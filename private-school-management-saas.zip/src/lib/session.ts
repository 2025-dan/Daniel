import { cookies } from "next/headers";
import { ROLE_COOKIE, type Role } from "@/lib/roles";

export async function getRole(): Promise<Role> {
  const store = await cookies();
  const value = store.get(ROLE_COOKIE)?.value;
  if (value === "comptable" || value === "enseignant" || value === "surveillant" || value === "directeur") {
    return value;
  }
  return "directeur";
}
