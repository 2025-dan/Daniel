export const CURRENCY = "FC";

export function money(value: number | string | null | undefined, withCurrency = true): string {
  const n = Number(value ?? 0);
  const formatted = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 }).format(
    Number.isFinite(n) ? n : 0,
  );
  return withCurrency ? `${formatted} ${CURRENCY}` : formatted;
}

export function compactMoney(value: number | null | undefined): string {
  const n = Number(value ?? 0);
  if (Math.abs(n) >= 1_000_000) return `${(n / 1_000_000).toFixed(n % 1_000_000 === 0 ? 0 : 1)} M`;
  if (Math.abs(n) >= 1_000) return `${Math.round(n / 1_000)} k`;
  return String(n);
}

export function toDate(value: string | Date | null | undefined): Date | null {
  if (!value) return null;
  if (value instanceof Date) return value;
  const iso = value.length === 10 ? `${value}T12:00:00` : value;
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function formatDate(value: string | Date | null | undefined): string {
  const d = toDate(value);
  if (!d) return "—";
  return new Intl.DateTimeFormat("fr-FR", { day: "2-digit", month: "short", year: "numeric" }).format(d);
}

export function formatDateLong(value: string | Date | null | undefined): string {
  const d = toDate(value);
  if (!d) return "—";
  return new Intl.DateTimeFormat("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(d);
}

export function formatDateTime(value: string | Date | null | undefined): string {
  const d = toDate(value);
  if (!d) return "—";
  return new Intl.DateTimeFormat("fr-FR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(d);
}

export function daysBetween(value: string | Date | null | undefined): number {
  const d = toDate(value);
  if (!d) return 0;
  const today = new Date();
  today.setHours(12, 0, 0, 0);
  return Math.round((d.getTime() - today.getTime()) / 86_400_000);
}

export function dueLabel(value: string | Date | null | undefined): string {
  const diff = daysBetween(value);
  if (diff === 0) return "Échéance aujourd'hui";
  if (diff > 0) return `Dans ${diff} jour${diff > 1 ? "s" : ""}`;
  return `En retard de ${Math.abs(diff)} jour${Math.abs(diff) > 1 ? "s" : ""}`;
}

export function relativeTime(value: string | Date | null | undefined): string {
  const d = toDate(value);
  if (!d) return "—";
  const diffMs = Date.now() - d.getTime();
  const mins = Math.round(diffMs / 60_000);
  if (mins < 60) return `il y a ${Math.max(1, mins)} min`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `il y a ${hours} h`;
  const days = Math.round(hours / 24);
  if (days < 31) return `il y a ${days} j`;
  return formatDate(d);
}

export function initials(first?: string | null, last?: string | null): string {
  return `${(first ?? "?").trim().charAt(0)}${(last ?? "").trim().charAt(0)}`.toUpperCase();
}

export function percent(part: number, total: number): number {
  if (!total) return 0;
  return Math.round((part / total) * 100);
}

export function todayISO(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function monthKey(value: string | Date | null | undefined): string {
  const d = toDate(value);
  if (!d) return "";
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function monthShort(key: string): string {
  const [y, m] = key.split("-").map(Number);
  if (!y || !m) return key;
  const label = new Intl.DateTimeFormat("fr-FR", { month: "short" }).format(new Date(y, m - 1, 1));
  return `${label.replace(".", "")} ${String(y).slice(2)}`;
}

export function gradeLabel(value: number | null | undefined): string {
  if (value === null || value === undefined) return "—";
  return new Intl.NumberFormat("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
}

export function mentionFor(average: number): { label: string; tone: "success" | "info" | "warning" | "danger" } {
  if (average >= 16) return { label: "Excellent", tone: "success" };
  if (average >= 14) return { label: "Très bien", tone: "success" };
  if (average >= 12) return { label: "Bien", tone: "info" };
  if (average >= 10) return { label: "Passable", tone: "warning" };
  return { label: "Insuffisant", tone: "danger" };
}

export function appreciationFor(average: number | null): string {
  if (average === null) return "Non évalué";
  if (average >= 16) return "Excellent travail, continuez ainsi.";
  if (average >= 14) return "Très bons résultats, félicitations.";
  if (average >= 12) return "Ensemble satisfaisant, peut mieux faire.";
  if (average >= 10) return "Résultats passables, plus de rigueur attendue.";
  return "Résultats insuffisants, soutien nécessaire.";
}

export const TERMS = ["Trimestre 1", "Trimestre 2", "Trimestre 3"] as const;
export type Term = (typeof TERMS)[number];

// Structure de l'enseignement en République démocratique du Congo :
// Maternelle, Primaire (1ère à 6ème), Éducation de base (7ème et 8ème),
// Humanités (1ère à 4ème).
export const LEVELS = [
  "Maternelle",
  "1ère Primaire",
  "2ème Primaire",
  "3ème Primaire",
  "4ème Primaire",
  "5ème Primaire",
  "6ème Primaire",
  "7ème Éducation de base",
  "8ème Éducation de base",
  "1ère Humanités",
  "2ème Humanités",
  "3ème Humanités",
  "4ème Humanités",
] as const;

export const CYCLES = ["Maternelle", "Primaire", "Éducation de base", "Humanités"] as const;

export const COUNTRIES = [
  "République démocratique du Congo",
  "République du Congo",
  "Angola",
  "Burundi",
  "Cameroun",
  "Côte d'Ivoire",
  "Gabon",
  "Kenya",
  "Ouganda",
  "Rwanda",
  "Sénégal",
  "Tanzanie",
  "Tchad",
  "Zambie",
  "Autre pays",
] as const;

export const DRC_CITIES = [
  "Kinshasa",
  "Lubumbashi",
  "Goma",
  "Bukavu",
  "Kisangani",
  "Mbuji-Mayi",
  "Kananga",
  "Kolwezi",
  "Matadi",
  "Beni",
  "Butembo",
  "Bunia",
  "Kikwit",
  "Tshikapa",
  "Uvira",
] as const;

export const DOCUMENT_CATEGORIES = [
  { key: "bulletin", label: "Bulletin scolaire" },
  { key: "acte", label: "Acte de naissance" },
  { key: "photo", label: "Photo d'identité" },
  { key: "inscription", label: "Fiche d'inscription" },
  { key: "recu", label: "Reçu de paiement" },
  { key: "medical", label: "Document médical" },
  { key: "autre", label: "Autre document" },
] as const;

export const DOCUMENT_STATUS_LABEL: Record<string, string> = {
  "à vérifier": "À vérifier",
  validé: "Validé",
  rejeté: "Rejeté",
};

export const PAYMENT_METHODS = ["mobile money", "espèces", "virement", "chèque"] as const;

export const INVOICE_STATUSES = ["payée", "partielle", "impayée", "annulée"] as const;

export type InvoiceStatus = (typeof INVOICE_STATUSES)[number];

export const INVOICE_TONE: Record<string, string> = {
  payée: "bg-brand-100 text-brand-800",
  partielle: "bg-amber-100 text-amber-800",
  impayée: "bg-red-100 text-red-700",
  annulée: "bg-ink/10 text-ink/60",
};

export const ATTENDANCE_TONE: Record<string, string> = {
  présent: "bg-brand-100 text-brand-800",
  retard: "bg-amber-100 text-amber-800",
  absent: "bg-red-100 text-red-700",
  excusé: "bg-sky-100 text-sky-700",
};

export const CHANNEL_LABEL: Record<string, string> = {
  sms: "SMS",
  email: "E-mail",
  app: "Notification",
  whatsapp: "WhatsApp",
};
