"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { and, eq, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  academicYears,
  assessments,
  attendance,
  classes,
  documents,
  exams,
  lessonLogs,
  enrollments,
  feeStructures,
  grades,
  guardians,
  invoices,
  messages,
  payments,
  payrolls,
  reminders,
  schools,
  staff,
  students,
  subjects,
  timetableSlots,
} from "@/db/schema";
import { requireContext } from "@/lib/data/context";
import { ROLE_COOKIE, roleLabel, type Role } from "@/lib/roles";
import { getRole } from "@/lib/session";
import { todayISO } from "@/lib/format";
import { currentPeriod } from "@/lib/data/staff";
import {
  PARENT_COOKIE,
  findStudentByMatricule,
  getParentInvoice,
  getParentStudentId,
} from "@/lib/data/parent";

const VALID_ROLES: Role[] = ["directeur", "comptable", "enseignant", "surveillant"];

function str(value: FormDataEntryValue | null | undefined, fallback = ""): string {
  return typeof value === "string" ? value.trim() : fallback;
}

function num(value: FormDataEntryValue | null | undefined, fallback = 0): number {
  const raw = typeof value === "string" ? value.replace(/\s/g, "").replace(",", ".") : "";
  const parsed = Number(raw);
  return raw === "" || !Number.isFinite(parsed) ? fallback : parsed;
}

function isoDate(value: FormDataEntryValue | null | undefined, fallback: string): string {
  const raw = str(value);
  return /^\d{4}-\d{2}-\d{2}$/.test(raw) ? raw : fallback;
}

function shiftDays(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function safeRedirect(value: FormDataEntryValue | null | undefined, fallback: string): string {
  const raw = str(value);
  return raw.startsWith("/") && !raw.startsWith("//") ? raw : fallback;
}

function refreshAll() {
  for (const path of [
    "/dashboard",
    "/eleves",
    "/classes",
    "/finances",
    "/presences",
    "/notes",
    "/bulletins",
    "/communication",
    "/parametres",
    "/emploi-du-temps",
    "/cahier-de-textes",
    "/examens",
    "/personnel",
    "/paie",
    "/parents",
    "/plateforme",
    "/documents",
    "/documents/scan",
  ]) {
    revalidatePath(path);
  }
}

/* ------------------------------------------------------------------ */
/* Session / rôle de démonstration                                     */
/* ------------------------------------------------------------------ */

export async function setPersona(formData: FormData) {
  const requested = str(formData.get("role"), "directeur") as Role;
  const role = VALID_ROLES.includes(requested) ? requested : "directeur";
  const store = await cookies();
  store.set(ROLE_COOKIE, role, { path: "/", maxAge: 60 * 60 * 24 * 30, sameSite: "lax" });
  revalidatePath("/", "layout");
}

/* ------------------------------------------------------------------ */
/* Scolarité — élèves & inscriptions                                   */
/* ------------------------------------------------------------------ */

export async function createStudent(formData: FormData) {
  const { school, year } = await requireContext();
  const firstName = str(formData.get("firstName"));
  const lastName = str(formData.get("lastName"));
  const classId = num(formData.get("classId"));

  if (!firstName || !lastName) {
    redirect("/eleves/nouveau?erreur=Le+nom+et+le+prénom+sont+obligatoires");
  }

  const [maxStudent] = await db
    .select({ m: sql<string>`coalesce(max(${students.id}), 0)` })
    .from(students);
  const prefix = school.shortName.toUpperCase().replace(/[^A-Z0-9]/g, "");
  let matricule = str(formData.get("matricule"));
  if (!matricule) {
    matricule = `${prefix}-${year.label.slice(0, 4)}-${String(Number(maxStudent?.m ?? 0) + 1).padStart(3, "0")}`;
  }
  const [existing] = await db
    .select({ id: students.id })
    .from(students)
    .where(eq(students.matricule, matricule))
    .limit(1);
  if (existing) {
    matricule = `${matricule}-${Date.now().toString().slice(-3)}`;
  }

  const [student] = await db
    .insert(students)
    .values({
      schoolId: school.id,
      matricule,
      firstName,
      lastName,
      gender: str(formData.get("gender"), "M") === "F" ? "F" : "M",
      birthDate: str(formData.get("birthDate")) || null,
      birthPlace: str(formData.get("birthPlace")),
      status: str(formData.get("status"), "actif"),
      address: str(formData.get("address")),
      bloodGroup: str(formData.get("bloodGroup")),
      notes: str(formData.get("notes")),
      enrolledAt: todayISO(),
    })
    .returning({ id: students.id });

  const guardianName = str(formData.get("guardianName"));
  if (guardianName) {
    await db.insert(guardians).values({
      studentId: student.id,
      fullName: guardianName,
      relation: str(formData.get("guardianRelation"), "Père"),
      phone: str(formData.get("guardianPhone")),
      email: str(formData.get("guardianEmail")),
      profession: str(formData.get("guardianProfession")),
      isPrimary: true,
    });
  }
  const secondGuardian = str(formData.get("secondGuardianName"));
  if (secondGuardian) {
    await db.insert(guardians).values({
      studentId: student.id,
      fullName: secondGuardian,
      relation: str(formData.get("secondGuardianRelation"), "Mère"),
      phone: str(formData.get("secondGuardianPhone")),
      isPrimary: false,
    });
  }

  if (classId) {
    const [classRow] = await db.select().from(classes).where(eq(classes.id, classId)).limit(1);
    if (classRow) {
      await db.insert(enrollments).values({
        studentId: student.id,
        classId,
        academicYearId: year.id,
        status: "inscrit",
        tuitionAmount: classRow.monthlyFee * 9,
        registeredAt: todayISO(),
      });

      if (str(formData.get("generateFees")) === "on") {
        const [maxInvoice] = await db
          .select({ m: sql<string>`coalesce(max(${invoices.id}), 0)` })
          .from(invoices);
        let seq = Number(maxInvoice?.m ?? 0) + 1;
        const plans = [
          { label: "Frais d'inscription", amount: 25000, due: todayISO() },
          { label: "Scolarité — 1er versement", amount: classRow.monthlyFee * 3, due: shiftDays(14) },
          { label: "Scolarité — 2e versement", amount: classRow.monthlyFee * 3, due: shiftDays(44) },
          { label: "Scolarité — 3e versement", amount: classRow.monthlyFee * 3, due: shiftDays(74) },
        ];
        await db.insert(invoices).values(
          plans.map((plan) => ({
            schoolId: school.id,
            studentId: student.id,
            number: `FAC-${year.label.slice(0, 4)}-${String(seq++).padStart(4, "0")}`,
            label: plan.label,
            amount: plan.amount,
            amountPaid: 0,
            dueDate: plan.due,
            status: "impayée",
          })),
        );
      }
    }
  }

  refreshAll();
  redirect(`/eleves/${student.id}?inscription=ok`);
}

/* ------------------------------------------------------------------ */
/* Finances                                                            */
/* ------------------------------------------------------------------ */

export async function recordPayment(formData: FormData) {
  const redirectTo = safeRedirect(formData.get("redirectTo"), "/finances");
  const invoiceId = num(formData.get("invoiceId"));
  if (!invoiceId) redirect(`${redirectTo}?erreur=Facture+invalide`);

  const [invoice] = await db.select().from(invoices).where(eq(invoices.id, invoiceId)).limit(1);
  if (!invoice) redirect(`${redirectTo}?erreur=Facture+introuvable`);

  const remaining = invoice.amount - invoice.amountPaid;
  const requested = num(formData.get("amount"), remaining);
  const applied = Math.max(0, Math.min(requested, remaining));
  if (applied <= 0) redirect(`${redirectTo}?erreur=Montant+invalide`);

  const role = await getRole();
  const newPaid = invoice.amountPaid + applied;
  await db.insert(payments).values({
    schoolId: invoice.schoolId,
    invoiceId: invoice.id,
    studentId: invoice.studentId,
    amount: applied,
    method: str(formData.get("method"), "mobile money"),
    reference: str(formData.get("reference")),
    paidAt: isoDate(formData.get("paidAt"), todayISO()),
    recordedBy: `Encaissement — ${roleLabel(role)}`,
  });
  await db
    .update(invoices)
    .set({
      amountPaid: newPaid,
      status: newPaid >= invoice.amount ? "payée" : "partielle",
    })
    .where(eq(invoices.id, invoice.id));

  refreshAll();
  revalidatePath(`/eleves/${invoice.studentId}`);
  redirect(redirectTo);
}

export async function sendReminder(formData: FormData) {
  const redirectTo = safeRedirect(formData.get("redirectTo"), "/finances");
  const invoiceId = num(formData.get("invoiceId"));
  const channel = str(formData.get("channel"), "sms");
  const { school } = await requireContext();

  const [invoice] = await db
    .select({
      id: invoices.id,
      studentId: invoices.studentId,
      amount: invoices.amount,
      amountPaid: invoices.amountPaid,
      number: invoices.number,
      label: invoices.label,
      firstName: students.firstName,
      lastName: students.lastName,
    })
    .from(invoices)
    .innerJoin(students, eq(students.id, invoices.studentId))
    .where(eq(invoices.id, invoiceId))
    .limit(1);

  if (!invoice) redirect(`${redirectTo}?erreur=Facture+introuvable`);

  const balance = invoice.amount - invoice.amountPaid;
  const body = `Bonjour, nous vous rappelons que la facture ${invoice.number} (${invoice.label}) de ${new Intl.NumberFormat("fr-FR").format(balance)} FC pour ${invoice.firstName} ${invoice.lastName} reste à régler. Merci de vous rapprocher de la comptabilité. — ${school.shortName}`;

  await db.insert(reminders).values({
    invoiceId: invoice.id,
    studentId: invoice.studentId,
    channel,
    message: body,
  });
  await db.insert(messages).values({
    schoolId: school.id,
    audience: "parent",
    studentId: invoice.studentId,
    recipientLabel: `${invoice.firstName} ${invoice.lastName}`,
    channel,
    subject: `Relance scolarité — ${invoice.number}`,
    body,
    status: "envoyé",
    recipientsCount: 1,
  });

  refreshAll();
  redirect(redirectTo);
}

export async function sendBulkReminders(formData: FormData) {
  const redirectTo = safeRedirect(formData.get("redirectTo"), "/finances");
  const channel = str(formData.get("channel"), "sms");
  const { school } = await requireContext();

  const overdue = await db
    .select({
      id: invoices.id,
      studentId: invoices.studentId,
      amount: invoices.amount,
      amountPaid: invoices.amountPaid,
      number: invoices.number,
    })
    .from(invoices)
    .where(
      and(
        eq(invoices.schoolId, school.id),
        sql`${invoices.amountPaid} < ${invoices.amount}`,
        sql`${invoices.dueDate} < current_date`,
      ),
    )
    .limit(200);

  for (const invoice of overdue) {
    await db.insert(reminders).values({
      invoiceId: invoice.id,
      studentId: invoice.studentId,
      channel,
      message: "Relance automatique des frais de scolarité échus.",
    });
  }

  if (overdue.length > 0) {
    const total = overdue.reduce((sum, i) => sum + (i.amount - i.amountPaid), 0);
    await db.insert(messages).values({
      schoolId: school.id,
      audience: "tous",
      recipientLabel: `${overdue.length} famille(s) en retard`,
      channel,
      subject: "Relance de scolarité",
      body: `Chers parents, un solde de ${new Intl.NumberFormat("fr-FR").format(total)} FC reste à régler pour ${overdue.length} dossier(s). Merci de régulariser auprès de la comptabilité. — ${school.shortName}`,
      status: "envoyé",
      recipientsCount: overdue.length,
    });
  }

  refreshAll();
  redirect(`${redirectTo}${redirectTo.includes("?") ? "&" : "?"}relances=${overdue.length}`);
}

/* ------------------------------------------------------------------ */
/* Pédagogie                                                           */
/* ------------------------------------------------------------------ */

export async function saveAttendance(formData: FormData) {
  const classId = num(formData.get("classId"));
  const date = isoDate(formData.get("date"), todayISO());
  const role = await getRole();
  const allowed = ["présent", "absent", "retard", "excusé"];

  const rows: { studentId: number; classId: number; date: string; status: string; note: string; recordedBy: string }[] = [];
  for (const [key, value] of formData.entries()) {
    if (!key.startsWith("status_")) continue;
    const studentId = Number(key.replace("status_", ""));
    const status = String(value);
    if (!studentId || !allowed.includes(status)) continue;
    rows.push({
      studentId,
      classId,
      date,
      status,
      note: "",
      recordedBy: `Appel — ${roleLabel(role)}`,
    });
  }

  if (classId && rows.length > 0) {
    await db.delete(attendance).where(and(eq(attendance.classId, classId), eq(attendance.date, date)));
    await db.insert(attendance).values(rows);
  }

  refreshAll();
  redirect(`/presences?classId=${classId}&date=${date}&enregistre=1`);
}

export async function createAssessment(formData: FormData) {
  const { year } = await requireContext();
  const classId = num(formData.get("classId"));
  const subjectId = num(formData.get("subjectId"));
  const term = str(formData.get("term"), "Trimestre 1");

  if (!classId || !subjectId) {
    redirect(`/notes?classId=${classId}&subjectId=${subjectId}&term=${encodeURIComponent(term)}&erreur=Matière+requise`);
  }

  await db.insert(assessments).values({
    classId,
    subjectId,
    academicYearId: year.id,
    term,
    title: str(formData.get("title"), "Évaluation"),
    maxScore: Math.max(1, num(formData.get("maxScore"), 20)),
    coefficient: Math.max(1, num(formData.get("coefficient"), 1)),
    date: isoDate(formData.get("date"), todayISO()),
  });

  refreshAll();
  redirect(
    `/notes?classId=${classId}&subjectId=${subjectId}&term=${encodeURIComponent(term)}&enregistre=evaluation`,
  );
}

export async function saveGrades(formData: FormData) {
  const classId = num(formData.get("classId"));
  const subjectId = num(formData.get("subjectId"));
  const term = str(formData.get("term"), "Trimestre 1");

  for (const [key, value] of formData.entries()) {
    if (!key.startsWith("score_")) continue;
    const [, assessmentRaw, studentRaw] = key.split("_");
    const assessmentId = Number(assessmentRaw);
    const studentId = Number(studentRaw);
    if (!assessmentId || !studentId) continue;

    const raw = String(value).trim().replace(",", ".");
    const [existing] = await db
      .select({ id: grades.id })
      .from(grades)
      .where(and(eq(grades.assessmentId, assessmentId), eq(grades.studentId, studentId)))
      .limit(1);

    if (raw === "") {
      if (existing) await db.delete(grades).where(eq(grades.id, existing.id));
      continue;
    }
    const parsed = Number(raw);
    if (!Number.isFinite(parsed)) continue;
    const score = Math.max(0, Math.min(20, Math.round(parsed * 100) / 100));

    if (existing) {
      await db.update(grades).set({ score }).where(eq(grades.id, existing.id));
    } else {
      await db.insert(grades).values({ assessmentId, studentId, score, remark: "" });
    }
  }

  refreshAll();
  redirect(`/notes?classId=${classId}&subjectId=${subjectId}&term=${encodeURIComponent(term)}&enregistre=notes`);
}

/* ------------------------------------------------------------------ */
/* Communication                                                       */
/* ------------------------------------------------------------------ */

export async function sendMessage(formData: FormData) {
  const { school } = await requireContext();
  const audience = str(formData.get("audience"), "tous");
  const channel = str(formData.get("channel"), "sms");
  const classId = num(formData.get("classId"));
  const studentId = num(formData.get("studentId"));
  const isDraft = str(formData.get("intent")) === "brouillon";

  let recipientLabel = "Tous les parents";
  let recipientsCount = 0;
  let className = "";

  if (audience === "classe" && classId) {
    const [classRow] = await db.select().from(classes).where(eq(classes.id, classId)).limit(1);
    const [count] = await db
      .select({ c: sql<string>`count(*)` })
      .from(enrollments)
      .where(eq(enrollments.classId, classId));
    recipientLabel = `Parents — ${classRow?.name ?? "classe"}`;
    recipientsCount = Number(count?.c ?? 0);
    className = classRow?.name ?? "";
  } else if (audience === "parent" && studentId) {
    const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
    recipientLabel = student ? `${student.firstName} ${student.lastName} (tuteur)` : "Parent";
    recipientsCount = 1;
    className = "";
  } else {
    const [count] = await db
      .select({ c: sql<string>`count(*)` })
      .from(students)
      .where(and(eq(students.schoolId, school.id), eq(students.status, "actif")));
    recipientLabel = "Tous les parents";
    recipientsCount = Number(count?.c ?? 0);
  }
  void className;

  await db.insert(messages).values({
    schoolId: school.id,
    audience,
    classId: audience === "classe" && classId ? classId : null,
    studentId: audience === "parent" && studentId ? studentId : null,
    recipientLabel,
    channel,
    subject: str(formData.get("subject"), "Message aux parents"),
    body: str(formData.get("body")),
    status: isDraft ? "brouillon" : "envoyé",
    recipientsCount: isDraft ? 0 : recipientsCount,
  });

  refreshAll();
  redirect(`/communication?${isDraft ? "brouillon" : "envoye"}=1`);
}

/* ------------------------------------------------------------------ */
/* Paramètres                                                          */
/* ------------------------------------------------------------------ */

export async function saveSchool(formData: FormData) {
  const { school } = await requireContext();
  await db
    .update(schools)
    .set({
      name: str(formData.get("name"), school.name),
      shortName: str(formData.get("shortName"), school.shortName),
      city: str(formData.get("city")),
      country: str(formData.get("country")),
      phone: str(formData.get("phone")),
      email: str(formData.get("email")),
      address: str(formData.get("address")),
      motto: str(formData.get("motto")),
      directorName: str(formData.get("directorName")),
    })
    .where(eq(schools.id, school.id));
  refreshAll();
  redirect("/parametres?enregistre=etablissement");
}

export async function createClass(formData: FormData) {
  const { school, year } = await requireContext();
  const name = str(formData.get("name"));
  if (!name) redirect("/classes?erreur=Nom+de+classe+requis");

  await db.insert(classes).values({
    schoolId: school.id,
    academicYearId: year.id,
    name,
    level: str(formData.get("level"), "1ère Primaire"),
    cycle: str(formData.get("cycle"), "Primaire"),
    capacity: Math.max(1, num(formData.get("capacity"), 40)),
    room: str(formData.get("room")),
    mainTeacher: str(formData.get("mainTeacher")),
    monthlyFee: Math.max(0, num(formData.get("monthlyFee"), 50000)),
  });

  refreshAll();
  redirect("/classes?classe=creee");
}

export async function createSubject(formData: FormData) {
  const { school } = await requireContext();
  const name = str(formData.get("name"));
  if (!name) redirect("/parametres?erreur=Matière+requise");

  await db.insert(subjects).values({
    schoolId: school.id,
    name,
    code: str(formData.get("code"), name.slice(0, 4).toUpperCase()),
    cycle: str(formData.get("cycle"), "Primaire"),
    coefficient: Math.max(1, num(formData.get("coefficient"), 1)),
    teacher: str(formData.get("teacher")),
  });

  refreshAll();
  redirect("/parametres?enregistre=matiere");
}

export async function createFeeStructure(formData: FormData) {
  const { school, year } = await requireContext();
  await db.insert(feeStructures).values({
    schoolId: school.id,
    academicYearId: year.id,
    level: str(formData.get("level"), "1ère Primaire"),
    label: str(formData.get("label"), "Frais de scolarité"),
    amount: Math.max(0, num(formData.get("amount"), 0)),
    type: str(formData.get("type"), "scolarité"),
    dueDate: str(formData.get("dueDate")) || null,
  });
  refreshAll();
  redirect("/parametres?enregistre=frais");
}

export async function setCurrentYear(formData: FormData) {
  const { school } = await requireContext();
  const yearId = num(formData.get("yearId"));
  if (!yearId) redirect("/parametres");
  await db
    .update(academicYears)
    .set({ isCurrent: false })
    .where(eq(academicYears.schoolId, school.id));
  await db
    .update(academicYears)
    .set({ isCurrent: true })
    .where(and(eq(academicYears.schoolId, school.id), eq(academicYears.id, yearId)));
  refreshAll();
  redirect("/parametres?enregistre=annee");
}

/* ------------------------------------------------------------------ */
/* Emploi du temps                                                     */
/* ------------------------------------------------------------------ */

export async function addTimetableSlot(formData: FormData) {
  const { school } = await requireContext();
  const classId = num(formData.get("classId"));
  const subjectId = num(formData.get("subjectId"));
  if (!classId) redirect("/emploi-du-temps?erreur=Classe+requise");

  const day = Math.min(6, Math.max(1, num(formData.get("day"), 1)));
  const startTime = str(formData.get("startTime"), "08:00");
  const endTime = str(formData.get("endTime"), "09:00");

  await db.insert(timetableSlots).values({
    schoolId: school.id,
    classId,
    day,
    startTime,
    endTime,
    subjectId: subjectId || null,
    teacher: str(formData.get("teacher")),
    room: str(formData.get("room")),
  });

  refreshAll();
  revalidatePath("/emploi-du-temps");
  redirect(`/emploi-du-temps?classId=${classId}&enregistre=slot`);
}

export async function deleteTimetableSlot(formData: FormData) {
  const id = num(formData.get("slotId"));
  const classId = num(formData.get("classId"));
  if (id) await db.delete(timetableSlots).where(eq(timetableSlots.id, id));
  revalidatePath("/emploi-du-temps");
  redirect(`/emploi-du-temps?classId=${classId}`);
}

/* ------------------------------------------------------------------ */
/* Cahier de textes                                                    */
/* ------------------------------------------------------------------ */

export async function createLessonLog(formData: FormData) {
  const { school } = await requireContext();
  const classId = num(formData.get("classId"));
  const subjectId = num(formData.get("subjectId"));
  if (!classId) redirect("/cahier-de-textes?erreur=Classe+requise");

  await db.insert(lessonLogs).values({
    schoolId: school.id,
    classId,
    subjectId: subjectId || null,
    date: isoDate(formData.get("date"), todayISO()),
    title: str(formData.get("title"), "Séance de classe"),
    content: str(formData.get("content")),
    homework: str(formData.get("homework")),
    dueDate: str(formData.get("dueDate")) || null,
    teacher: str(formData.get("teacher")),
  });

  revalidatePath("/cahier-de-textes");
  redirect(`/cahier-de-textes?classId=${classId}&enregistre=seance`);
}

export async function deleteLessonLog(formData: FormData) {
  const id = num(formData.get("logId"));
  const classId = num(formData.get("classId"));
  if (id) await db.delete(lessonLogs).where(eq(lessonLogs.id, id));
  revalidatePath("/cahier-de-textes");
  redirect(`/cahier-de-textes?classId=${classId}`);
}

/* ------------------------------------------------------------------ */
/* Examens                                                             */
/* ------------------------------------------------------------------ */

export async function createExam(formData: FormData) {
  const { school } = await requireContext();
  const classId = num(formData.get("classId"));
  const subjectId = num(formData.get("subjectId"));
  if (!classId) redirect("/examens?erreur=Classe+requise");

  await db.insert(exams).values({
    schoolId: school.id,
    classId,
    subjectId: subjectId || null,
    term: str(formData.get("term"), "Trimestre 1"),
    title: str(formData.get("title"), "Examen"),
    date: isoDate(formData.get("date"), todayISO()),
    startTime: str(formData.get("startTime"), "08:00"),
    duration: Math.max(15, num(formData.get("duration"), 120)),
    room: str(formData.get("room")),
    supervisor: str(formData.get("supervisor")),
    status: "planifié",
  });

  revalidatePath("/examens");
  redirect(`/examens?classId=${classId}&enregistre=examen`);
}

export async function updateExamStatus(formData: FormData) {
  const id = num(formData.get("examId"));
  const status = str(formData.get("status"), "planifié");
  if (id) await db.update(exams).set({ status }).where(eq(exams.id, id));
  revalidatePath("/examens");
  redirect(`/examens?classId=${str(formData.get("classId"))}&term=${encodeURIComponent(str(formData.get("term")))}`);
}

export async function deleteExam(formData: FormData) {
  const id = num(formData.get("examId"));
  if (id) await db.delete(exams).where(eq(exams.id, id));
  revalidatePath("/examens");
  redirect(`/examens?classId=${str(formData.get("classId"))}`);
}

/* ------------------------------------------------------------------ */
/* Personnel & paie                                                    */
/* ------------------------------------------------------------------ */

export async function createStaff(formData: FormData) {
  const { school } = await requireContext();
  const firstName = str(formData.get("firstName"));
  const lastName = str(formData.get("lastName"));
  if (!firstName || !lastName) redirect("/personnel?erreur=Nom+et+prénom+requis");

  await db.insert(staff).values({
    schoolId: school.id,
    firstName,
    lastName,
    jobTitle: str(formData.get("jobTitle"), "Enseignant"),
    category: str(formData.get("category"), "enseignement"),
    phone: str(formData.get("phone")),
    email: str(formData.get("email")),
    qualification: str(formData.get("qualification")),
    hireDate: isoDate(formData.get("hireDate"), todayISO()),
    monthlySalary: Math.max(0, num(formData.get("monthlySalary"), 0)),
    status: str(formData.get("status"), "actif"),
  });

  revalidatePath("/personnel");
  revalidatePath("/paie");
  redirect("/personnel?enregistre=membre");
}

export async function updateStaffStatus(formData: FormData) {
  const id = num(formData.get("staffId"));
  const status = str(formData.get("status"), "actif");
  if (id) await db.update(staff).set({ status }).where(eq(staff.id, id));
  revalidatePath("/personnel");
  redirect("/personnel?enregistre=statut");
}

export async function generatePayroll(formData: FormData) {
  const { school } = await requireContext();
  const period = /^\d{4}-\d{2}$/.test(str(formData.get("period"))) ? str(formData.get("period")) : currentPeriod();
  const members = await db.select().from(staff).where(and(eq(staff.schoolId, school.id), ne(staff.status, "inactif")));
  const existing = await db
    .select({ staffId: payrolls.staffId })
    .from(payrolls)
    .where(and(eq(payrolls.schoolId, school.id), eq(payrolls.period, period)));

  const missing = members.filter((m) => !existing.some((e) => e.staffId === m.id));
  if (missing.length > 0) {
    await db.insert(payrolls).values(
      missing.map((member) => {
        const deductions = Math.round(member.monthlySalary * 0.0575);
        return {
          schoolId: school.id,
          staffId: member.id,
          period,
          grossSalary: member.monthlySalary,
          bonuses: 0,
          deductions,
          netSalary: member.monthlySalary - deductions,
          status: "en attente" as const,
          method: "virement",
          reference: "",
        };
      }),
    );
  }

  revalidatePath("/paie");
  revalidatePath("/personnel");
  redirect(`/paie?period=${period}&genere=${missing.length}`);
}

export async function payPayroll(formData: FormData) {
  const id = num(formData.get("payrollId"));
  const period = str(formData.get("period"));
  const method = str(formData.get("method"), "virement");
  if (id) {
    await db
      .update(payrolls)
      .set({
        status: "payé",
        paidAt: todayISO(),
        method,
        reference: `PAIE-${period}-${String(id).padStart(4, "0")}`,
      })
      .where(eq(payrolls.id, id));
  }
  revalidatePath("/paie");
  revalidatePath("/personnel");
  redirect(`/paie?period=${period}&paie=1`);
}

export async function payAllPayrolls(formData: FormData) {
  const period = str(formData.get("period"));
  const method = str(formData.get("method"), "virement");
  await db
    .update(payrolls)
    .set({ status: "payé", paidAt: todayISO(), method })
    .where(and(eq(payrolls.period, period), eq(payrolls.status, "en attente")));
  revalidatePath("/paie");
  revalidatePath("/personnel");
  redirect(`/paie?period=${period}&paie=tout`);
}

/* ------------------------------------------------------------------ */
/* Console plateforme                                                  */
/* ------------------------------------------------------------------ */

export async function updateSubscription(formData: FormData) {
  const schoolId = num(formData.get("schoolId"));
  if (!schoolId) redirect("/plateforme");
  const plan = str(formData.get("plan"), "Pro");
  const status = str(formData.get("subscriptionStatus"), "actif");
  const seats = Math.max(1, num(formData.get("seats"), 150));
  const monthlyPrice = Math.max(0, num(formData.get("monthlyPrice"), 25000));
  const renewal = str(formData.get("renewalDate"));

  const [current] = await db.select().from(schools).where(eq(schools.id, schoolId)).limit(1);

  await db
    .update(schools)
    .set({
      name: str(formData.get("name")) || current?.name || "",
      city: str(formData.get("city")) || current?.city || "",
      country: str(formData.get("country")) || current?.country || "",
      plan,
      subscriptionStatus: status,
      seats,
      monthlyPrice,
      renewalDate: /^\d{4}-\d{2}-\d{2}$/.test(renewal) ? renewal : null,
    })
    .where(eq(schools.id, schoolId));

  revalidatePath("/plateforme");
  redirect(`/plateforme?enregistre=${schoolId}`);
}

/* ------------------------------------------------------------------ */
/* Portail parents                                                     */
/* ------------------------------------------------------------------ */

export async function parentLogin(formData: FormData) {
  const matricule = str(formData.get("matricule"));
  const student = await findStudentByMatricule(matricule);
  if (!student) {
    redirect(`/parents?erreur=${encodeURIComponent("Matricule inconnu. Exemple : GSLP-2026-001")}`);
  }

  const store = await cookies();
  store.set(PARENT_COOKIE, String(student.id), { path: "/", maxAge: 60 * 60 * 24 * 30, sameSite: "lax" });
  revalidatePath("/parents");
  redirect("/parents");
}

export async function parentLoginDirect(formData: FormData) {
  const id = num(formData.get("studentId"));
  if (!id) redirect("/parents");
  const store = await cookies();
  store.set(PARENT_COOKIE, String(id), { path: "/", maxAge: 60 * 60 * 24 * 30, sameSite: "lax" });
  revalidatePath("/parents");
  redirect("/parents");
}

export async function parentLogout() {
  const store = await cookies();
  store.delete(PARENT_COOKIE);
  revalidatePath("/parents");
  redirect("/parents");
}

export async function parentPayInvoice(formData: FormData) {
  const studentId = await getParentStudentId();
  if (!studentId) redirect("/parents");
  const invoiceId = num(formData.get("invoiceId"));
  const invoice = await getParentInvoice(studentId, invoiceId);
  if (!invoice) redirect("/parents?vue=paiements&erreur=Facture+introuvable");

  const remaining = invoice.amount - invoice.amountPaid;
  const amount = Math.max(1, Math.min(num(formData.get("amount"), remaining), remaining));

  await db.insert(payments).values({
    schoolId: invoice.schoolId,
    invoiceId: invoice.id,
    studentId,
    amount,
    method: str(formData.get("method"), "mobile money"),
    reference: str(formData.get("reference")) || `MOB-${Date.now().toString().slice(-6)}`,
    paidAt: todayISO(),
    recordedBy: "Portail parents — paiement en ligne",
  });
  const newPaid = invoice.amountPaid + amount;
  await db
    .update(invoices)
    .set({ amountPaid: newPaid, status: newPaid >= invoice.amount ? "payée" : "partielle" })
    .where(eq(invoices.id, invoice.id));

  refreshAll();
  revalidatePath("/parents");
  redirect("/parents?vue=paiements&paiement=ok");
}

/* ------------------------------------------------------------------ */
/* Compléments : facture manuelle & mise à jour d'un dossier élève      */
/* ------------------------------------------------------------------ */

export async function createInvoice(formData: FormData) {
  const { school, year } = await requireContext();
  const studentId = num(formData.get("studentId"));
  const label = str(formData.get("label"), "Frais de scolarité");
  const amount = Math.max(500, num(formData.get("amount"), 0));
  if (!studentId || amount <= 0) {
    redirect(`/finances?erreur=${encodeURIComponent("Sélectionnez un élève et un montant valide")}`);
  }

  const [maxInvoice] = await db.select({ m: sql<string>`coalesce(max(${invoices.id}), 0)` }).from(invoices);
  const number = `FAC-${year.label.slice(0, 4)}-${String(Number(maxInvoice?.m ?? 0) + 1).padStart(4, "0")}`;

  await db.insert(invoices).values({
    schoolId: school.id,
    studentId,
    number,
    label,
    amount,
    amountPaid: 0,
    dueDate: isoDate(formData.get("dueDate"), shiftDays(14)),
    status: "impayée",
  });

  refreshAll();
  redirect("/finances?facture=creee");
}

export async function updateStudent(formData: FormData) {
  const { year } = await requireContext();
  const id = num(formData.get("studentId"));
  if (!id) redirect("/eleves");

  await db
    .update(students)
    .set({
      firstName: str(formData.get("firstName")),
      lastName: str(formData.get("lastName")),
      gender: str(formData.get("gender"), "M") === "F" ? "F" : "M",
      birthDate: str(formData.get("birthDate")) || null,
      birthPlace: str(formData.get("birthPlace")),
      status: str(formData.get("status"), "actif"),
      address: str(formData.get("address")),
      notes: str(formData.get("notes")),
    })
    .where(eq(students.id, id));

  const classId = num(formData.get("classId"));
  const [enrollment] = await db
    .select({ id: enrollments.id, classId: enrollments.classId })
    .from(enrollments)
    .where(and(eq(enrollments.studentId, id), eq(enrollments.academicYearId, year.id)))
    .limit(1);

  if (classId > 0) {
    const [classRow] = await db.select().from(classes).where(eq(classes.id, classId)).limit(1);
    if (enrollment) {
      await db
        .update(enrollments)
        .set({ classId, tuitionAmount: classRow ? classRow.monthlyFee * 9 : 0 })
        .where(eq(enrollments.id, enrollment.id));
    } else if (classRow) {
      await db.insert(enrollments).values({
        studentId: id,
        classId,
        academicYearId: year.id,
        status: "inscrit",
        tuitionAmount: classRow.monthlyFee * 9,
        registeredAt: todayISO(),
      });
    }
  } else if (enrollment) {
    await db.delete(enrollments).where(eq(enrollments.id, enrollment.id));
  }

  refreshAll();
  revalidatePath(`/eleves/${id}`);
  redirect(`/eleves/${id}?modifie=ok`);
}

/* ------------------------------------------------------------------ */
/* Documents : import, scan de bulletin, validation, partage           */
/* ------------------------------------------------------------------ */

const MAX_FILE_SIZE = 8 * 1024 * 1024;
const ALLOWED_MIME = [
  "application/pdf",
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/heic",
  "image/heif",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
];

export async function uploadDocument(formData: FormData) {
  const { school } = await requireContext();
  const role = await getRole();
  const redirectTo = safeRedirect(formData.get("redirectTo"), "/documents");
  const file = formData.get("file");
  const category = str(formData.get("category"), "autre");
  const studentId = num(formData.get("studentId"));
  const term = str(formData.get("term"));
  const isScan = str(formData.get("source")) === "scan";

  if (!(file instanceof File) || file.size === 0) {
    redirect(`${redirectTo}${redirectTo.includes("?") ? "&" : "?"}erreur=${encodeURIComponent("Aucun fichier sélectionné")}`);
  }
  if (file.size > MAX_FILE_SIZE) {
    redirect(`${redirectTo}${redirectTo.includes("?") ? "&" : "?"}erreur=${encodeURIComponent("Fichier trop volumineux (max 8 Mo)")}`);
  }
  const mime = file.type || "application/pdf";
  if (!ALLOWED_MIME.includes(mime)) {
    redirect(`${redirectTo}${redirectTo.includes("?") ? "&" : "?"}erreur=${encodeURIComponent("Format non pris en charge (PDF, JPG, PNG, WEBP, DOCX)")}`);
  }

  let classId: number | null = null;
  let studentLabel = "";
  if (studentId) {
    const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
    if (student) {
      studentLabel = `${student.lastName} ${student.firstName}`;
      const [enrollment] = await db
        .select({ classId: enrollments.classId })
        .from(enrollments)
        .where(eq(enrollments.studentId, studentId))
        .limit(1);
      classId = enrollment?.classId ?? null;
    }
  }

  const buffer = Buffer.from(await file.arrayBuffer());
  const requestedStatus = str(formData.get("status"));
  const hasAverage = str(formData.get("average")) !== "";
  const status = requestedStatus || (isScan ? "à vérifier" : category === "bulletin" ? "à vérifier" : "validé");

  await db.insert(documents).values({
    schoolId: school.id,
    studentId: studentId || null,
    classId,
    category,
    title:
      str(formData.get("title")) ||
      `${isScan ? "Bulletin scanné" : "Document"} — ${studentLabel || "établissement"}${term ? ` (${term})` : ""}`,
    fileName: file.name || `scan-${Date.now()}.jpg`,
    mimeType: mime,
    fileSize: file.size,
    data: buffer.toString("base64"),
    term,
    average: hasAverage ? num(formData.get("average")) : null,
    decision: str(formData.get("decision")),
    status,
    shared: str(formData.get("shared")) === "on",
    notes: str(formData.get("notes")),
    uploadedBy: roleLabel(role),
    source: isScan ? "scan" : "import",
  });

  refreshAll();
  redirect(`${redirectTo}${redirectTo.includes("?") ? "&" : "?"}importe=ok`);
}

export async function updateDocument(formData: FormData) {
  const id = num(formData.get("documentId"));
  const redirectTo = safeRedirect(formData.get("redirectTo"), "/documents");
  if (!id) redirect(redirectTo);

  const status = str(formData.get("status"));
  const action = str(formData.get("intent"));
  const patch: Record<string, unknown> = {};

  if (action === "validate") {
    patch.status = "validé";
    patch.shared = true;
  } else if (action === "reject") {
    patch.status = "rejeté";
    patch.shared = false;
  } else if (action === "share") {
    patch.shared = true;
  } else if (action === "unshare") {
    patch.shared = false;
  } else if (action === "update") {
    patch.title = str(formData.get("title"));
    patch.category = str(formData.get("category"), "autre");
    patch.term = str(formData.get("term"));
    patch.decision = str(formData.get("decision"));
    patch.notes = str(formData.get("notes"));
    patch.average = str(formData.get("average")) === "" ? null : num(formData.get("average"));
    patch.shared = str(formData.get("shared")) === "on";
    if (status) patch.status = status;
  }

  if (Object.keys(patch).length > 0) {
    await db.update(documents).set(patch).where(eq(documents.id, id));
  }

  refreshAll();
  redirect(redirectTo);
}

export async function deleteDocument(formData: FormData) {
  const id = num(formData.get("documentId"));
  const redirectTo = safeRedirect(formData.get("redirectTo"), "/documents");
  if (id) await db.delete(documents).where(eq(documents.id, id));
  refreshAll();
  redirect(redirectTo);
}
