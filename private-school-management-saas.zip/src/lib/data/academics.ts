import { db } from "@/db";
import {
  assessments,
  attendance,
  classes,
  enrollments,
  grades,
  students,
  subjects,
} from "@/db/schema";
import { and, asc, desc, eq, gte, ne, sql } from "drizzle-orm";
import { requireContext } from "@/lib/data/context";
import { todayISO } from "@/lib/format";

export type SubjectResult = {
  id: number;
  name: string;
  coefficient: number;
  teacher: string;
  classAverage: number | null;
};

export type StudentResult = {
  id: number;
  firstName: string;
  lastName: string;
  matricule: string;
  gender: string;
  average: number | null;
  rank: number | null;
  subjectAverages: Record<number, number | null>;
};

export type ClassResults = {
  subjects: SubjectResult[];
  students: StudentResult[];
  assessmentsCount: number;
  classAverage: number | null;
  successRate: number;
  best: StudentResult | null;
};

export async function computeClassResults(classId: number, term: string): Promise<ClassResults> {
  const [assessmentRows, studentRows, gradeRows] = await Promise.all([
    db
      .select({
        id: assessments.id,
        subjectId: assessments.subjectId,
        coefficient: assessments.coefficient,
        subjectName: subjects.name,
        subjectCoefficient: subjects.coefficient,
        teacher: subjects.teacher,
      })
      .from(assessments)
      .innerJoin(subjects, eq(subjects.id, assessments.subjectId))
      .where(and(eq(assessments.classId, classId), eq(assessments.term, term)))
      .orderBy(asc(subjects.name), asc(assessments.date)),
    db
      .select({
        id: students.id,
        firstName: students.firstName,
        lastName: students.lastName,
        matricule: students.matricule,
        gender: students.gender,
      })
      .from(students)
      .innerJoin(enrollments, eq(enrollments.studentId, students.id))
      .where(eq(enrollments.classId, classId))
      .orderBy(asc(students.lastName), asc(students.firstName)),
    db
      .select({ assessmentId: grades.assessmentId, studentId: grades.studentId, score: grades.score })
      .from(grades)
      .innerJoin(assessments, eq(assessments.id, grades.assessmentId))
      .where(and(eq(assessments.classId, classId), eq(assessments.term, term))),
  ]);

  const subjectMap = new Map<number, SubjectResult & { weighted: number; coefSum: number }>();
  const assessmentMeta = new Map<number, { subjectId: number; coefficient: number }>();
  for (const a of assessmentRows) {
    assessmentMeta.set(a.id, { subjectId: a.subjectId, coefficient: a.coefficient });
    if (!subjectMap.has(a.subjectId)) {
      subjectMap.set(a.subjectId, {
        id: a.subjectId,
        name: a.subjectName,
        coefficient: a.subjectCoefficient,
        teacher: a.teacher,
        classAverage: null,
        weighted: 0,
        coefSum: 0,
      });
    }
  }

  const scoreMap = new Map<string, number>();
  for (const g of gradeRows) {
    if (g.score === null) continue;
    scoreMap.set(`${g.assessmentId}:${g.studentId}`, g.score);
  }

  const subjectWeight = new Map<number, { weighted: number; coefSum: number }>();
  const results: StudentResult[] = studentRows.map((s) => {
    const perSubject = new Map<number, { weighted: number; coefSum: number }>();
    for (const a of assessmentRows) {
      const score = scoreMap.get(`${a.id}:${s.id}`);
      if (score === undefined) continue;
      const bucket = perSubject.get(a.subjectId) ?? { weighted: 0, coefSum: 0 };
      bucket.weighted += score * a.coefficient;
      bucket.coefSum += a.coefficient;
      perSubject.set(a.subjectId, bucket);
    }
    const subjectAverages: Record<number, number | null> = {};
    let weightedTotal = 0;
    let coefficientTotal = 0;
    for (const subj of subjectMap.values()) {
      const bucket = perSubject.get(subj.id);
      const avg = bucket && bucket.coefSum > 0 ? bucket.weighted / bucket.coefSum : null;
      subjectAverages[subj.id] = avg === null ? null : Math.round(avg * 100) / 100;
      if (avg !== null) {
        weightedTotal += avg * subj.coefficient;
        coefficientTotal += subj.coefficient;
        const classBucket = subjectWeight.get(subj.id) ?? { weighted: 0, coefSum: 0 };
        classBucket.weighted += avg;
        classBucket.coefSum += 1;
        subjectWeight.set(subj.id, classBucket);
      }
    }
    return {
      ...s,
      average: coefficientTotal > 0 ? Math.round((weightedTotal / coefficientTotal) * 100) / 100 : null,
      rank: null,
      subjectAverages,
    };
  });

  const ranked = [...results].sort((a, b) => (b.average ?? -1) - (a.average ?? -1));
  ranked.forEach((s, index) => {
    const target = results.find((r) => r.id === s.id);
    if (target) target.rank = s.average === null ? null : index + 1;
  });

  const subjectRows: SubjectResult[] = [...subjectMap.values()].map((s) => {
    const bucket = subjectWeight.get(s.id);
    return {
      id: s.id,
      name: s.name,
      coefficient: s.coefficient,
      teacher: s.teacher,
      classAverage: bucket && bucket.coefSum > 0 ? Math.round((bucket.weighted / bucket.coefSum) * 100) / 100 : null,
    };
  });

  const withAverage = results.filter((r) => r.average !== null);
  const classAverage = withAverage.length
    ? Math.round((withAverage.reduce((sum, r) => sum + (r.average ?? 0), 0) / withAverage.length) * 100) / 100
    : null;

  return {
    subjects: subjectRows,
    students: results,
    assessmentsCount: assessmentRows.length,
    classAverage,
    successRate: withAverage.length
      ? Math.round((withAverage.filter((r) => (r.average ?? 0) >= 10).length / withAverage.length) * 100)
      : 0,
    best: withAverage.length ? withAverage.reduce((best, r) => ((r.average ?? 0) > (best.average ?? 0) ? r : best)) : null,
  };
}

export type GradeMatrix = {
  classId: number;
  subjectId: number;
  term: string;
  assessments: {
    id: number;
    title: string;
    date: string;
    coefficient: number;
    maxScore: number;
  }[];
  students: {
    id: number;
    firstName: string;
    lastName: string;
    matricule: string;
    scores: Record<number, number | null>;
    average: number | null;
  }[];
  stats: { average: number | null; best: number | null; below10: number; filled: number };
};

export async function getGradeMatrix(
  classId: number,
  subjectId: number,
  term: string,
): Promise<GradeMatrix> {
  const [assessmentRows, studentRows, gradeRows] = await Promise.all([
    db
      .select()
      .from(assessments)
      .where(
        and(
          eq(assessments.classId, classId),
          eq(assessments.subjectId, subjectId),
          eq(assessments.term, term),
        ),
      )
      .orderBy(asc(assessments.date)),
    db
      .select({
        id: students.id,
        firstName: students.firstName,
        lastName: students.lastName,
        matricule: students.matricule,
      })
      .from(students)
      .innerJoin(enrollments, eq(enrollments.studentId, students.id))
      .where(eq(enrollments.classId, classId))
      .orderBy(asc(students.lastName), asc(students.firstName)),
    db
      .select({ assessmentId: grades.assessmentId, studentId: grades.studentId, score: grades.score })
      .from(grades)
      .innerJoin(assessments, eq(assessments.id, grades.assessmentId))
      .where(
        and(
          eq(assessments.classId, classId),
          eq(assessments.subjectId, subjectId),
          eq(assessments.term, term),
        ),
      ),
  ]);

  const scoreMap = new Map<string, number>();
  for (const g of gradeRows) if (g.score !== null) scoreMap.set(`${g.assessmentId}:${g.studentId}`, g.score);

  const rows = studentRows.map((s) => {
    const scores: Record<number, number | null> = {};
    let weighted = 0;
    let coefSum = 0;
    for (const a of assessmentRows) {
      const score = scoreMap.get(`${a.id}:${s.id}`) ?? null;
      scores[a.id] = score;
      if (score !== null) {
        weighted += score * a.coefficient;
        coefSum += a.coefficient;
      }
    }
    return { ...s, scores, average: coefSum > 0 ? Math.round((weighted / coefSum) * 100) / 100 : null };
  });

  const evaluated = rows.filter((r) => r.average !== null).map((r) => r.average as number);
  return {
    classId,
    subjectId,
    term,
    assessments: assessmentRows.map((a) => ({
      id: a.id,
      title: a.title,
      date: a.date,
      coefficient: a.coefficient,
      maxScore: a.maxScore,
    })),
    students: rows,
    stats: {
      average: evaluated.length ? Math.round((evaluated.reduce((s, v) => s + v, 0) / evaluated.length) * 100) / 100 : null,
      best: evaluated.length ? Math.max(...evaluated) : null,
      below10: evaluated.filter((v) => v < 10).length,
      filled: gradeRows.filter((g) => g.score !== null).length,
    },
  };
}

export async function getFirstEvaluatedSubject(classId: number, term: string) {
  const [row] = await db
    .select({ subjectId: assessments.subjectId })
    .from(assessments)
    .where(and(eq(assessments.classId, classId), eq(assessments.term, term)))
    .limit(1);
  return row?.subjectId ?? null;
}

export async function getPupilsOfClass(classId: number) {
  return db
    .select({
      id: students.id,
      firstName: students.firstName,
      lastName: students.lastName,
      matricule: students.matricule,
      gender: students.gender,
      birthDate: students.birthDate,
      status: students.status,
    })
    .from(students)
    .innerJoin(enrollments, eq(enrollments.studentId, students.id))
    .where(eq(enrollments.classId, classId))
    .orderBy(asc(students.lastName), asc(students.firstName));
}

export async function getAttendancePageData(params: { classId?: string; date?: string }) {
  const { school } = await requireContext();
  const classRows = await db
    .select()
    .from(classes)
    .where(eq(classes.schoolId, school.id))
    .orderBy(asc(classes.id));
  const selectedClass =
    classRows.find((c) => String(c.id) === params.classId) ?? classRows[0] ?? null;
  const date = params.date && /^\d{4}-\d{2}-\d{2}$/.test(params.date) ? params.date : todayISO();

  if (!selectedClass) {
    return { classRows, selectedClass, date, pupils: [], summary: null, recentAbsences: [], trend: [], saved: false };
  }

  const [pupilRows, recentAbsences, trend] = await Promise.all([
    db
      .select({
        id: students.id,
        firstName: students.firstName,
        lastName: students.lastName,
        matricule: students.matricule,
        gender: students.gender,
        status: attendance.status,
        note: attendance.note,
      })
      .from(students)
      .innerJoin(enrollments, eq(enrollments.studentId, students.id))
      .leftJoin(
        attendance,
        and(
          eq(attendance.studentId, students.id),
          eq(attendance.classId, selectedClass.id),
          eq(attendance.date, date),
        ),
      )
      .where(eq(enrollments.classId, selectedClass.id))
      .orderBy(asc(students.lastName), asc(students.firstName)),
    db
      .select({
        studentId: students.id,
        firstName: students.firstName,
        lastName: students.lastName,
        date: attendance.date,
        status: attendance.status,
        className: classes.name,
        classNameShort: classes.name,
        guardianPhone: sql<string>`coalesce((select g.phone from guardians g where g.student_id = ${students.id} order by g.is_primary desc limit 1), '')`,
      })
      .from(attendance)
      .innerJoin(students, eq(students.id, attendance.studentId))
      .innerJoin(classes, eq(classes.id, attendance.classId))
      .where(and(eq(classes.schoolId, school.id), ne(attendance.status, "présent")))
      .orderBy(desc(attendance.date), asc(students.lastName))
      .limit(8),
    db
      .select({
        date: attendance.date,
        present: sql<string>`sum(case when ${attendance.status} in ('présent','retard') then 1 else 0 end)`,
        total: sql<string>`count(*)`,
      })
      .from(attendance)
      .where(eq(attendance.classId, selectedClass.id))
      .groupBy(attendance.date)
      .orderBy(desc(attendance.date))
      .limit(8),
  ]);

  const pupils = pupilRows.map((p) => ({ ...p, status: p.status ?? "présent" }));
  const count = (status: string) => pupils.filter((p) => p.status === status).length;

  return {
    classRows,
    selectedClass,
    date,
    pupils,
    saved: pupilRows.some((p) => p.status !== null),
    summary: {
      total: pupils.length,
      présent: count("présent"),
      absent: count("absent"),
      retard: count("retard"),
      excusé: count("excusé"),
    },
    recentAbsences,
    trend: trend.map((t) => ({
      date: t.date,
      rate: Number(t.total) ? Math.round((Number(t.present) / Number(t.total)) * 100) : 0,
      total: Number(t.total),
    })),
  };
}

export async function getSubjects() {
  const { school } = await requireContext();
  return db
    .select({
      id: subjects.id,
      name: subjects.name,
      code: subjects.code,
      cycle: subjects.cycle,
      coefficient: subjects.coefficient,
      teacher: subjects.teacher,
      assessmentsCount: sql<string>`(select count(*) from assessments where assessments.subject_id = ${subjects.id})`,
    })
    .from(subjects)
    .where(eq(subjects.schoolId, school.id))
    .orderBy(asc(subjects.name));
}

export async function getRecentAttendanceRate() {
  const { school } = await requireContext();
  const [row] = await db
    .select({
      rate: sql<string>`coalesce(round(100.0 * sum(case when ${attendance.status} in ('présent','retard') then 1 else 0 end) / nullif(count(*), 0)), 0)`,
      date: sql<string>`max(${attendance.date})`,
      total: sql<string>`count(*)`,
    })
    .from(attendance)
    .innerJoin(classes, eq(classes.id, attendance.classId))
    .where(and(eq(classes.schoolId, school.id), gte(attendance.date, sql`current_date - 7`)));
  return { rate: Number(row?.rate ?? 0), total: Number(row?.total ?? 0), date: row?.date ?? null };
}
