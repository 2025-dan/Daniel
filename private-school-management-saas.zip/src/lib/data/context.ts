import { db } from "@/db";
import { academicYears, classes, schools } from "@/db/schema";
import { asc, eq, sql } from "drizzle-orm";

export type School = typeof schools.$inferSelect;
export type AcademicYear = typeof academicYears.$inferSelect;

export type AppContext = { school: School; year: AcademicYear };

export async function getContext(): Promise<AppContext | null> {
  const [school] = await db.select().from(schools).orderBy(asc(schools.id)).limit(1);
  if (!school) return null;
  const years = await db
    .select()
    .from(academicYears)
    .where(eq(academicYears.schoolId, school.id))
    .orderBy(asc(academicYears.startDate));
  const year = years.find((y) => y.isCurrent) ?? years[years.length - 1];
  if (!year) return null;
  return { school, year };
}

export async function requireContext(): Promise<AppContext> {
  const ctx = await getContext();
  if (!ctx) throw new Error("Aucun établissement configuré. Lancez le script de démonstration.");
  return ctx;
}

export type ClassSummary = {
  id: number;
  name: string;
  level: string;
  cycle: string;
  capacity: number;
  room: string;
  mainTeacher: string;
  monthlyFee: number;
  studentCount: number;
  attendanceRate: number;
};

export async function getClassSummaries(): Promise<ClassSummary[]> {
  const { school } = await requireContext();
  const rows = await db
    .select({
      id: classes.id,
      name: classes.name,
      level: classes.level,
      cycle: classes.cycle,
      capacity: classes.capacity,
      room: classes.room,
      mainTeacher: classes.mainTeacher,
      monthlyFee: classes.monthlyFee,
      studentCount: sql<string>`(select count(*) from enrollments where enrollments.class_id = ${classes.id})`,
      attendanceRate: sql<string>`coalesce((
        select round(100.0 * sum(case when a.status in ('présent','retard') then 1 else 0 end) / nullif(count(*), 0))
        from attendance a where a.class_id = ${classes.id} and a.date >= current_date - 30
      ), 0)`,
    })
    .from(classes)
    .where(eq(classes.schoolId, school.id))
    .orderBy(asc(classes.id));

  return rows.map((r) => ({
    ...r,
    studentCount: Number(r.studentCount),
    attendanceRate: Number(r.attendanceRate),
  }));
}

export async function getAcademicYears() {
  const { school } = await requireContext();
  return db
    .select()
    .from(academicYears)
    .where(eq(academicYears.schoolId, school.id))
    .orderBy(asc(academicYears.startDate));
}

export async function getClassById(id: number) {
  const { school } = await requireContext();
  const [row] = await db
    .select()
    .from(classes)
    .where(eq(classes.id, id))
    .limit(1);
  if (!row || row.schoolId !== school.id) return null;
  return row;
}
