import { db } from "@/db";
import { payrolls, staff } from "@/db/schema";
import { and, asc, desc, eq, sql } from "drizzle-orm";
import { requireContext } from "@/lib/data/context";

export function currentPeriod(offset = 0): string {
  const d = new Date();
  d.setDate(1);
  d.setMonth(d.getMonth() + offset);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function periodLabel(period: string): string {
  const [year, month] = period.split("-").map(Number);
  if (!year || !month) return period;
  const label = new Intl.DateTimeFormat("fr-FR", { month: "long", year: "numeric" }).format(
    new Date(year, month - 1, 1),
  );
  return label.charAt(0).toUpperCase() + label.slice(1);
}

export async function getStaffPageData() {
  const { school } = await requireContext();
  const [rows, payrollAgg] = await Promise.all([
    db
      .select({
        id: staff.id,
        firstName: staff.firstName,
        lastName: staff.lastName,
        jobTitle: staff.jobTitle,
        category: staff.category,
        phone: staff.phone,
        email: staff.email,
        qualification: staff.qualification,
        hireDate: staff.hireDate,
        monthlySalary: staff.monthlySalary,
        status: staff.status,
        lastPaid: sql<string | null>`(select max(p.period) from payrolls p where p.staff_id = ${staff.id} and p.status = 'payé')`,
        unpaidCount: sql<string>`(select count(*) from payrolls p where p.staff_id = ${staff.id} and p.status = 'en attente')`,
      })
      .from(staff)
      .where(eq(staff.schoolId, school.id))
      .orderBy(asc(staff.category), asc(staff.lastName)),
    db
      .select({
        total: sql<string>`count(*)`,
        active: sql<string>`count(*) filter (where ${staff.status} = 'actif')`,
        payroll: sql<string>`coalesce(sum(${staff.monthlySalary}), 0)`,
        teaching: sql<string>`count(*) filter (where ${staff.category} = 'enseignement')`,
        pending: sql<string>`(select count(*) from payrolls p where p.school_id = ${school.id} and p.status = 'en attente')`,
        pendingAmount: sql<string>`(select coalesce(sum(p.net_salary),0) from payrolls p where p.school_id = ${school.id} and p.status = 'en attente')`,
      })
      .from(staff)
      .where(eq(staff.schoolId, school.id)),
  ]);

  return {
    staff: rows,
    stats: {
      total: Number(payrollAgg[0]?.total ?? 0),
      active: Number(payrollAgg[0]?.active ?? 0),
      payroll: Number(payrollAgg[0]?.payroll ?? 0),
      teaching: Number(payrollAgg[0]?.teaching ?? 0),
      pending: Number(payrollAgg[0]?.pending ?? 0),
      pendingAmount: Number(payrollAgg[0]?.pendingAmount ?? 0),
    },
  };
}

export async function getPayrollPageData(period?: string) {
  const { school } = await requireContext();
  const selectedPeriod = period && /^\d{4}-\d{2}$/.test(period) ? period : currentPeriod();

  const [rows, staffRows, periods, totals] = await Promise.all([
    db
      .select({
        id: payrolls.id,
        period: payrolls.period,
        grossSalary: payrolls.grossSalary,
        bonuses: payrolls.bonuses,
        deductions: payrolls.deductions,
        netSalary: payrolls.netSalary,
        status: payrolls.status,
        method: payrolls.method,
        paidAt: payrolls.paidAt,
        reference: payrolls.reference,
        staffId: staff.id,
        firstName: staff.firstName,
        lastName: staff.lastName,
        jobTitle: staff.jobTitle,
        category: staff.category,
      })
      .from(payrolls)
      .innerJoin(staff, eq(staff.id, payrolls.staffId))
      .where(and(eq(payrolls.schoolId, school.id), eq(payrolls.period, selectedPeriod)))
      .orderBy(asc(staff.lastName)),
    db.select().from(staff).where(eq(staff.schoolId, school.id)).orderBy(asc(staff.lastName)),
    db
      .select({ period: payrolls.period })
      .from(payrolls)
      .where(eq(payrolls.schoolId, school.id))
      .groupBy(payrolls.period)
      .orderBy(desc(payrolls.period))
      .limit(12),
    db
      .select({
        gross: sql<string>`coalesce(sum(${payrolls.grossSalary}), 0)`,
        bonuses: sql<string>`coalesce(sum(${payrolls.bonuses}), 0)`,
        deductions: sql<string>`coalesce(sum(${payrolls.deductions}), 0)`,
        net: sql<string>`coalesce(sum(${payrolls.netSalary}), 0)`,
        paid: sql<string>`coalesce(sum(${payrolls.netSalary}) filter (where ${payrolls.status} = 'payé'), 0)`,
        pending: sql<string>`coalesce(sum(${payrolls.netSalary}) filter (where ${payrolls.status} = 'en attente'), 0)`,
        count: sql<string>`count(*)`,
        paidCount: sql<string>`count(*) filter (where ${payrolls.status} = 'payé')`,
      })
      .from(payrolls)
      .where(and(eq(payrolls.schoolId, school.id), eq(payrolls.period, selectedPeriod))),
  ]);

  const activeStaff = staffRows.filter((s) => s.status !== "inactif");
  const notGenerated = activeStaff.filter((s) => !rows.some((r) => r.staffId === s.id));

  return {
    period: selectedPeriod,
    payrolls: rows,
    staff: staffRows,
    activeStaffCount: activeStaff.length,
    missing: notGenerated,
    periods: periods.map((p) => p.period),
    totals: {
      gross: Number(totals[0]?.gross ?? 0),
      bonuses: Number(totals[0]?.bonuses ?? 0),
      deductions: Number(totals[0]?.deductions ?? 0),
      net: Number(totals[0]?.net ?? 0),
      paid: Number(totals[0]?.paid ?? 0),
      pending: Number(totals[0]?.pending ?? 0),
      count: Number(totals[0]?.count ?? 0),
      paidCount: Number(totals[0]?.paidCount ?? 0),
    },
  };
}
