import { cookies } from "next/headers";
import { db } from "@/db";
import { classes, enrollments, invoices, lessonLogs, messages, subjects, students, attendance } from "@/db/schema";
import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { requireContext } from "@/lib/data/context";
import { computeClassResults } from "@/lib/data/academics";
import { getSharedDocuments } from "@/lib/data/documents";
import { getClassTimetable } from "@/lib/data/school-life";
import type { AcademicYear } from "@/lib/data/context";


export const PARENT_COOKIE = "scolaris_parent";

export async function getParentStudentId(): Promise<number | null> {
  const store = await cookies();
  const raw = store.get(PARENT_COOKIE)?.value;
  const id = Number(raw);
  return Number.isFinite(id) && id > 0 ? id : null;
}

export async function findStudentByMatricule(matricule: string) {
  const value = matricule.trim().toUpperCase();
  if (!value) return null;
  const [row] = await db
    .select({ id: students.id, firstName: students.firstName, lastName: students.lastName, matricule: students.matricule })
    .from(students)
    .where(sql`upper(${students.matricule}) = ${value}`)
    .limit(1);
  return row ?? null;
}

export async function getParentPortalData(studentId: number) {
  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) return null;
  const ctx = await requireContext();
  const year: AcademicYear = ctx.year;
  const school = ctx.school;

  const [enrollment] = await db
    .select({
      classId: classes.id,
      className: classes.name,
      cycle: classes.cycle,
      teacher: classes.mainTeacher,
      room: classes.room,
      monthlyFee: classes.monthlyFee,
    })
    .from(enrollments)
    .innerJoin(classes, eq(classes.id, enrollments.classId))
    .where(and(eq(enrollments.studentId, student.id), eq(enrollments.academicYearId, year.id)))
    .limit(1);

  if (!enrollment) {
    return {
      school,
      year,
      student,
      enrollment: null,
      invoices: [],
      payments: [],
      results: null,
      myResult: null,
      attendanceRate: 0,
      absences: 0,
      timetable: [],
      homework: [],
      messages: [],
      sharedDocuments: [],
      finance: { invoiced: 0, paid: 0, balance: 0 },
    };
  }

  const [invoiceRows, attendanceRows, timetable, homework, classResults] = await Promise.all([
    db.select().from(invoices).where(eq(invoices.studentId, student.id)).orderBy(asc(invoices.dueDate)),
    db
      .select({ status: attendance.status, total: sql<string>`count(*)` })
      .from(attendance)
      .where(eq(attendance.studentId, student.id))
      .groupBy(attendance.status),
    getClassTimetable(enrollment.classId),
    db
      .select({
        id: lessonLogs.id,
        title: lessonLogs.title,
        homework: lessonLogs.homework,
        dueDate: lessonLogs.dueDate,
        date: lessonLogs.date,
        subjectName: subjects.name,
      })
      .from(lessonLogs)
      .leftJoin(subjects, eq(subjects.id, lessonLogs.subjectId))
      .where(and(eq(lessonLogs.classId, enrollment.classId), sql`${lessonLogs.homework} <> ''`))
      .orderBy(desc(lessonLogs.date))
      .limit(6),
    computeClassResults(enrollment.classId, "Trimestre 1"),
  ]);

  const messageRows = await db
    .select()
    .from(messages)
    .where(
      and(
        eq(messages.schoolId, school.id),
        eq(messages.status, "envoyé"),
        sql`(${messages.audience} = 'tous' or (${messages.audience} = 'classe' and ${messages.classId} = ${enrollment.classId}) or (${messages.audience} = 'parent' and ${messages.studentId} = ${student.id}))`,
      ),
    )
    .orderBy(desc(messages.sentAt))
    .limit(6);

  const sharedDocuments = await getSharedDocuments(student.id, 10);
  const invoiced = invoiceRows.reduce((sum, i) => sum + i.amount, 0);
  const paid = invoiceRows.reduce((sum, i) => sum + i.amountPaid, 0);
  const attendanceTotal = attendanceRows.reduce((sum, a) => sum + Number(a.total), 0);
  const present = attendanceRows
    .filter((a) => a.status === "présent" || a.status === "retard")
    .reduce((sum, a) => sum + Number(a.total), 0);

  return {
    school,
    year,
    student,
    enrollment,
    invoices: invoiceRows,
    results: classResults,
    myResult: classResults.students.find((s) => s.id === student.id) ?? null,
    attendanceRate: attendanceTotal ? Math.round((present / attendanceTotal) * 100) : 0,
    absences: attendanceRows.filter((a) => a.status === "absent").reduce((s, a) => s + Number(a.total), 0),
    timetable,
    homework,
    messages: messageRows,
    sharedDocuments,
    finance: { invoiced, paid, balance: invoiced - paid },
  };
}

export type ParentPortalData = NonNullable<Awaited<ReturnType<typeof getParentPortalData>>>;

export async function getParentStudentOptions(limit = 8) {
  return db
    .select({
      id: students.id,
      firstName: students.firstName,
      lastName: students.lastName,
      matricule: students.matricule,
      className: classes.name,
    })
    .from(students)
    .leftJoin(enrollments, eq(enrollments.studentId, students.id))
    .leftJoin(classes, eq(classes.id, enrollments.classId))
    .where(eq(students.status, "actif"))
    .orderBy(asc(students.id))
    .limit(limit);
}

export function invoiceStatusTone(status: string) {
  const map: Record<string, string> = {
    payée: "bg-brand-100 text-brand-800",
    partielle: "bg-amber-100 text-amber-800",
    impayée: "bg-red-100 text-red-700",
  };
  return map[status] ?? "bg-ink/10 text-ink/60";
}

export async function getParentAttendanceBreakdown(studentId: number) {
  return db
    .select({ status: attendance.status, total: sql<string>`count(*)` })
    .from(attendance)
    .where(eq(attendance.studentId, studentId))
    .groupBy(attendance.status);
}

export async function getParentInvoice(studentId: number, invoiceId: number) {
  const [row] = await db
    .select()
    .from(invoices)
    .where(and(eq(invoices.id, invoiceId), eq(invoices.studentId, studentId)))
    .limit(1);
  return row ?? null;
}

export async function getStudentsForIds(ids: number[]) {
  if (ids.length === 0) return [];
  return db.select().from(students).where(inArray(students.id, ids));
}
