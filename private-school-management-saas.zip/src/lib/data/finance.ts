import { db } from "@/db";
import {
  classes,
  enrollments,
  feeStructures,
  invoices,
  payments,
  reminders,
  students,
} from "@/db/schema";
import { and, asc, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { requireContext } from "@/lib/data/context";
import { monthKey, monthShort } from "@/lib/format";

export type InvoiceRow = {
  id: number;
  number: string;
  label: string;
  amount: number;
  amountPaid: number;
  dueDate: string;
  status: string;
  studentId: number;
  firstName: string;
  lastName: string;
  matricule: string;
  className: string | null;
};

export type PaymentRow = {
  id: number;
  amount: number;
  method: string;
  reference: string;
  paidAt: string;
  recordedBy: string;
  invoiceId: number | null;
  studentId: number;
  firstName: string;
  lastName: string;
  invoiceNumber: string | null;
  invoiceLabel: string | null;
};

export type FinanceTotals = {
  invoiced: number;
  paid: number;
  balance: number;
  invoiceCount: number;
  unpaidCount: number;
  overdueAmount: number;
  overdueCount: number;
  recoveryRate: number;
  collected30: number;
  remindersCount: number;
};

export async function getFinanceTotals(): Promise<FinanceTotals> {
  const { school } = await requireContext();
  const [invoiceAgg] = await db
    .select({
      invoiced: sql<string>`coalesce(sum(${invoices.amount}), 0)`,
      paid: sql<string>`coalesce(sum(${invoices.amountPaid}), 0)`,
      invoiceCount: sql<string>`count(*)`,
      unpaidCount: sql<string>`count(*) filter (where ${invoices.status} in ('impayée','partielle'))`,
      overdueAmount: sql<string>`coalesce(sum(${invoices.amount} - ${invoices.amountPaid}) filter (where ${invoices.status} in ('impayée','partielle') and ${invoices.dueDate} < current_date), 0)`,
      overdueCount: sql<string>`count(*) filter (where ${invoices.status} in ('impayée','partielle') and ${invoices.dueDate} < current_date)`,
    })
    .from(invoices)
    .where(eq(invoices.schoolId, school.id));

  const [paymentAgg] = await db
    .select({
      collected30: sql<string>`coalesce(sum(${payments.amount}) filter (where ${payments.paidAt} >= current_date - 30), 0)`,
    })
    .from(payments)
    .where(eq(payments.schoolId, school.id));

  const [reminderAgg] = await db
    .select({ count: sql<string>`count(*)` })
    .from(reminders)
    .where(sql`${reminders.sentAt} >= current_date - 30`);

  const invoiced = Number(invoiceAgg?.invoiced ?? 0);
  const paid = Number(invoiceAgg?.paid ?? 0);

  return {
    invoiced,
    paid,
    balance: invoiced - paid,
    invoiceCount: Number(invoiceAgg?.invoiceCount ?? 0),
    unpaidCount: Number(invoiceAgg?.unpaidCount ?? 0),
    overdueAmount: Number(invoiceAgg?.overdueAmount ?? 0),
    overdueCount: Number(invoiceAgg?.overdueCount ?? 0),
    recoveryRate: invoiced ? Math.round((paid / invoiced) * 100) : 0,
    collected30: Number(paymentAgg?.collected30 ?? 0),
    remindersCount: Number(reminderAgg?.count ?? 0),
  };
}

export async function getInvoiceRows(filters: { q?: string; statut?: string } = {}): Promise<InvoiceRow[]> {
  const { school, year } = await requireContext();
  const q = filters.q?.trim();
  const statut = filters.statut;
  const textFilter: SQL | undefined = q
    ? or(
        ilike(students.firstName, `%${q}%`),
        ilike(students.lastName, `%${q}%`),
        ilike(invoices.number, `%${q}%`),
        ilike(invoices.label, `%${q}%`),
      )
    : undefined;
  const statusFilter: SQL | undefined =
    statut === "impayées"
      ? sql`${invoices.status} in ('impayée','partielle')`
      : statut === "retard"
        ? sql`${invoices.status} in ('impayée','partielle') and ${invoices.dueDate} < current_date`
        : statut && statut !== "toutes"
          ? eq(invoices.status, statut)
          : undefined;

  const rows = await db
    .select({
      id: invoices.id,
      number: invoices.number,
      label: invoices.label,
      amount: invoices.amount,
      amountPaid: invoices.amountPaid,
      dueDate: invoices.dueDate,
      status: invoices.status,
      studentId: invoices.studentId,
      firstName: students.firstName,
      lastName: students.lastName,
      matricule: students.matricule,
      className: classes.name,
    })
    .from(invoices)
    .innerJoin(students, eq(students.id, invoices.studentId))
    .leftJoin(
      enrollments,
      and(eq(enrollments.studentId, students.id), eq(enrollments.academicYearId, year.id)),
    )
    .leftJoin(classes, eq(classes.id, enrollments.classId))
    .where(and(eq(invoices.schoolId, school.id), textFilter, statusFilter))
    .orderBy(asc(invoices.dueDate), desc(invoices.id))
    .limit(120);

  return rows;
}

export async function getRecentPayments(limit = 12): Promise<PaymentRow[]> {
  const { school } = await requireContext();
  return db
    .select({
      id: payments.id,
      amount: payments.amount,
      method: payments.method,
      reference: payments.reference,
      paidAt: payments.paidAt,
      recordedBy: payments.recordedBy,
      invoiceId: payments.invoiceId,
      studentId: payments.studentId,
      firstName: students.firstName,
      lastName: students.lastName,
      invoiceNumber: invoices.number,
      invoiceLabel: invoices.label,
    })
    .from(payments)
    .innerJoin(students, eq(students.id, payments.studentId))
    .leftJoin(invoices, eq(invoices.id, payments.invoiceId))
    .where(eq(payments.schoolId, school.id))
    .orderBy(desc(payments.paidAt), desc(payments.id))
    .limit(limit);
}

export async function getUnpaidInvoiceOptions(studentId?: number) {
  const { school } = await requireContext();
  return db
    .select({
      id: invoices.id,
      number: invoices.number,
      label: invoices.label,
      amount: invoices.amount,
      amountPaid: invoices.amountPaid,
      dueDate: invoices.dueDate,
      status: invoices.status,
      firstName: students.firstName,
      lastName: students.lastName,
      studentId: students.id,
    })
    .from(invoices)
    .innerJoin(students, eq(students.id, invoices.studentId))
    .where(
      and(
        eq(invoices.schoolId, school.id),
        sql`${invoices.amountPaid} < ${invoices.amount}`,
        studentId ? eq(invoices.studentId, studentId) : undefined,
      ),
    )
    .orderBy(asc(invoices.dueDate))
    .limit(300);
}

export async function getMonthlyCollections(months = 6) {
  const { school } = await requireContext();
  const rows = await db
    .select({
      month: sql<string>`to_char(${payments.paidAt}, 'YYYY-MM')`,
      total: sql<string>`sum(${payments.amount})`,
    })
    .from(payments)
    .where(
      and(
        eq(payments.schoolId, school.id),
        sql`${payments.paidAt} >= (current_date - interval '6 months')`,
      ),
    )
    .groupBy(sql`to_char(${payments.paidAt}, 'YYYY-MM')`);

  const byMonth = new Map(rows.map((r) => [r.month, Number(r.total)]));
  const series: { key: string; label: string; value: number }[] = [];
  const now = new Date();
  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const key = monthKey(d);
    series.push({ key, label: monthShort(key), value: byMonth.get(key) ?? 0 });
  }
  return series;
}

export async function getPaymentMethodBreakdown() {
  const { school } = await requireContext();
  const rows = await db
    .select({
      method: payments.method,
      total: sql<string>`sum(${payments.amount})`,
      count: sql<string>`count(*)`,
    })
    .from(payments)
    .where(eq(payments.schoolId, school.id))
    .groupBy(payments.method)
    .orderBy(desc(sql`sum(${payments.amount})`));
  return rows.map((r) => ({ method: r.method, total: Number(r.total), count: Number(r.count) }));
}

export async function getReminders(limit = 6) {
  return db
    .select({
      id: reminders.id,
      channel: reminders.channel,
      message: reminders.message,
      sentAt: reminders.sentAt,
      invoiceId: reminders.invoiceId,
      firstName: students.firstName,
      lastName: students.lastName,
      amount: invoices.amount,
      amountPaid: invoices.amountPaid,
      number: invoices.number,
    })
    .from(reminders)
    .innerJoin(students, eq(students.id, reminders.studentId))
    .innerJoin(invoices, eq(invoices.id, reminders.invoiceId))
    .orderBy(desc(reminders.sentAt))
    .limit(limit);
}

export async function getFeeStructures() {
  const { school, year } = await requireContext();
  return db
    .select()
    .from(feeStructures)
    .where(and(eq(feeStructures.schoolId, school.id), eq(feeStructures.academicYearId, year.id)))
    .orderBy(asc(feeStructures.level), asc(feeStructures.type));
}

export async function getPaymentCount() {
  const { school } = await requireContext();
  const [row] = await db
    .select({ count: sql<string>`count(*)` })
    .from(payments)
    .where(eq(payments.schoolId, school.id));
  return Number(row?.count ?? 0);
}
