import { db } from "@/db";
import { classes, exams, lessonLogs, subjects, timetableSlots } from "@/db/schema";
import { and, asc, desc, eq, gte, sql } from "drizzle-orm";
import { requireContext, getClassSummaries } from "@/lib/data/context";

export const DAYS = [
  { value: 1, label: "Lundi", short: "Lun" },
  { value: 2, label: "Mardi", short: "Mar" },
  { value: 3, label: "Mercredi", short: "Mer" },
  { value: 4, label: "Jeudi", short: "Jeu" },
  { value: 5, label: "Vendredi", short: "Ven" },
  { value: 6, label: "Samedi", short: "Sam" },
];

export const TIME_SLOTS = [
  { start: "07:30", end: "08:25" },
  { start: "08:25", end: "09:20" },
  { start: "09:20", end: "10:15" },
  { start: "10:30", end: "11:25" },
  { start: "11:25", end: "12:20" },
  { start: "15:00", end: "15:55" },
];

export type TimetableRow = {
  id: number;
  day: number;
  startTime: string;
  endTime: string;
  subjectName: string | null;
  subjectCode: string | null;
  teacher: string;
  room: string;
};

export async function getTimetablePageData(classId?: string) {
  const { school } = await requireContext();
  const [classRows, subjectRows] = await Promise.all([
    getClassSummaries(),
    db
      .select({ id: subjects.id, name: subjects.name, code: subjects.code, cycle: subjects.cycle, teacher: subjects.teacher })
      .from(subjects)
      .where(eq(subjects.schoolId, school.id))
      .orderBy(asc(subjects.name)),
  ]);
  const selectedClass = classRows.find((c) => String(c.id) === classId) ?? classRows[0] ?? null;

  let slots: TimetableRow[] = [];
  if (selectedClass) {
    slots = await db
      .select({
        id: timetableSlots.id,
        day: timetableSlots.day,
        startTime: timetableSlots.startTime,
        endTime: timetableSlots.endTime,
        subjectName: subjects.name,
        subjectCode: subjects.code,
        teacher: timetableSlots.teacher,
        room: timetableSlots.room,
      })
      .from(timetableSlots)
      .leftJoin(subjects, eq(subjects.id, timetableSlots.subjectId))
      .where(eq(timetableSlots.classId, selectedClass.id))
      .orderBy(asc(timetableSlots.day), asc(timetableSlots.startTime));
  }

  return { classRows, subjectRows, selectedClass, slots };
}

export async function getLessonLogs(filters: { classId?: string; subjectId?: string } = {}) {
  const { school } = await requireContext();
  const rows = await db
    .select({
      id: lessonLogs.id,
      date: lessonLogs.date,
      title: lessonLogs.title,
      content: lessonLogs.content,
      homework: lessonLogs.homework,
      dueDate: lessonLogs.dueDate,
      teacher: lessonLogs.teacher,
      classId: classes.id,
      className: classes.name,
      subjectId: subjects.id,
      subjectName: subjects.name,
    })
    .from(lessonLogs)
    .innerJoin(classes, eq(classes.id, lessonLogs.classId))
    .leftJoin(subjects, eq(subjects.id, lessonLogs.subjectId))
    .where(
      and(
        eq(lessonLogs.schoolId, school.id),
        filters.classId ? eq(lessonLogs.classId, Number(filters.classId)) : undefined,
        filters.subjectId ? eq(lessonLogs.subjectId, Number(filters.subjectId)) : undefined,
      ),
    )
    .orderBy(desc(lessonLogs.date), desc(lessonLogs.id))
    .limit(60);
  return rows;
}

export async function getLessonsPageData(filters: { classId?: string; subjectId?: string }) {
  const { school } = await requireContext();
  const [logs, classRows, subjectRows, homeworkCount] = await Promise.all([
    getLessonLogs(filters),
    getClassSummaries(),
    db
      .select({ id: subjects.id, name: subjects.name })
      .from(subjects)
      .where(eq(subjects.schoolId, school.id))
      .orderBy(asc(subjects.name)),
    db
      .select({ count: sql<string>`count(*)` })
      .from(lessonLogs)
      .where(and(eq(lessonLogs.schoolId, school.id), sql`${lessonLogs.homework} <> ''`)),
  ]);
  return { logs, classRows, subjectRows, homeworkTotal: Number(homeworkCount[0]?.count ?? 0) };
}

export type ExamRow = {
  id: number;
  title: string;
  date: string;
  startTime: string;
  duration: number;
  room: string;
  supervisor: string;
  status: string;
  term: string;
  classId: number;
  className: string;
  subjectName: string | null;
};

export async function getExamsPageData(filters: { classId?: string; term?: string } = {}) {
  const { school } = await requireContext();
  const classRows = await getClassSummaries();
  const selectedClass = classRows.find((c) => String(c.id) === filters.classId) ?? null;
  const term = filters.term ?? "";

  const rows = await db
    .select({
      id: exams.id,
      title: exams.title,
      date: exams.date,
      startTime: exams.startTime,
      duration: exams.duration,
      room: exams.room,
      supervisor: exams.supervisor,
      status: exams.status,
      term: exams.term,
      classId: classes.id,
      className: classes.name,
      subjectName: subjects.name,
    })
    .from(exams)
    .innerJoin(classes, eq(classes.id, exams.classId))
    .leftJoin(subjects, eq(subjects.id, exams.subjectId))
    .where(
      and(
        eq(exams.schoolId, school.id),
        selectedClass ? eq(exams.classId, selectedClass.id) : undefined,
        term ? eq(exams.term, term) : undefined,
      ),
    )
    .orderBy(asc(exams.date), asc(exams.startTime))
    .limit(80);

  const [subjectRows, stats] = await Promise.all([
    db
      .select({ id: subjects.id, name: subjects.name })
      .from(subjects)
      .where(eq(subjects.schoolId, school.id))
      .orderBy(asc(subjects.name)),
    db
      .select({
        total: sql<string>`count(*)`,
        planned: sql<string>`count(*) filter (where ${exams.status} = 'planifié')`,
        done: sql<string>`count(*) filter (where ${exams.status} = 'terminé')`,
        upcoming: sql<string>`count(*) filter (where ${exams.date} >= current_date and ${exams.status} = 'planifié')`,
      })
      .from(exams)
      .where(eq(exams.schoolId, school.id)),
  ]);

  return {
    classRows,
    subjectRows,
    selectedClass,
    term,
    exams: rows,
    stats: {
      total: Number(stats[0]?.total ?? 0),
      planned: Number(stats[0]?.planned ?? 0),
      done: Number(stats[0]?.done ?? 0),
      upcoming: Number(stats[0]?.upcoming ?? 0),
    },
  };
}

export async function getNextExams(limit = 4) {
  const { school } = await requireContext();
  return db
    .select({
      id: exams.id,
      title: exams.title,
      date: exams.date,
      startTime: exams.startTime,
      room: exams.room,
      className: classes.name,
      subjectName: subjects.name,
      duration: exams.duration,
    })
    .from(exams)
    .innerJoin(classes, eq(classes.id, exams.classId))
    .leftJoin(subjects, eq(subjects.id, exams.subjectId))
    .where(and(eq(exams.schoolId, school.id), gte(exams.date, sql`current_date`)))
    .orderBy(asc(exams.date))
    .limit(limit);
}

export async function getClassTimetable(classId: number) {
  return db
    .select({
      id: timetableSlots.id,
      day: timetableSlots.day,
      startTime: timetableSlots.startTime,
      endTime: timetableSlots.endTime,
      room: timetableSlots.room,
      teacher: timetableSlots.teacher,
      subjectName: subjects.name,
    })
    .from(timetableSlots)
    .leftJoin(subjects, eq(subjects.id, timetableSlots.subjectId))
    .where(eq(timetableSlots.classId, classId))
    .orderBy(asc(timetableSlots.day), asc(timetableSlots.startTime));
}

export async function getClassHomework(classId: number, limit = 5) {
  return db
    .select({
      id: lessonLogs.id,
      title: lessonLogs.title,
      homework: lessonLogs.homework,
      dueDate: lessonLogs.dueDate,
      date: lessonLogs.date,
      subjectName: subjects.name,
    })
    .from(lessonLogs)
    .leftJoin(subjects, eq(subjects.id, lessonLogs.subjectId))
    .where(and(eq(lessonLogs.classId, classId), sql`${lessonLogs.homework} <> ''`))
    .orderBy(desc(lessonLogs.date))
    .limit(limit);
}
