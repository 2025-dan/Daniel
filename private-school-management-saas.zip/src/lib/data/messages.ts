import { db } from "@/db";
import { classes, messages, students } from "@/db/schema";
import { asc, desc, eq, sql } from "drizzle-orm";
import { requireContext } from "@/lib/data/context";
import { getReminders } from "@/lib/data/finance";

export async function getMessagesPageData() {
  const { school } = await requireContext();
  const [messageRows, classRows, reminderRows, aggregates, pupils] = await Promise.all([
    db
      .select()
      .from(messages)
      .where(eq(messages.schoolId, school.id))
      .orderBy(desc(messages.sentAt), desc(messages.id))
      .limit(30),
    db.select().from(classes).where(eq(classes.schoolId, school.id)).orderBy(asc(classes.id)),
    getReminders(5),
    db
      .select({
        sent: sql<string>`count(*) filter (where ${messages.status} = 'envoyé')`,
        recipients: sql<string>`coalesce(sum(${messages.recipientsCount}), 0)`,
        drafts: sql<string>`count(*) filter (where ${messages.status} = 'brouillon')`,
      })
      .from(messages)
      .where(eq(messages.schoolId, school.id)),
    db
      .select({
        id: students.id,
        firstName: students.firstName,
        lastName: students.lastName,
        matricule: students.matricule,
      })
      .from(students)
      .where(eq(students.schoolId, school.id))
      .orderBy(asc(students.lastName)),
  ]);

  return {
    messages: messageRows,
    classes: classRows,
    reminders: reminderRows,
    pupils,
    stats: {
      sent: Number(aggregates[0]?.sent ?? 0),
      recipients: Number(aggregates[0]?.recipients ?? 0),
      drafts: Number(aggregates[0]?.drafts ?? 0),
    },
  };
}

export type MessagesPageData = Awaited<ReturnType<typeof getMessagesPageData>>;
