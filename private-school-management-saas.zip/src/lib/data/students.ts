import { db } from "@/db";
import { attendance, classes, enrollments, guardians, invoices, payments, students } from "@/db/schema";
import { and, asc, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { requireContext } from "@/lib/data/context";

export type StudentListItem = {
  id: number;
  matricule: string;
  firstName: string;
  lastName: string;
  gender: string;
  status: string;
  birthDate: string | null;
  enrolledAt: string;
  address: string;
  className: string | null;
  classId: number | null;
  cycle: string | null;
  teacher: string | null;
  guardianName: string;
  guardianPhone: string;
  guardianRelation: string;
  invoiced: number;
  paid: number;
};

export type StudentFilters = { q?: string; classId?: string; status?: string };

export async function getStudents(filters: StudentFilters = {}): Promise<StudentListItem[]> {
  const { school, year } = await requireContext();
  const q = filters.q?.trim();
  const textFilter: SQL | undefined = q
    ? or(
        ilike(students.firstName, `%${q}%`),
        ilike(students.lastName, `%${q}%`),
        ilike(students.matricule, `%${q}%`),
        sql`exists (select 1 from guardians g where g.student_id = ${students.id} and (g.full_name ilike ${`%${q}%`} or g.phone ilike ${`%${q}%`}))`,
      )
    : undefined;

  const rows = await db
    .select({
      id: students.id,
      matricule: students.matricule,
      firstName: students.firstName,
      lastName: students.lastName,
      gender: students.gender,
      status: students.status,
      birthDate: students.birthDate,
      enrolledAt: students.enrolledAt,
      address: students.address,
      className: classes.name,
      classId: classes.id,
      cycle: classes.cycle,
      teacher: classes.mainTeacher,
      guardianName: sql<string>`coalesce((select g.full_name from guardians g where g.student_id = ${students.id} order by g.is_primary desc, g.id asc limit 1), '—')`,
      guardianPhone: sql<string>`coalesce((select g.phone from guardians g where g.student_id = ${students.id} order by g.is_primary desc, g.id asc limit 1), '')`,
      guardianRelation: sql<string>`coalesce((select g.relation from guardians g where g.student_id = ${students.id} order by g.is_primary desc, g.id asc limit 1), '')`,
      invoiced: sql<string>`coalesce((select sum(i.amount) from invoices i where i.student_id = ${students.id}), 0)`,
      paid: sql<string>`coalesce((select sum(i.amount_paid) from invoices i where i.student_id = ${students.id}), 0)`,
    })
    .from(students)
    .leftJoin(
      enrollments,
      and(eq(enrollments.studentId, students.id), eq(enrollments.academicYearId, year.id)),
    )
    .leftJoin(classes, eq(classes.id, enrollments.classId))
    .where(
      and(
        eq(students.schoolId, school.id),
        textFilter,
        filters.status ? eq(students.status, filters.status) : undefined,
        filters.classId ? eq(classes.id, Number(filters.classId)) : undefined,
      ),
    )
    .orderBy(asc(students.lastName), asc(students.firstName));

  return rows.map((r) => ({
    ...r,
    invoiced: Number(r.invoiced),
    paid: Number(r.paid),
  }));
}

export async function getStudentDetail(id: number) {
  const { school, year } = await requireContext();
  const [student] = await db.select().from(students).where(eq(students.id, id)).limit(1);
  if (!student || student.schoolId !== school.id) return null;

  const [guardianRows, enrollmentRows, invoiceRows, paymentRows, attendanceRows, absences] =
    await Promise.all([
      db.select().from(guardians).where(eq(guardians.studentId, id)).orderBy(desc(guardians.isPrimary)),
      db
        .select({ classId: classes.id, className: classes.name, level: classes.level, cycle: classes.cycle, teacher: classes.mainTeacher, room: classes.room, monthlyFee: classes.monthlyFee, status: enrollments.status, tuitionAmount: enrollments.tuitionAmount })
        .from(enrollments)
        .innerJoin(classes, eq(classes.id, enrollments.classId))
        .where(and(eq(enrollments.studentId, id), eq(enrollments.academicYearId, year.id)))
        .limit(1),
      db.select().from(invoices).where(eq(invoices.studentId, id)).orderBy(desc(invoices.dueDate)),
      db.select().from(payments).where(eq(payments.studentId, id)).orderBy(desc(payments.paidAt), desc(payments.id)).limit(30),
      db
        .select({ status: attendance.status, total: sql<string>`count(*)` })
        .from(attendance)
        .where(eq(attendance.studentId, id))
        .groupBy(attendance.status),
      db
        .select({ date: attendance.date, status: attendance.status })
        .from(attendance)
        .where(and(eq(attendance.studentId, id), sql`${attendance.status} <> 'présent'`))
        .orderBy(desc(attendance.date))
        .limit(6),
    ]);

  const invoicedTotal = invoiceRows.reduce((s, i) => s + i.amount, 0);
  const paidTotal = invoiceRows.reduce((s, i) => s + i.amountPaid, 0);
  const attendanceTotal = attendanceRows.reduce((s, a) => s + Number(a.total), 0);
  const presentTotal = attendanceRows
    .filter((a) => a.status === "présent" || a.status === "retard")
    .reduce((s, a) => s + Number(a.total), 0);

  return {
    student,
    enrollment: enrollmentRows[0] ?? null,
    guardians: guardianRows,
    invoices: invoiceRows,
    payments: paymentRows,
    attendance: {
      total: attendanceTotal,
      present: presentTotal,
      rate: attendanceTotal ? Math.round((presentTotal / attendanceTotal) * 100) : 0,
      breakdown: attendanceRows.map((a) => ({ status: a.status, total: Number(a.total) })),
      absences,
    },
    finance: {
      invoiced: invoicedTotal,
      paid: paidTotal,
      balance: invoicedTotal - paidTotal,
      rate: invoicedTotal ? Math.round((paidTotal / invoicedTotal) * 100) : 0,
    },
  };
}

export async function getStudentOptions() {
  const { school, year } = await requireContext();
  return db
    .select({
      id: students.id,
      firstName: students.firstName,
      lastName: students.lastName,
      matricule: students.matricule,
      className: classes.name,
    })
    .from(students)
    .leftJoin(enrollments, and(eq(enrollments.studentId, students.id), eq(enrollments.academicYearId, year.id)))
    .leftJoin(classes, eq(classes.id, enrollments.classId))
    .where(eq(students.schoolId, school.id))
    .orderBy(asc(students.lastName));
}
