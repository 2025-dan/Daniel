import { db } from "@/db";
import { classes, enrollments, invoices, messages, staff, students } from "@/db/schema";
import { and, desc, eq, gte, sql, sql as sqlish } from "drizzle-orm";
import { requireContext, getClassSummaries } from "@/lib/data/context";
import {
  getFinanceTotals,
  getMonthlyCollections,
  getPaymentMethodBreakdown,
  getRecentPayments,
  getReminders,
} from "@/lib/data/finance";
import { getRecentAttendanceRate } from "@/lib/data/academics";
import { getNextExams } from "@/lib/data/school-life";
import { currentPeriod, periodLabel } from "@/lib/data/staff";


export async function getDashboardData() {
  const { school, year } = await requireContext();

  const [counts] = await db
    .select({
      total: sql<string>`count(*)`,
      active: sql<string>`count(*) filter (where ${students.status} = 'actif')`,
      girls: sql<string>`count(*) filter (where ${students.gender} = 'F')`,
      boys: sql<string>`count(*) filter (where ${students.gender} = 'M')`,
      recent: sql<string>`count(*) filter (where ${students.enrolledAt} >= current_date - 30)`,
    })
    .from(students)
    .where(eq(students.schoolId, school.id));

  const [messagesAgg] = await db
    .select({
      sent: sql<string>`count(*) filter (where ${messages.status} = 'envoyé')`,
      drafts: sql<string>`count(*) filter (where ${messages.status} = 'brouillon')`,
      recipients: sql<string>`coalesce(sum(${messages.recipientsCount}), 0)`,
    })
    .from(messages)
    .where(eq(messages.schoolId, school.id));

  const [finance, classRows, monthly, methods, recentPayments, reminders, attendance, topDebts, lastMessages, dueSoon, nextExams, staffAgg] =
    await Promise.all([
      getFinanceTotals(),
      getClassSummaries(),
      getMonthlyCollections(),
      getPaymentMethodBreakdown(),
      getRecentPayments(6),
      getReminders(4),
      getRecentAttendanceRate(),
      db
        .select({
          id: invoices.id,
          number: invoices.number,
          label: invoices.label,
          amount: invoices.amount,
          amountPaid: invoices.amountPaid,
          dueDate: invoices.dueDate,
          studentId: invoices.studentId,
          firstName: students.firstName,
          lastName: students.lastName,
          className: classes.name,
        })
        .from(invoices)
        .innerJoin(students, eq(students.id, invoices.studentId))
        .leftJoin(
          enrollments,
          and(eq(enrollments.studentId, students.id), eq(enrollments.academicYearId, year.id)),
        )
        .leftJoin(classes, eq(classes.id, enrollments.classId))
        .where(
          and(
            eq(invoices.schoolId, school.id),
            sql`${invoices.amountPaid} < ${invoices.amount}`,
            sql`${invoices.dueDate} < current_date`,
          ),
        )
        .orderBy(desc(sql`${invoices.amount} - ${invoices.amountPaid}`))
        .limit(5),
      db
        .select({
          id: messages.id,
          subject: messages.subject,
          body: messages.body,
          channel: messages.channel,
          audience: messages.audience,
          recipientLabel: messages.recipientLabel,
          sentAt: messages.sentAt,
          status: messages.status,
          recipientsCount: messages.recipientsCount,
        })
        .from(messages)
        .where(eq(messages.schoolId, school.id))
        .orderBy(desc(messages.sentAt))
        .limit(3),
      db
        .select({
          amount: sql<string>`coalesce(sum(${invoices.amount} - ${invoices.amountPaid}), 0)`,
          count: sql<string>`count(*)`,
        })
        .from(invoices)
        .where(
          and(
            eq(invoices.schoolId, school.id),
            sql`${invoices.amountPaid} < ${invoices.amount}`,
            gte(invoices.dueDate, sql`current_date`),
            sql`${invoices.dueDate} <= current_date + 15`,
          ),
        )
        .then((rows) => rows[0] ?? { amount: "0", count: "0" }),
      getNextExams(3),
      db
        .select({
          total: sqlish<string>`count(*)`,
          teaching: sqlish<string>`count(*) filter (where ${staff.category} = 'enseignement')`,
          pending: sqlish<string>`(select count(*) from payrolls p where p.school_id = ${school.id} and p.status = 'en attente')`,
          pendingAmount: sqlish<string>`(select coalesce(sum(p.net_salary),0) from payrolls p where p.school_id = ${school.id} and p.status = 'en attente')`,
        })
        .from(staff)
        .where(eq(staff.schoolId, school.id)),
    ]);

  return {
    school,
    year,
    students: {
      total: Number(counts?.total ?? 0),
      active: Number(counts?.active ?? 0),
      girls: Number(counts?.girls ?? 0),
      boys: Number(counts?.boys ?? 0),
      recent: Number(counts?.recent ?? 0),
    },
    finance,
    classRows,
    monthly,
    methods,
    recentPayments,
    reminders,
    attendance,
    topDebts,
    lastMessages,
    messages: {
      sent: Number(messagesAgg?.sent ?? 0),
      drafts: Number(messagesAgg?.drafts ?? 0),
      recipients: Number(messagesAgg?.recipients ?? 0),
    },
    dueSoon: {
      amount: Number(dueSoon?.amount ?? 0),
      count: Number(dueSoon?.count ?? 0),
    },
    nextExams,
    staff: {
      total: Number(staffAgg[0]?.total ?? 0),
      teaching: Number(staffAgg[0]?.teaching ?? 0),
      pending: Number(staffAgg[0]?.pending ?? 0),
      pendingAmount: Number(staffAgg[0]?.pendingAmount ?? 0),
      period: periodLabel(currentPeriod()),
    },
  };
}

export type DashboardData = Awaited<ReturnType<typeof getDashboardData>>;
