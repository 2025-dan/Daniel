import { db } from "@/db";
import { classes, invoices, schools, students } from "@/db/schema";
import { asc, eq, sql } from "drizzle-orm";

export type PlatformSchool = {
  id: number;
  name: string;
  shortName: string;
  city: string;
  country: string;
  phone: string;
  email: string;
  directorName: string;
  plan: string;
  subscriptionStatus: string;
  seats: number;
  monthlyPrice: number;
  renewalDate: string | null;
  createdAt: Date;
  studentCount: number;
  classCount: number;
  invoiced: number;
  paid: number;
};

export async function getPlatformData() {
  const rows = await db
    .select({
      id: schools.id,
      name: schools.name,
      shortName: schools.shortName,
      city: schools.city,
      country: schools.country,
      phone: schools.phone,
      email: schools.email,
      directorName: schools.directorName,
      plan: schools.plan,
      subscriptionStatus: schools.subscriptionStatus,
      seats: schools.seats,
      monthlyPrice: schools.monthlyPrice,
      renewalDate: schools.renewalDate,
      createdAt: schools.createdAt,
      studentCount: sql<string>`(select count(*) from students s where s.school_id = ${schools.id})`,
      classCount: sql<string>`(select count(*) from classes c where c.school_id = ${schools.id})`,
      invoiced: sql<string>`(select coalesce(sum(i.amount),0) from invoices i where i.school_id = ${schools.id})`,
      paid: sql<string>`(select coalesce(sum(i.amount_paid),0) from invoices i where i.school_id = ${schools.id})`,
    })
    .from(schools)
    .orderBy(asc(schools.id));

  const schoolsList: PlatformSchool[] = rows.map((r) => ({
    ...r,
    studentCount: Number(r.studentCount),
    classCount: Number(r.classCount),
    invoiced: Number(r.invoiced),
    paid: Number(r.paid),
  }));

  const active = schoolsList.filter((s) => s.subscriptionStatus === "actif");
  const mrr = active.reduce((sum, s) => sum + s.monthlyPrice, 0);
  const totalStudents = schoolsList.reduce((sum, s) => sum + s.studentCount, 0);

  const recentInvoices = await db
    .select({
      id: invoices.id,
      number: invoices.number,
      amount: invoices.amount,
      amountPaid: invoices.amountPaid,
      dueDate: invoices.dueDate,
      status: invoices.status,
      firstName: students.firstName,
      lastName: students.lastName,
      schoolName: schools.name,
      className: classes.name,
    })
    .from(invoices)
    .innerJoin(students, eq(students.id, invoices.studentId))
    .innerJoin(schools, eq(schools.id, invoices.schoolId))
    .leftJoin(classes, eq(classes.id, sql`(select e.class_id from enrollments e where e.student_id = ${students.id} limit 1)`))
    .orderBy(sql`${invoices.createdAt} desc`)
    .limit(6);

  return {
    schools: schoolsList,
    totals: {
      schools: schoolsList.length,
      active: active.length,
      trial: schoolsList.filter((s) => s.subscriptionStatus === "essai").length,
      suspended: schoolsList.filter((s) => s.subscriptionStatus === "suspendu").length,
      mrr,
      arr: mrr * 12,
      students: totalStudents,
      seats: schoolsList.reduce((sum, s) => sum + s.seats, 0),
    },
    recentInvoices,
  };
}

export type PlatformData = Awaited<ReturnType<typeof getPlatformData>>;
