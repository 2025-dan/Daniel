import { db } from "@/db";
import { classes, documents, students } from "@/db/schema";
import { and, asc, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { requireContext, getClassSummaries } from "@/lib/data/context";
import { getStudentOptions } from "@/lib/data/students";

export type DocumentListItem = {
  id: number;
  category: string;
  title: string;
  fileName: string;
  mimeType: string;
  fileSize: number;
  term: string;
  average: number | null;
  decision: string;
  status: string;
  shared: boolean;
  notes: string;
  uploadedBy: string;
  source: string;
  createdAt: Date;
  studentId: number | null;
  firstName: string | null;
  lastName: string | null;
  matricule: string | null;
  className: string | null;
};

export type DocumentFilters = {
  q?: string;
  category?: string;
  status?: string;
  studentId?: string;
};

const LIST_COLUMNS = {
  id: documents.id,
  category: documents.category,
  title: documents.title,
  fileName: documents.fileName,
  mimeType: documents.mimeType,
  fileSize: documents.fileSize,
  term: documents.term,
  average: documents.average,
  decision: documents.decision,
  status: documents.status,
  shared: documents.shared,
  notes: documents.notes,
  uploadedBy: documents.uploadedBy,
  source: documents.source,
  createdAt: documents.createdAt,
  studentId: documents.studentId,
  firstName: students.firstName,
  lastName: students.lastName,
  matricule: students.matricule,
  className: classes.name,
};

export async function getDocumentRows(filters: DocumentFilters = {}): Promise<DocumentListItem[]> {
  const { school } = await requireContext();
  const q = filters.q?.trim();
  const textFilter: SQL | undefined = q
    ? or(
        ilike(documents.title, `%${q}%`),
        ilike(documents.fileName, `%${q}%`),
        ilike(students.firstName, `%${q}%`),
        ilike(students.lastName, `%${q}%`),
        ilike(students.matricule, `%${q}%`),
      )
    : undefined;

  return db
    .select(LIST_COLUMNS)
    .from(documents)
    .leftJoin(students, eq(students.id, documents.studentId))
    .leftJoin(classes, eq(classes.id, documents.classId))
    .where(
      and(
        eq(documents.schoolId, school.id),
        textFilter,
        filters.category ? eq(documents.category, filters.category) : undefined,
        filters.status ? eq(documents.status, filters.status) : undefined,
        filters.studentId ? eq(documents.studentId, Number(filters.studentId)) : undefined,
      ),
    )
    .orderBy(desc(documents.createdAt), desc(documents.id))
    .limit(120);
}

export async function getDocumentsPageData(filters: DocumentFilters = {}) {
  const { school } = await requireContext();
  const [rows, classRows, studentRows, stats] = await Promise.all([
    getDocumentRows(filters),
    getClassSummaries(),
    getStudentOptions(),
    db
      .select({
        total: sql<string>`count(*)`,
        bulletins: sql<string>`count(*) filter (where ${documents.category} = 'bulletin')`,
        pending: sql<string>`count(*) filter (where ${documents.status} = 'à vérifier')`,
        shared: sql<string>`count(*) filter (where ${documents.shared} = true)`,
        bytes: sql<string>`coalesce(sum(${documents.fileSize}), 0)`,
      })
      .from(documents)
      .where(eq(documents.schoolId, school.id)),
  ]);

  return {
    documents: rows,
    classRows,
    students: studentRows,
    stats: {
      total: Number(stats[0]?.total ?? 0),
      bulletins: Number(stats[0]?.bulletins ?? 0),
      pending: Number(stats[0]?.pending ?? 0),
      shared: Number(stats[0]?.shared ?? 0),
      bytes: Number(stats[0]?.bytes ?? 0),
    },
  };
}

export async function getStudentDocuments(studentId: number, limit = 12) {
  return db
    .select(LIST_COLUMNS)
    .from(documents)
    .leftJoin(students, eq(students.id, documents.studentId))
    .leftJoin(classes, eq(classes.id, documents.classId))
    .where(eq(documents.studentId, studentId))
    .orderBy(desc(documents.createdAt))
    .limit(limit);
}

export async function getSharedDocuments(studentId: number, limit = 10) {
  return db
    .select({
      id: documents.id,
      title: documents.title,
      category: documents.category,
      fileName: documents.fileName,
      mimeType: documents.mimeType,
      fileSize: documents.fileSize,
      term: documents.term,
      average: documents.average,
      createdAt: documents.createdAt,
    })
    .from(documents)
    .where(and(eq(documents.studentId, studentId), eq(documents.shared, true)))
    .orderBy(desc(documents.createdAt))
    .limit(limit);
}

export async function getDocumentFile(id: number) {
  const [row] = await db
    .select({
      id: documents.id,
      fileName: documents.fileName,
      mimeType: documents.mimeType,
      data: documents.data,
    })
    .from(documents)
    .where(eq(documents.id, id))
    .limit(1);
  return row ?? null;
}

export async function getDocumentClasses() {
  return getClassSummaries();
}

export function formatFileSize(bytes: number): string {
  if (!bytes) return "0 Ko";
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} Ko`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} Mo`;
}

export { asc };
