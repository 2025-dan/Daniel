export const ROLE_COOKIE = "scolaris_role";

export type Role = "directeur" | "comptable" | "enseignant" | "surveillant";

export type Section =
  | "dashboard"
  | "students"
  | "classes"
  | "documents"
  | "finance"
  | "attendance"
  | "timetable"
  | "lessons"
  | "exams"
  | "grades"
  | "reports"
  | "staff"
  | "payroll"
  | "messages"
  | "settings";

export const ROLES: { key: Role; label: string; short: string; description: string }[] = [
  {
    key: "directeur",
    label: "Directeur / Promoteur",
    short: "Directeur",
    description: "Pilotage complet, validation et tableaux de bord.",
  },
  {
    key: "comptable",
    label: "Comptable / Économe",
    short: "Comptable",
    description: "Frais, encaissements, relances et rapports financiers.",
  },
  {
    key: "enseignant",
    label: "Enseignant",
    short: "Enseignant",
    description: "Présences, notes, cahier de textes et bulletins.",
  },
  {
    key: "surveillant",
    label: "Surveillant / Éducateur",
    short: "Surveillant",
    description: "Discipline, absences, retards et communication.",
  },
];

export const SECTION_ACCESS: Record<Section, Role[]> = {
  dashboard: ["directeur", "comptable", "enseignant", "surveillant"],
  students: ["directeur", "comptable", "enseignant", "surveillant"],
  classes: ["directeur", "enseignant", "surveillant"],
  documents: ["directeur", "enseignant", "surveillant", "comptable"],
  finance: ["directeur", "comptable"],
  attendance: ["directeur", "enseignant", "surveillant"],
  timetable: ["directeur", "enseignant", "surveillant"],
  lessons: ["directeur", "enseignant"],
  exams: ["directeur", "enseignant", "surveillant"],
  grades: ["directeur", "enseignant"],
  reports: ["directeur", "enseignant"],
  staff: ["directeur", "comptable"],
  payroll: ["directeur", "comptable"],
  messages: ["directeur", "comptable", "surveillant"],
  settings: ["directeur"],
};

export function can(role: Role, section: Section): boolean {
  return SECTION_ACCESS[section].includes(role);
}

export function roleLabel(role: Role): string {
  return ROLES.find((r) => r.key === role)?.short ?? "Directeur";
}
