import {
  boolean,
  date,
  integer,
  pgTable,
  real,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Établissement & années scolaires                                    */
/* ------------------------------------------------------------------ */

export const schools = pgTable("schools", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  shortName: text("short_name").notNull(),
  city: text("city").notNull().default("Abidjan"),
  country: text("country").notNull().default("Côte d'Ivoire"),
  phone: text("phone").notNull().default(""),
  email: text("email").notNull().default(""),
  address: text("address").notNull().default(""),
  motto: text("motto").notNull().default(""),
  currency: text("currency").notNull().default("FC"),
  directorName: text("director_name").notNull().default(""),
  plan: text("plan").notNull().default("Pro"),
  subscriptionStatus: text("subscription_status").notNull().default("actif"),
  seats: integer("seats").notNull().default(150),
  monthlyPrice: integer("monthly_price").notNull().default(55000),
  renewalDate: date("renewal_date"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const academicYears = pgTable("academic_years", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").notNull().references(() => schools.id, { onDelete: "cascade" }),
  label: text("label").notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  isCurrent: boolean("is_current").notNull().default(true),
});

/* ------------------------------------------------------------------ */
/* Classes, élèves, tuteurs                                            */
/* ------------------------------------------------------------------ */

export const classes = pgTable("classes", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").notNull().references(() => schools.id, { onDelete: "cascade" }),
  academicYearId: integer("academic_year_id").notNull().references(() => academicYears.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  level: text("level").notNull(),
  cycle: text("cycle").notNull().default("Primaire"),
  capacity: integer("capacity").notNull().default(40),
  room: text("room").notNull().default(""),
  mainTeacher: text("main_teacher").notNull().default(""),
  monthlyFee: integer("monthly_fee").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const students = pgTable(
  "students",
  {
    id: serial("id").primaryKey(),
    schoolId: integer("school_id").notNull().references(() => schools.id, { onDelete: "cascade" }),
    matricule: text("matricule").notNull(),
    firstName: text("first_name").notNull(),
    lastName: text("last_name").notNull(),
    gender: text("gender").notNull().default("M"),
    birthDate: date("birth_date"),
    birthPlace: text("birth_place").notNull().default(""),
    status: text("status").notNull().default("actif"),
    address: text("address").notNull().default(""),
    bloodGroup: text("blood_group").notNull().default(""),
    notes: text("notes").notNull().default(""),
    enrolledAt: date("enrolled_at").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("students_matricule_unique").on(table.matricule)],
);

export const guardians = pgTable("guardians", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => students.id, { onDelete: "cascade" }),
  fullName: text("full_name").notNull(),
  relation: text("relation").notNull().default("Père"),
  phone: text("phone").notNull().default(""),
  email: text("email").notNull().default(""),
  profession: text("profession").notNull().default(""),
  isPrimary: boolean("is_primary").notNull().default(true),
});

export const enrollments = pgTable("enrollments", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => students.id, { onDelete: "cascade" }),
  classId: integer("class_id").notNull().references(() => classes.id, { onDelete: "cascade" }),
  academicYearId: integer("academic_year_id").notNull().references(() => academicYears.id, { onDelete: "cascade" }),
  status: text("status").notNull().default("inscrit"),
  tuitionAmount: integer("tuition_amount").notNull().default(0),
  registeredAt: date("registered_at").notNull(),
});

/* ------------------------------------------------------------------ */
/* Finances                                                            */
/* ------------------------------------------------------------------ */

export const feeStructures = pgTable("fee_structures", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").notNull().references(() => schools.id, { onDelete: "cascade" }),
  academicYearId: integer("academic_year_id").notNull().references(() => academicYears.id, { onDelete: "cascade" }),
  level: text("level").notNull(),
  label: text("label").notNull(),
  amount: integer("amount").notNull().default(0),
  type: text("type").notNull().default("scolarité"),
  dueDate: date("due_date"),
});

export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").notNull().references(() => schools.id, { onDelete: "cascade" }),
  studentId: integer("student_id").notNull().references(() => students.id, { onDelete: "cascade" }),
  number: text("number").notNull(),
  label: text("label").notNull(),
  amount: integer("amount").notNull().default(0),
  amountPaid: integer("amount_paid").notNull().default(0),
  dueDate: date("due_date").notNull(),
  status: text("status").notNull().default("impayée"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").notNull().references(() => schools.id, { onDelete: "cascade" }),
  invoiceId: integer("invoice_id").references(() => invoices.id, { onDelete: "set null" }),
  studentId: integer("student_id").notNull().references(() => students.id, { onDelete: "cascade" }),
  amount: integer("amount").notNull().default(0),
  method: text("method").notNull().default("espèces"),
  reference: text("reference").notNull().default(""),
  paidAt: date("paid_at").notNull(),
  recordedBy: text("recorded_by").notNull().default("Secrétariat"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const reminders = pgTable("reminders", {
  id: serial("id").primaryKey(),
  invoiceId: integer("invoice_id").notNull().references(() => invoices.id, { onDelete: "cascade" }),
  studentId: integer("student_id").notNull().references(() => students.id, { onDelete: "cascade" }),
  channel: text("channel").notNull().default("sms"),
  message: text("message").notNull(),
  sentAt: timestamp("sent_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Pédagogie                                                           */
/* ------------------------------------------------------------------ */

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").notNull().references(() => schools.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  code: text("code").notNull(),
  cycle: text("cycle").notNull().default("Primaire"),
  coefficient: integer("coefficient").notNull().default(1),
  teacher: text("teacher").notNull().default(""),
});

export const assessments = pgTable("assessments", {
  id: serial("id").primaryKey(),
  classId: integer("class_id").notNull().references(() => classes.id, { onDelete: "cascade" }),
  subjectId: integer("subject_id").notNull().references(() => subjects.id, { onDelete: "cascade" }),
  academicYearId: integer("academic_year_id").notNull().references(() => academicYears.id, { onDelete: "cascade" }),
  term: text("term").notNull().default("Trimestre 1"),
  title: text("title").notNull(),
  maxScore: integer("max_score").notNull().default(20),
  coefficient: integer("coefficient").notNull().default(1),
  date: date("date").notNull(),
});

export const grades = pgTable("grades", {
  id: serial("id").primaryKey(),
  assessmentId: integer("assessment_id").notNull().references(() => assessments.id, { onDelete: "cascade" }),
  studentId: integer("student_id").notNull().references(() => students.id, { onDelete: "cascade" }),
  score: real("score"),
  remark: text("remark").notNull().default(""),
});

export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => students.id, { onDelete: "cascade" }),
  classId: integer("class_id").notNull().references(() => classes.id, { onDelete: "cascade" }),
  date: date("date").notNull(),
  status: text("status").notNull().default("présent"),
  note: text("note").notNull().default(""),
  recordedBy: text("recorded_by").notNull().default("Enseignant"),
});

/* ------------------------------------------------------------------ */
/* Communication                                                       */
/* ------------------------------------------------------------------ */

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").notNull().references(() => schools.id, { onDelete: "cascade" }),
  audience: text("audience").notNull().default("tous"),
  classId: integer("class_id").references(() => classes.id, { onDelete: "set null" }),
  studentId: integer("student_id").references(() => students.id, { onDelete: "set null" }),
  recipientLabel: text("recipient_label").notNull().default("Tous les parents"),
  channel: text("channel").notNull().default("sms"),
  subject: text("subject").notNull(),
  body: text("body").notNull(),
  status: text("status").notNull().default("envoyé"),
  recipientsCount: integer("recipients_count").notNull().default(0),
  sentAt: timestamp("sent_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Personnel & paie                                                    */
/* ------------------------------------------------------------------ */

export const staff = pgTable("staff", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").notNull().references(() => schools.id, { onDelete: "cascade" }),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  jobTitle: text("job_title").notNull().default("Enseignant"),
  category: text("category").notNull().default("enseignement"),
  phone: text("phone").notNull().default(""),
  email: text("email").notNull().default(""),
  qualification: text("qualification").notNull().default(""),
  hireDate: date("hire_date").notNull(),
  monthlySalary: integer("monthly_salary").notNull().default(0),
  status: text("status").notNull().default("actif"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const payrolls = pgTable("payrolls", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").notNull().references(() => schools.id, { onDelete: "cascade" }),
  staffId: integer("staff_id").notNull().references(() => staff.id, { onDelete: "cascade" }),
  period: text("period").notNull(),
  grossSalary: integer("gross_salary").notNull().default(0),
  bonuses: integer("bonuses").notNull().default(0),
  deductions: integer("deductions").notNull().default(0),
  netSalary: integer("net_salary").notNull().default(0),
  status: text("status").notNull().default("en attente"),
  method: text("method").notNull().default("virement"),
  paidAt: date("paid_at"),
  reference: text("reference").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Emploi du temps, cahier de textes, examens                          */
/* ------------------------------------------------------------------ */

export const timetableSlots = pgTable("timetable_slots", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").notNull().references(() => schools.id, { onDelete: "cascade" }),
  classId: integer("class_id").notNull().references(() => classes.id, { onDelete: "cascade" }),
  day: integer("day").notNull().default(1),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  subjectId: integer("subject_id").references(() => subjects.id, { onDelete: "set null" }),
  teacher: text("teacher").notNull().default(""),
  room: text("room").notNull().default(""),
});

export const lessonLogs = pgTable("lesson_logs", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").notNull().references(() => schools.id, { onDelete: "cascade" }),
  classId: integer("class_id").notNull().references(() => classes.id, { onDelete: "cascade" }),
  subjectId: integer("subject_id").references(() => subjects.id, { onDelete: "set null" }),
  date: date("date").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull().default(""),
  homework: text("homework").notNull().default(""),
  dueDate: date("due_date"),
  teacher: text("teacher").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const exams = pgTable("exams", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").notNull().references(() => schools.id, { onDelete: "cascade" }),
  classId: integer("class_id").notNull().references(() => classes.id, { onDelete: "cascade" }),
  subjectId: integer("subject_id").references(() => subjects.id, { onDelete: "set null" }),
  term: text("term").notNull().default("Trimestre 1"),
  title: text("title").notNull(),
  date: date("date").notNull(),
  startTime: text("start_time").notNull().default("08:00"),
  duration: integer("duration").notNull().default(120),
  room: text("room").notNull().default(""),
  supervisor: text("supervisor").notNull().default(""),
  status: text("status").notNull().default("planifié"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Documents, imports et bulletins scannés                             */
/* ------------------------------------------------------------------ */

export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").notNull().references(() => schools.id, { onDelete: "cascade" }),
  studentId: integer("student_id").references(() => students.id, { onDelete: "cascade" }),
  classId: integer("class_id").references(() => classes.id, { onDelete: "set null" }),
  category: text("category").notNull().default("autre"),
  title: text("title").notNull(),
  fileName: text("file_name").notNull(),
  mimeType: text("mime_type").notNull().default("application/octet-stream"),
  fileSize: integer("file_size").notNull().default(0),
  data: text("data").notNull(),
  term: text("term").notNull().default(""),
  average: real("average"),
  decision: text("decision").notNull().default(""),
  status: text("status").notNull().default("à vérifier"),
  shared: boolean("shared").notNull().default(false),
  notes: text("notes").notNull().default(""),
  uploadedBy: text("uploaded_by").notNull().default("Secrétariat"),
  source: text("source").notNull().default("import"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type DocumentRow = typeof documents.$inferSelect;
export type Staff = typeof staff.$inferSelect;
export type Payroll = typeof payrolls.$inferSelect;
export type TimetableSlot = typeof timetableSlots.$inferSelect;
export type LessonLog = typeof lessonLogs.$inferSelect;
export type Exam = typeof exams.$inferSelect;
export type School = typeof schools.$inferSelect;
export type Student = typeof students.$inferSelect;
export type ClassRow = typeof classes.$inferSelect;
export type Invoice = typeof invoices.$inferSelect;
export type Payment = typeof payments.$inferSelect;
export type Message = typeof messages.$inferSelect;
