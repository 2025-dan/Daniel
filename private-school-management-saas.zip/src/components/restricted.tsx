import Link from "next/link";
import { Lock, RotateCcw } from "lucide-react";
import { ROLES, roleLabel, type Role } from "@/lib/roles";

export function Restricted({ role, module }: { role: Role; module: string }) {
  return (
    <div className="card mx-auto max-w-xl p-8 text-center">
      <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-amber-50 text-amber-700">
        <Lock className="h-6 w-6" strokeWidth={1.8} />
      </span>
      <h1 className="mt-4 font-display text-xl font-semibold text-ink">Accès réservé</h1>
      <p className="mt-2 text-sm text-ink/55">
        Le profil <strong>{roleLabel(role)}</strong> n&apos;a pas accès au module « {module} ». Changez de rôle dans
        la barre du haut pour découvrir cette partie de la plateforme.
      </p>
      <div className="mt-5 flex flex-wrap justify-center gap-2">
        <Link href="/dashboard" className="btn-primary">
          Retour au tableau de bord
        </Link>
        <span className="btn-outline cursor-default">
          <RotateCcw className="h-4 w-4" /> {ROLES.length} profils disponibles
        </span>
      </div>
    </div>
  );
}
