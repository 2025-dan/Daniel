import Link from "next/link";
import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

export function PageHeader({
  eyebrow,
  title,
  subtitle,
  actions,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        {eyebrow ? (
          <p className="mb-1.5 text-[11px] font-bold uppercase tracking-[0.14em] text-brand-600">{eyebrow}</p>
        ) : null}
        <h1 className="font-display text-2xl font-semibold tracking-tight text-ink sm:text-[28px]">{title}</h1>
        {subtitle ? <p className="mt-1.5 max-w-2xl text-sm text-ink/55">{subtitle}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

const TONES: Record<string, { bg: string; text: string; ring: string }> = {
  brand: { bg: "bg-brand-50", text: "text-brand-700", ring: "ring-brand-100" },
  amber: { bg: "bg-amber-50", text: "text-amber-700", ring: "ring-amber-100" },
  danger: { bg: "bg-red-50", text: "text-red-600", ring: "ring-red-100" },
  sky: { bg: "bg-sky-50", text: "text-sky-600", ring: "ring-sky-100" },
  ink: { bg: "bg-ink/5", text: "text-ink/70", ring: "ring-ink/10" },
};

export function StatCard({
  label,
  value,
  hint,
  icon: Icon,
  tone = "brand",
  footer,
}: {
  label: string;
  value: string | number;
  hint?: string;
  icon: LucideIcon;
  tone?: keyof typeof TONES;
  footer?: ReactNode;
}) {
  const t = TONES[tone] ?? TONES.brand;
  return (
    <div className="card p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-bold uppercase tracking-[0.08em] text-ink/45">{label}</p>
          <p className="mt-2 font-display text-2xl font-semibold tracking-tight text-ink">{value}</p>
          {hint ? <p className="mt-1 text-xs text-ink/50">{hint}</p> : null}
        </div>
        <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ring-1 ${t.bg} ${t.text} ${t.ring}`}>
          <Icon className="h-5 w-5" strokeWidth={1.8} />
        </span>
      </div>
      {footer ? <div className="mt-3">{footer}</div> : null}
    </div>
  );
}

const BADGE_TONES: Record<string, string> = {
  success: "bg-brand-100 text-brand-800",
  warning: "bg-amber-100 text-amber-800",
  danger: "bg-red-100 text-red-700",
  info: "bg-sky-100 text-sky-700",
  neutral: "bg-ink/8 text-ink/65",
  brand: "bg-brand-50 text-brand-700 ring-1 ring-brand-100",
};

export function Badge({
  children,
  tone = "neutral",
  className = "",
}: {
  children: ReactNode;
  tone?: keyof typeof BADGE_TONES;
  className?: string;
}) {
  return <span className={`badge ${BADGE_TONES[tone] ?? BADGE_TONES.neutral} ${className}`}>{children}</span>;
}

export function ProgressBar({
  value,
  tone = "brand",
  className = "",
}: {
  value: number;
  tone?: "brand" | "amber" | "danger" | "sky";
  className?: string;
}) {
  const colors = {
    brand: "bg-brand-500",
    amber: "bg-amber-400",
    danger: "bg-red-500",
    sky: "bg-sky-500",
  };
  return (
    <div className={`h-1.5 w-full overflow-hidden rounded-full bg-ink/8 ${className}`}>
      <div
        className={`h-full rounded-full ${colors[tone]}`}
        style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
      />
    </div>
  );
}

export function Avatar({
  first,
  last,
  size = "md",
  tone = "brand",
}: {
  first?: string | null;
  last?: string | null;
  size?: "sm" | "md" | "lg";
  tone?: "brand" | "sand";
}) {
  const sizes = { sm: "h-8 w-8 text-[11px]", md: "h-10 w-10 text-xs", lg: "h-14 w-14 text-base" };
  const letters = `${(first ?? "?").charAt(0)}${(last ?? "").charAt(0)}`.toUpperCase();
  return (
    <span
      className={`grid shrink-0 place-items-center rounded-full font-bold ${sizes[size]} ${
        tone === "brand" ? "bg-brand-100 text-brand-800" : "bg-sand-dark text-ink/70"
      }`}
    >
      {letters}
    </span>
  );
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-ink/15 bg-sand/40 px-6 py-12 text-center">
      <span className="grid h-12 w-12 place-items-center rounded-2xl bg-white text-brand-600 shadow-sm">
        <Icon className="h-6 w-6" strokeWidth={1.6} />
      </span>
      <p className="mt-3 font-display text-base font-semibold text-ink">{title}</p>
      {description ? <p className="mt-1 max-w-sm text-sm text-ink/55">{description}</p> : null}
      {action ? <div className="mt-4">{action}</div> : null}
    </div>
  );
}

export function SectionCard({
  title,
  description,
  action,
  children,
  className = "",
  bodyClassName = "p-5",
}: {
  title?: string;
  description?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
}) {
  return (
    <section className={`card overflow-hidden ${className}`}>
      {title ? (
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-ink/8 px-5 py-4">
          <div>
            <h2 className="section-title">{title}</h2>
            {description ? <p className="mt-0.5 text-xs text-ink/50">{description}</p> : null}
          </div>
          {action}
        </div>
      ) : null}
      <div className={bodyClassName}>{children}</div>
    </section>
  );
}

export function InfoRow({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-ink/6 py-2.5 last:border-0">
      <span className="text-xs font-semibold uppercase tracking-wide text-ink/40">{label}</span>
      <span className="text-right text-sm font-medium text-ink">{value}</span>
    </div>
  );
}

export function Tabs({
  items,
  current,
}: {
  items: { label: string; href: string; count?: number }[];
  current: string;
}) {
  return (
    <div className="flex flex-wrap items-center gap-1 rounded-xl bg-ink/5 p-1">
      {items.map((item) => {
        const active = item.label === current;
        return (
          <Link
            key={item.label}
            href={item.href}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              active ? "bg-white text-ink shadow-sm" : "text-ink/55 hover:text-ink"
            }`}
          >
            {item.label}
            {typeof item.count === "number" ? (
              <span className="ml-1.5 text-[10px] text-ink/45">{item.count}</span>
            ) : null}
          </Link>
        );
      })}
    </div>
  );
}

export function Notice({
  tone = "success",
  children,
}: {
  tone?: "success" | "warning" | "danger" | "info";
  children: ReactNode;
}) {
  const tones = {
    success: "border-brand-200 bg-brand-50 text-brand-800",
    warning: "border-amber-200 bg-amber-50 text-amber-800",
    danger: "border-red-200 bg-red-50 text-red-700",
    info: "border-sky-200 bg-sky-50 text-sky-800",
  };
  return <div className={`rounded-xl border px-3.5 py-2.5 text-sm ${tones[tone]}`}>{children}</div>;
}
