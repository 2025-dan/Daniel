import { compactMoney, money } from "@/lib/format";

export function CollectionBars({
  data,
}: {
  data: { key: string; label: string; value: number }[];
}) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <div className="flex h-44 items-end gap-3 sm:gap-5">
      {data.map((item) => {
        const height = Math.max(4, Math.round((item.value / max) * 100));
        return (
          <div key={item.key} className="group flex flex-1 flex-col items-center justify-end gap-2">
            <span className="text-[10px] font-semibold text-ink/45 opacity-0 transition group-hover:opacity-100">
              {compactMoney(item.value)}
            </span>
            <div
              title={money(item.value)}
              className="w-full rounded-t-lg bg-gradient-to-t from-brand-700 to-brand-400 transition group-hover:from-brand-800 group-hover:to-brand-500"
              style={{ height: `${height}%` }}
            />
            <span className="text-[10px] font-semibold uppercase tracking-wide text-ink/45">{item.label}</span>
          </div>
        );
      })}
    </div>
  );
}

export function Donut({
  segments,
  centerValue,
  centerLabel,
}: {
  segments: { label: string; value: number; color: string }[];
  centerValue: string;
  centerLabel: string;
}) {
  const total = segments.reduce((sum, s) => sum + s.value, 0);
  let cursor = 0;
  const stops = segments
    .map((s) => {
      const start = total ? (cursor / total) * 360 : 0;
      cursor += s.value;
      const end = total ? (cursor / total) * 360 : 0;
      return `${s.color} ${start}deg ${end}deg`;
    })
    .join(", ");

  return (
    <div className="flex flex-col items-center gap-5 sm:flex-row sm:gap-6">
      <div
        className="relative grid h-32 w-32 shrink-0 place-items-center rounded-full"
        style={{
          background: total > 0 ? `conic-gradient(${stops})` : "#ece7da",
        }}
      >
        <div className="grid h-24 w-24 place-items-center rounded-full bg-white text-center shadow-inner">
          <div>
            <p className="font-display text-lg font-semibold text-ink">{centerValue}</p>
            <p className="text-[10px] font-semibold uppercase tracking-wide text-ink/40">{centerLabel}</p>
          </div>
        </div>
      </div>
      <ul className="w-full space-y-2.5">
        {segments.map((s) => (
          <li key={s.label} className="flex items-center justify-between gap-3 text-sm">
            <span className="flex items-center gap-2 text-ink/65">
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
              {s.label}
            </span>
            <span className="font-semibold text-ink">{money(s.value, false)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function TrendBars({
  data,
}: {
  data: { date: string; rate: number; total: number }[];
}) {
  const items = [...data].reverse();
  if (items.length === 0) {
    return <p className="text-sm text-ink/50">Aucun appel enregistré.</p>;
  }
  return (
    <div className="flex items-end gap-2">
      {items.map((d) => (
        <div key={d.date} className="flex flex-1 flex-col items-center gap-1.5">
          <div className="flex h-16 w-full items-end rounded-md bg-ink/5">
            <div
              className={`w-full rounded-md ${d.rate >= 90 ? "bg-brand-500" : d.rate >= 75 ? "bg-amber-400" : "bg-red-400"}`}
              style={{ height: `${Math.max(8, d.rate)}%` }}
              title={`${d.date} · ${d.rate}%`}
            />
          </div>
          <span className="text-[9px] font-semibold text-ink/40">{d.date.slice(8, 10)}</span>
        </div>
      ))}
    </div>
  );
}
