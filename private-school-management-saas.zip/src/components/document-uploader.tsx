"use client";

import { useRef, useState } from "react";
import { Camera, FileText, Image as ImageIcon, Loader2, ScanLine, UploadCloud, X } from "lucide-react";

type StudentOption = {
  id: number;
  firstName: string;
  lastName: string;
  matricule: string;
  className: string | null;
};

export function DocumentUploader({
  action,
  redirectTo,
  students,
  categories,
  terms,
  mode = "import",
  defaultStudentId,
  defaultCategory,
}: {
  action: (formData: FormData) => void | Promise<void>;
  redirectTo: string;
  students: StudentOption[];
  categories: { key: string; label: string }[];
  terms: readonly string[];
  mode?: "import" | "scan";
  defaultStudentId?: string;
  defaultCategory?: string;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);
  const [category, setCategory] = useState(defaultCategory ?? (mode === "scan" ? "bulletin" : "acte"));
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);

  function acceptFile(next: File | null) {
    setError(null);
    if (!next) {
      setFile(null);
      setPreview(null);
      return;
    }
    if (next.size > 8 * 1024 * 1024) {
      setError("Le fichier dépasse 8 Mo. Compressez le document ou prenez une photo de meilleure qualité.");
      return;
    }
    setFile(next);
    setPreview(next.type.startsWith("image/") ? URL.createObjectURL(next) : null);
  }

  const isBulletin = category === "bulletin";

  return (
    <form action={action} encType="multipart/form-data" className="space-y-3">
      <input type="hidden" name="redirectTo" value={redirectTo} />
      <input type="hidden" name="source" value={mode === "scan" ? "scan" : "import"} />

      <div
        onDragOver={(event) => {
          event.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(event) => {
          event.preventDefault();
          setDragging(false);
          acceptFile(event.dataTransfer.files?.[0] ?? null);
        }}
        className={`relative rounded-xl border-2 border-dashed p-4 text-center transition ${
          dragging ? "border-brand-500 bg-brand-50" : "border-ink/15 bg-sand/40 hover:border-brand-300"
        }`}
      >
        {preview ? (
          <div className="relative">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={preview} alt="Aperçu du document" className="mx-auto max-h-44 rounded-lg object-contain" />
            <button
              type="button"
              onClick={() => acceptFile(null)}
              className="absolute right-1 top-1 grid h-7 w-7 place-items-center rounded-full bg-white text-red-600 shadow"
              aria-label="Retirer le fichier"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ) : file ? (
          <div className="flex items-center justify-center gap-2 py-6">
            <FileText className="h-6 w-6 text-brand-700" />
            <div className="text-left">
              <p className="max-w-[220px] truncate text-sm font-semibold text-ink">{file.name}</p>
              <p className="text-[11px] text-ink/45">{Math.round(file.size / 1024)} Ko prêt à être importé</p>
            </div>
            <button type="button" onClick={() => acceptFile(null)} className="text-ink/40 hover:text-red-600" aria-label="Retirer">
              <X className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <div className="py-5">
            <span className="mx-auto grid h-11 w-11 place-items-center rounded-xl bg-white text-brand-700 shadow-sm">
              {mode === "scan" ? <ScanLine className="h-5 w-5" /> : <UploadCloud className="h-5 w-5" />}
            </span>
            <p className="mt-2 text-sm font-semibold text-ink">
              {mode === "scan" ? "Prenez une photo du bulletin" : "Glissez un fichier ici"}
            </p>
            <p className="mt-0.5 text-[11px] text-ink/45">PDF, JPG, PNG, WEBP ou DOCX · 8 Mo maximum</p>
            <div className="mt-3 flex flex-wrap justify-center gap-2">
              <button type="button" onClick={() => cameraRef.current?.click()} className="btn-soft btn-sm">
                <Camera className="h-3.5 w-3.5" /> Utiliser la caméra
              </button>
              <button type="button" onClick={() => inputRef.current?.click()} className="btn-outline btn-sm">
                <ImageIcon className="h-3.5 w-3.5" /> Choisir un fichier
              </button>
            </div>
          </div>
        )}

        <input
          ref={inputRef}
          type="file"
          name="file"
          accept="application/pdf,image/*,.doc,.docx"
          className="hidden"
          onChange={(event) => acceptFile(event.target.files?.[0] ?? null)}
        />
        <input
          ref={cameraRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={(event) => acceptFile(event.target.files?.[0] ?? null)}
        />
      </div>

      {error ? (
        <p className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-[11px] text-red-700">{error}</p>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="upload-student">Élève concerné</label>
          <select id="upload-student" name="studentId" className="input" defaultValue={defaultStudentId ?? ""}>
            <option value="">Document de l&apos;établissement</option>
            {students.map((student) => (
              <option key={student.id} value={student.id}>
                {student.lastName} {student.firstName} — {student.className ?? "sans classe"}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="upload-category">Type de document</label>
          <select
            id="upload-category"
            name="category"
            className="input"
            value={category}
            onChange={(event) => setCategory(event.target.value)}
          >
            {categories.map((item) => (
              <option key={item.key} value={item.key}>{item.label}</option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <label className="label" htmlFor="upload-title">
          Titre {mode === "scan" ? "(optionnel)" : ""}
        </label>
        <input
          id="upload-title"
          name="title"
          className="input"
          placeholder={mode === "scan" ? "Bulletin T1 — KABONGO Grâce" : "Acte de naissance — 2026"}
        />
      </div>

      {isBulletin ? (
        <>
          <div className="grid gap-3 sm:grid-cols-3">
            <div>
              <label className="label" htmlFor="upload-term">Trimestre</label>
              <select id="upload-term" name="term" className="input" defaultValue={terms[0]}>
                {terms.map((term) => (
                  <option key={term} value={term}>{term}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="upload-average">Moyenne lue (/20)</label>
              <input id="upload-average" name="average" type="number" min={0} max={20} step={0.01} className="input" placeholder="14.50" />
            </div>
            <div>
              <label className="label" htmlFor="upload-decision">Décision</label>
              <select id="upload-decision" name="decision" className="input" defaultValue="">
                <option value="">À déterminer</option>
                <option value="admis">Admis</option>
                <option value="à soutenir">À soutenir</option>
                <option value="redouble">Redouble</option>
              </select>
            </div>
          </div>
          <p className="rounded-lg bg-sand px-3 py-2 text-[11px] leading-relaxed text-ink/55">
            Vérifiez la moyenne et la décision lues sur le bulletin avant l&apos;envoi. Le document est enregistré
            avec le statut « à vérifier » : validez-le depuis la liste.
          </p>
        </>
      ) : null}

      <div>
        <label className="label" htmlFor="upload-notes">Remarque interne</label>
        <textarea id="upload-notes" name="notes" rows={2} className="input" placeholder="Facultatif" />
      </div>

      <label className="flex cursor-pointer items-start gap-2 rounded-xl border border-brand-200 bg-brand-50 p-3">
        <input type="checkbox" name="shared" defaultChecked className="mt-0.5 h-4 w-4 accent-brand-700" />
        <span className="text-[11px] leading-snug text-brand-900">
          <span className="block font-bold">Visible par les parents</span>
          Le document apparaîtra dans le portail parents de l&apos;élève.
        </span>
      </label>

      <div className="flex flex-col gap-2 sm:flex-row">
        <button type="submit" className="btn-primary flex-1" disabled={!file}>
          {file ? (
            <>
              <ScanLine className="h-4 w-4" />
              {mode === "scan" ? "Enregistrer le scan" : "Importer le document"}
            </>
          ) : (
            <>
              <Loader2 className="hidden h-4 w-4" />
              Sélectionnez un fichier
            </>
          )}
        </button>
      </div>
    </form>
  );
}
