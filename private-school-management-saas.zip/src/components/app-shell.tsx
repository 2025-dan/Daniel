"use client";

import { useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Banknote,
  Bell,
  BookOpen,
  Building2,
  CalendarCheck,
  CalendarRange,
  ChevronDown,
  ClipboardList,
  ClipboardCheck,
  FileText,
  FolderOpen,
  GraduationCap,
  LayoutDashboard,
  Menu,
  MessageSquare,
  Search,
  Settings,
  Smartphone,
  Sparkles,
  UserCog,
  Users,
  Wallet,
  X,
  type LucideIcon,
} from "lucide-react";
import { can, ROLES, roleLabel, type Role, type Section } from "@/lib/roles";
import { setPersona } from "@/lib/actions";

type NavItem = { href: string; label: string; icon: LucideIcon; section: Section };
type NavGroup = { label?: string; items: NavItem[] };

const NAV: NavGroup[] = [
  { items: [{ href: "/dashboard", label: "Tableau de bord", icon: LayoutDashboard, section: "dashboard" }] },
  {
    label: "Scolarité",
    items: [
      { href: "/eleves", label: "Élèves & dossiers", icon: Users, section: "students" },
      { href: "/classes", label: "Classes", icon: GraduationCap, section: "classes" },
      { href: "/documents", label: "Documents & scans", icon: FolderOpen, section: "documents" },
    ],
  },
  {
    label: "Vie scolaire",
    items: [
      { href: "/presences", label: "Présences", icon: CalendarCheck, section: "attendance" },
      { href: "/emploi-du-temps", label: "Emploi du temps", icon: CalendarRange, section: "timetable" },
      { href: "/cahier-de-textes", label: "Cahier de textes", icon: BookOpen, section: "lessons" },
      { href: "/examens", label: "Examens", icon: ClipboardCheck, section: "exams" },
    ],
  },
  {
    label: "Pédagogie",
    items: [
      { href: "/notes", label: "Notes", icon: ClipboardList, section: "grades" },
      { href: "/bulletins", label: "Bulletins", icon: FileText, section: "reports" },
    ],
  },
  {
    label: "Finances",
    items: [
      { href: "/finances", label: "Scolarité & paiements", icon: Wallet, section: "finance" },
      { href: "/paie", label: "Paie & salaires", icon: Banknote, section: "payroll" },
    ],
  },
  {
    label: "Personnel",
    items: [{ href: "/personnel", label: "Équipe & contrats", icon: UserCog, section: "staff" }],
  },
  {
    label: "Communication",
    items: [{ href: "/communication", label: "Messages parents", icon: MessageSquare, section: "messages" }],
  },
  {
    label: "Établissement",
    items: [{ href: "/parametres", label: "Paramètres", icon: Settings, section: "settings" }],
  },
];

function isActive(pathname: string, href: string) {
  return pathname === href || pathname.startsWith(`${href}/`);
}

function Brand({ short }: { short: string }) {
  return (
    <Link href="/dashboard" className="flex items-center gap-2.5">
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-700 text-white shadow-sm">
        <GraduationCap className="h-5 w-5" strokeWidth={2} />
      </span>
      <span className="leading-tight">
        <span className="block font-display text-[15px] font-bold tracking-tight text-ink">Scolaris</span>
        <span className="block text-[10px] font-semibold uppercase tracking-[0.12em] text-ink/40">{short}</span>
      </span>
    </Link>
  );
}

function NavList({
  role,
  pathname,
  onNavigate,
}: {
  role: Role;
  pathname: string;
  onNavigate?: () => void;
}) {
  return (
    <nav className="space-y-5">
      {NAV.map((group, index) => {
        const items = group.items.filter((item) => can(role, item.section));
        if (items.length === 0) return null;
        return (
          <div key={group.label ?? `group-${index}`}>
            {group.label ? (
              <p className="mb-1.5 px-3 text-[10px] font-bold uppercase tracking-[0.12em] text-ink/35">
                {group.label}
              </p>
            ) : null}
            <div className="space-y-0.5">
              {items.map((item) => {
                const active = isActive(pathname, item.href);
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={onNavigate}
                    className={`nav-link ${active ? "nav-link-active" : ""}`}
                  >
                    <item.icon className="h-[18px] w-[18px]" strokeWidth={1.8} />
                    {item.label}
                  </Link>
                );
              })}
            </div>
          </div>
        );
      })}
    </nav>
  );
}

export function AppShell({
  children,
  shortName,
  schoolName,
  directorName,
  yearLabel,
  role,
}: {
  children: ReactNode;
  shortName: string;
  schoolName: string;
  directorName: string;
  yearLabel: string;
  role: Role;
}) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  return (
    <div className="min-h-screen bg-sand">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-ink/8 bg-white lg:flex">
        <div className="px-5 py-5">
          <Brand short={shortName} />
        </div>
        <div className="flex-1 overflow-y-auto px-3 pb-4">
          <NavList role={role} pathname={pathname} />
        </div>
        <div className="border-t border-ink/8 p-3">
          <div className="rounded-xl bg-gradient-to-br from-brand-800 to-brand-600 p-3.5 text-white">
            <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-wide text-white/70">
              <Sparkles className="h-3.5 w-3.5" /> Version démo
            </div>
            <p className="mt-1.5 text-sm font-semibold leading-snug">{schoolName}</p>
            <div className="mt-2 space-y-1">
              <Link href="/parents" className="flex items-center gap-1.5 text-[11px] font-semibold text-white/85 hover:text-white">
                <Smartphone className="h-3 w-3" /> Portail parents
              </Link>
              <Link href="/plateforme" className="flex items-center gap-1.5 text-[11px] font-semibold text-white/85 hover:text-white">
                <Building2 className="h-3 w-3" /> Console plateforme
              </Link>
            </div>
          </div>
        </div>
      </aside>

      {open ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-ink/40 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 left-0 flex w-72 flex-col bg-white shadow-2xl">
            <div className="flex items-center justify-between px-4 py-4">
              <Brand short={shortName} />
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="grid h-8 w-8 place-items-center rounded-lg text-ink/60 hover:bg-ink/5"
                aria-label="Fermer le menu"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto px-3 pb-6">
              <NavList role={role} pathname={pathname} onNavigate={() => setOpen(false)} />
            </div>
          </div>
        </div>
      ) : null}

      <div className="lg:pl-64">
        <header className="sticky top-0 z-30 border-b border-ink/8 bg-white/85 backdrop-blur">
          <div className="mx-auto flex h-16 w-full max-w-[1400px] items-center gap-3 px-4 sm:px-6 lg:px-8">
            <button
              type="button"
              onClick={() => setOpen(true)}
              className="grid h-9 w-9 place-items-center rounded-xl border border-ink/10 text-ink/70 lg:hidden"
              aria-label="Ouvrir le menu"
            >
              <Menu className="h-4 w-4" />
            </button>

            <form action="/eleves" className="relative hidden max-w-sm flex-1 sm:block">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/35" />
              <input
                name="q"
                placeholder="Rechercher un élève, un tuteur…"
                className="w-full rounded-xl border border-ink/10 bg-sand/60 py-2 pl-9 pr-3 text-sm outline-none transition placeholder:text-ink/35 focus:border-brand-400 focus:bg-white"
              />
            </form>

            <div className="ml-auto flex items-center gap-2 sm:gap-3">
              <span className="hidden items-center gap-1.5 rounded-full border border-ink/10 bg-white px-3 py-1.5 text-[11px] font-semibold text-ink/60 md:inline-flex">
                <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
                Année {yearLabel}
              </span>

              <form action={setPersona} className="relative">
                <select
                  name="role"
                  defaultValue={role}
                  onChange={(event) => {
                    event.currentTarget.form?.requestSubmit();
                  }}
                  aria-label="Changer de rôle"
                  className="appearance-none rounded-xl border border-ink/10 bg-white py-1.5 pl-3 pr-8 text-[12px] font-semibold text-ink/70 outline-none transition hover:border-ink/20 focus:border-brand-400"
                >
                  {ROLES.map((r) => (
                    <option key={r.key} value={r.key}>
                      {r.label}
                    </option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink/40" />
              </form>

              <Link
                href="/parents"
                title="Portail parents"
                className="hidden h-9 w-9 place-items-center rounded-xl border border-ink/10 bg-white text-ink/60 transition hover:text-ink sm:grid"
                aria-label="Portail parents"
              >
                <Smartphone className="h-4 w-4" />
              </Link>
              <Link
                href="/plateforme"
                title="Console plateforme"
                className="hidden h-9 w-9 place-items-center rounded-xl border border-ink/10 bg-white text-ink/60 transition hover:text-ink sm:grid"
                aria-label="Console plateforme"
              >
                <Building2 className="h-4 w-4" />
              </Link>
              <Link
                href="/communication"
                className="relative grid h-9 w-9 place-items-center rounded-xl border border-ink/10 bg-white text-ink/60 transition hover:text-ink"
                aria-label="Messages"
              >
                <Bell className="h-4 w-4" />
                <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-amber-brand" />
              </Link>

              <div className="flex items-center gap-2">
                <span className="grid h-9 w-9 place-items-center rounded-full bg-brand-100 text-xs font-bold text-brand-800">
                  {directorName
                    .split(" ")
                    .filter(Boolean)
                    .slice(0, 2)
                    .map((w) => w.charAt(0))
                    .join("")
                    .toUpperCase()}
                </span>
                <span className="hidden leading-tight md:block">
                  <span className="block text-xs font-semibold text-ink">{directorName}</span>
                  <span className="block text-[10px] font-medium uppercase tracking-wide text-ink/40">
                    {roleLabel(role)}
                  </span>
                </span>
              </div>
            </div>
          </div>
        </header>

        <main className="mx-auto w-full max-w-[1400px] px-4 py-6 sm:px-6 lg:px-8 lg:py-8">{children}</main>

        <footer className="mx-auto flex w-full max-w-[1400px] flex-col gap-1 px-4 pb-8 pt-2 text-[11px] text-ink/40 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
          <span>Scolaris · plateforme de gestion des écoles privées</span>
          <span>{shortName} · données de démonstration</span>
        </footer>
      </div>
    </div>
  );
}
