"use client";

import { useFormStatus } from "react-dom";
import type { ReactNode } from "react";
import { Loader2, Printer } from "lucide-react";

export function SubmitButton({
  children,
  className = "btn-primary",
  pendingLabel,
  formAction,
  name,
  value,
}: {
  children: ReactNode;
  className?: string;
  pendingLabel?: string;
  formAction?: (formData: FormData) => void | Promise<void>;
  name?: string;
  value?: string;
}) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      name={name}
      value={value}
      formAction={formAction}
      disabled={pending}
      className={className}
    >
      {pending ? (
        <>
          <Loader2 className="h-4 w-4 animate-spin" />
          {pendingLabel ?? "Enregistrement…"}
        </>
      ) : (
        children
      )}
    </button>
  );
}

export function PrintButton() {
  return (
    <button type="button" onClick={() => window.print()} className="btn-outline no-print">
      <Printer className="h-4 w-4" />
      Imprimer
    </button>
  );
}
