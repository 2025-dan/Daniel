import Link from "next/link";
import {
  ArrowRight,
  BookOpen,
  CalendarCheck,
  CalendarRange,
  CheckCircle2,
  CreditCard,
  FileText,
  LogOut,
  FolderOpen,
  MessageSquare,
  Receipt,
  Smartphone,
  Wallet,
} from "lucide-react";
import { SubmitButton } from "@/components/forms";
import {
  parentLogin,
  parentLoginDirect,
  parentLogout,
  parentPayInvoice,
} from "@/lib/actions";
import { DAYS } from "@/lib/data/school-life";
import {
  getParentPortalData,
  getParentStudentId,
  getParentStudentOptions,
} from "@/lib/data/parent";
import { getRecentPayments } from "@/lib/data/finance";
import {
  CHANNEL_LABEL,
  dueLabel,
  formatDate,
  gradeLabel,
  money,
  percent,
  relativeTime,
} from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = {
  searchParams: Promise<{ erreur?: string; paiement?: string; vue?: string }>;
};

const TABS = [
  { key: "accueil", label: "Accueil" },
  { key: "paiements", label: "Paiements" },
  { key: "notes", label: "Notes" },
  { key: "devoirs", label: "Devoirs" },
  { key: "planning", label: "Planning" },
  { key: "documents", label: "Documents" },
];

export default async function ParentPortalPage({ searchParams }: Props) {
  const [params, studentId, demoStudents] = await Promise.all([
    searchParams,
    getParentStudentId(),
    getParentStudentOptions(6),
  ]);

  if (!studentId) {
    return (
      <>
        <div className="rounded-2xl bg-gradient-to-br from-brand-800 to-brand-600 p-6 text-white shadow-lg">
          <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-white/70">
            <Smartphone className="h-3.5 w-3.5" /> Espace famille
          </p>
          <h1 className="mt-2 font-display text-2xl font-bold leading-tight">La scolarité de votre enfant, dans votre poche.</h1>
          <p className="mt-2 text-sm leading-relaxed text-white/75">
            Consultez les soldes, payez par mobile money, suivez les notes, les absences et les devoirs.
          </p>
        </div>

        <form action={parentLogin} className="card mt-4 space-y-3 p-5">
          <div>
            <label className="label" htmlFor="matricule">Matricule de l&apos;élève</label>
            <input id="matricule" name="matricule" className="input" placeholder="GSLP-2026-001" required />
          </div>
          {params.erreur ? (
            <p className="rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">{params.erreur}</p>
          ) : null}
          <SubmitButton className="btn-primary w-full" pendingLabel="Connexion…">
            Accéder au dossier <ArrowRight className="h-4 w-4" />
          </SubmitButton>
          <p className="text-[11px] leading-relaxed text-ink/45">
            Démo : utilisez le matricule <strong className="text-ink/70">GSLP-2026-001</strong> ou choisissez un
            élève ci-dessous.
          </p>
        </form>

        <div className="card mt-4 p-4">
          <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.1em] text-ink/40">Accès rapide démo</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {demoStudents.map((student) => (
              <form action={parentLoginDirect} key={student.id}>
                <input type="hidden" name="studentId" value={student.id} />
                <button type="submit" className="flex w-full items-center justify-between gap-2 rounded-xl border border-ink/10 px-3 py-2 text-left transition hover:border-brand-300 hover:bg-brand-50/50">
                  <span>
                    <span className="block text-xs font-semibold text-ink">{student.lastName} {student.firstName}</span>
                    <span className="block text-[10px] text-ink/45">{student.matricule}</span>
                  </span>
                  {student.className ? <span className="text-[10px] font-bold text-brand-700">{student.className}</span> : null}
                </button>
              </form>
            ))}
          </div>
        </div>
      </>
    );
  }

  const data = await getParentPortalData(studentId);
  if (!data) {
    return (
      <div className="card mt-10 p-6 text-center">
        <p className="text-sm text-ink/60">Dossier introuvable.</p>
        <form action={parentLogout} className="mt-3">
          <SubmitButton className="btn-outline" pendingLabel="…">Changer d&apos;élève</SubmitButton>
        </form>
      </div>
    );
  }

  const vue = params.vue && TABS.some((t) => t.key === params.vue) ? params.vue : "accueil";
  const { student, enrollment, finance, myResult, results, invoices, timetable, homework, messages } = data;
  const unpaid = invoices.filter((i) => i.amountPaid < i.amount);
  const nextDue = unpaid.find((i) => i.dueDate >= new Date().toISOString().slice(0, 10)) ?? unpaid[0];
  const recentPayments = await getRecentPayments(4);
  const schoolPayments = recentPayments;

  return (
    <>
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-full bg-brand-100 text-sm font-bold text-brand-800">
            {student.firstName.charAt(0)}{student.lastName.charAt(0)}
          </span>
          <div>
            <p className="text-sm font-bold text-ink">{student.lastName} {student.firstName}</p>
            <p className="text-[11px] text-ink/45">
              {enrollment ? `${enrollment.className} · ${enrollment.cycle}` : "Sans classe"} · {student.matricule}
            </p>
          </div>
        </div>
        <form action={parentLogout}>
          <SubmitButton className="btn-ghost btn-sm" pendingLabel="…">
            <LogOut className="h-3.5 w-3.5" /> Quitter
          </SubmitButton>
        </form>
      </div>

      <div className="mt-4 flex gap-1 overflow-x-auto rounded-xl bg-ink/5 p-1">
        {TABS.map((tab) => (
          <Link
            key={tab.key}
            href={`/parents?vue=${tab.key}`}
            className={`whitespace-nowrap rounded-lg px-3 py-1.5 text-[11px] font-bold transition ${
              vue === tab.key ? "bg-white text-ink shadow-sm" : "text-ink/50 hover:text-ink"
            }`}
          >
            {tab.label}
          </Link>
        ))}
      </div>

      {params.paiement ? (
        <div className="mt-4 flex items-start gap-2 rounded-xl border border-brand-200 bg-brand-50 px-3.5 py-3 text-xs text-brand-800">
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
          Paiement effectué. Le reçu est disponible et la comptabilité de l&apos;école a été informée.
        </div>
      ) : null}

      {vue === "accueil" ? (
        <div className="mt-4 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-2xl bg-gradient-to-br from-brand-800 to-brand-600 p-4 text-white">
              <p className="text-[10px] font-bold uppercase tracking-wide text-white/60">Solde à régler</p>
              <p className="mt-1 font-display text-xl font-bold">{money(finance.balance)}</p>
              <p className="mt-1 text-[10px] text-white/60">{unpaid.length} facture(s) en cours</p>
              <Link href="/parents?vue=paiements" className="mt-3 inline-flex items-center gap-1 rounded-lg bg-white px-2.5 py-1.5 text-[11px] font-bold text-brand-800">
                <CreditCard className="h-3.5 w-3.5" /> Payer
              </Link>
            </div>
            <div className="card p-4">
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Assiduité</p>
              <p className="mt-1 font-display text-xl font-bold text-ink">{data.attendanceRate}%</p>
              <p className="mt-1 text-[10px] text-ink/45">{data.absences} absence(s) cumulée(s)</p>
              <Link href="/parents?vue=planning" className="mt-3 inline-flex items-center gap-1 rounded-lg bg-ink/5 px-2.5 py-1.5 text-[11px] font-bold text-ink/60">
                <CalendarRange className="h-3.5 w-3.5" /> Planning
              </Link>
            </div>
          </div>

          {nextDue ? (
            <div className="card p-4">
              <div className="flex items-center justify-between gap-2">
                <p className="text-[10px] font-bold uppercase tracking-tight text-ink/40">Prochaine échéance</p>
                <span className="badge bg-amber-100 text-amber-800">{dueLabel(nextDue.dueDate)}</span>
              </div>
              <p className="mt-1 text-sm font-semibold text-ink">{nextDue.label}</p>
              <p className="text-[11px] text-ink/45">{nextDue.number} · {formatDate(nextDue.dueDate)}</p>
              <div className="mt-2 flex items-end justify-between">
                <p className="font-display text-lg font-bold text-ink">{money(nextDue.amount - nextDue.amountPaid)}</p>
                <Link href="/parents?vue=paiements" className="btn-primary btn-sm">
                  <Wallet className="h-3.5 w-3.5" /> Régler maintenant
                </Link>
              </div>
            </div>
          ) : (
            <div className="card flex items-center gap-3 p-4">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-brand-100 text-brand-700">
                <CheckCircle2 className="h-4 w-4" />
              </span>
              <p className="text-xs text-ink/60">La scolarité est à jour. Merci !</p>
            </div>
          )}

          <div className="card p-4">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Moyenne — Trimestre 1</p>
              <span className="badge bg-brand-100 text-brand-800">{myResult?.rank ?? "—"}ᵉ / {results?.students.length ?? 0}</span>
            </div>
            <p className="mt-1 font-display text-2xl font-bold text-ink">{gradeLabel(myResult?.average)}/20</p>
            <p className="text-[11px] text-ink/45">Moyenne de classe : {gradeLabel(results?.classAverage)}/20</p>
            <div className="mt-3 space-y-1.5">
              {(results?.subjects ?? []).slice(0, 4).map((subject) => {
                const avg = myResult?.subjectAverages[subject.id] ?? null;
                return (
                  <div key={subject.id} className="flex items-center justify-between text-[11px]">
                    <span className="text-ink/60">{subject.name}</span>
                    <span className={`font-bold ${(avg ?? 0) >= 10 ? "text-brand-700" : "text-red-600"}`}>{gradeLabel(avg)}</span>
                  </div>
                );
              })}
            </div>
            <Link href="/parents?vue=notes" className="mt-3 inline-flex items-center gap-1 text-[11px] font-bold text-brand-700">
              Voir le bulletin <ArrowRight className="h-3 w-3" />
            </Link>
          </div>

          <div className="card p-4">
            <p className="mb-2 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-ink/40">
              <MessageSquare className="h-3.5 w-3.5" /> Messages de l&apos;école
            </p>
            <div className="space-y-2">
              {messages.slice(0, 3).map((message) => (
                <div key={message.id} className="rounded-xl bg-sand/70 px-3 py-2">
                  <p className="text-xs font-semibold text-ink">{message.subject}</p>
                  <p className="mt-0.5 line-clamp-2 text-[11px] text-ink/55">{message.body}</p>
                  <p className="mt-1 text-[9px] uppercase tracking-wide text-ink/35">
                    {CHANNEL_LABEL[message.channel] ?? message.channel} · {relativeTime(message.sentAt)}
                  </p>
                </div>
              ))}
              {messages.length === 0 ? <p className="text-xs text-ink/45">Aucun message pour l&apos;instant.</p> : null}
            </div>
          </div>
        </div>
      ) : null}

      {vue === "paiements" ? (
        <div className="mt-4 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="card p-4">
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Total facturé</p>
              <p className="mt-1 font-display text-lg font-bold text-ink">{money(finance.invoiced)}</p>
            </div>
            <div className="card p-4">
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Déjà réglé</p>
              <p className="mt-1 font-display text-lg font-bold text-brand-700">{money(finance.paid)}</p>
              <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-ink/8">
                <div className="h-full rounded-full bg-brand-500" style={{ width: `${percent(finance.paid, Math.max(1, finance.invoiced))}%` }} />
              </div>
            </div>
          </div>

          {invoices.map((invoice) => {
            const balance = invoice.amount - invoice.amountPaid;
            return (
              <div key={invoice.id} className="card p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-sm font-semibold text-ink">{invoice.label}</p>
                    <p className="text-[11px] text-ink/45">{invoice.number} · échéance {formatDate(invoice.dueDate)}</p>
                  </div>
                  <span className={`badge ${invoice.status === "payée" ? "bg-brand-100 text-brand-800" : invoice.status === "partielle" ? "bg-amber-100 text-amber-800" : "bg-red-100 text-red-700"}`}>
                    {invoice.status}
                  </span>
                </div>
                <div className="mt-2 flex items-end justify-between gap-2">
                  <div>
                    <p className="text-[10px] uppercase tracking-wide text-ink/35">Reste à payer</p>
                    <p className="font-display text-lg font-bold text-ink">{money(balance)}</p>
                  </div>
                  <p className="text-[10px] text-ink/40">sur {money(invoice.amount)}</p>
                </div>
                {balance > 0 ? (
                  <form action={parentPayInvoice} className="mt-3 space-y-2">
                    <input type="hidden" name="invoiceId" value={invoice.id} />
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="label" htmlFor={`amount-${invoice.id}`}>Montant</label>
                        <input id={`amount-${invoice.id}`} name="amount" type="number" min={500} max={balance} step={500} defaultValue={balance} className="input py-2 text-sm" />
                      </div>
                      <div>
                        <label className="label" htmlFor={`method-${invoice.id}`}>Moyen</label>
                        <select id={`method-${invoice.id}`} name="method" className="input py-2 text-sm" defaultValue="mobile money">
                          <option value="mobile money">Mobile money</option>
                          <option value="virement">Virement</option>
                        </select>
                      </div>
                    </div>
                    <SubmitButton className="btn-primary w-full" pendingLabel="Paiement sécurisé…">
                      <CreditCard className="h-4 w-4" /> Payer {money(balance)}
                    </SubmitButton>
                  </form>
                ) : (
                  <p className="mt-2 flex items-center gap-1 text-[11px] font-semibold text-brand-700">
                    <CheckCircle2 className="h-3.5 w-3.5" /> Facture soldée
                  </p>
                )}
              </div>
            );
          })}

          <div className="card p-4">
            <p className="mb-2 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-ink/40">
              <Receipt className="h-3.5 w-3.5" /> Encaissements récents de l&apos;établissement
            </p>
            <p className="text-[11px] text-ink/45">Les paiements en ligne apparaissent directement dans la comptabilité.</p>
            <div className="mt-2 space-y-1.5">
              {schoolPayments.slice(0, 3).map((payment) => (
                <div key={payment.id} className="flex items-center justify-between text-[11px]">
                  <span className="text-ink/55">
                    {payment.firstName} {payment.lastName} · {formatDate(payment.paidAt)}
                  </span>
                  <span className="font-bold text-brand-700">{money(payment.amount)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : null}

      {vue === "notes" ? (
        <div className="mt-4 space-y-4">
          <div className="card p-4">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Bulletin — Trimestre 1</p>
              <span className="badge bg-brand-100 text-brand-800">{myResult?.rank ?? "—"}ᵉ / {results?.students.length ?? 0}</span>
            </div>
            <p className="mt-1 font-display text-2xl font-bold text-ink">{gradeLabel(myResult?.average)}/20</p>
            <p className="text-[11px] text-ink/45">Moyenne de classe {gradeLabel(results?.classAverage)}/20</p>
          </div>
          <div className="card divide-y divide-ink/6">
            {(results?.subjects ?? []).map((subject) => {
              const avg = myResult?.subjectAverages[subject.id] ?? null;
              return (
                <div key={subject.id} className="flex items-center justify-between gap-2 px-4 py-3">
                  <div>
                    <p className="text-sm font-medium text-ink">{subject.name}</p>
                    <p className="text-[10px] text-ink/40">Coef. {subject.coefficient} · moy. classe {gradeLabel(subject.classAverage)}</p>
                  </div>
                  <span className={`font-display text-base font-bold ${(avg ?? 0) >= 10 ? "text-brand-700" : "text-red-600"}`}>
                    {gradeLabel(avg)}
                  </span>
                </div>
              );
            })}
          </div>
          <Link href={`/bulletins/${student.id}?term=Trimestre%201`} className="btn-outline w-full justify-center">
            <FileText className="h-4 w-4" /> Ouvrir le bulletin imprimable
          </Link>
        </div>
      ) : null}

      {vue === "devoirs" ? (
        <div className="mt-4 space-y-3">
          <div className="card p-4">
            <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-ink/40">
              <BookOpen className="h-3.5 w-3.5" /> Devoirs à faire
            </p>
            <p className="mt-1 text-[11px] text-ink/45">Cahier de textes de la classe {enrollment?.className}.</p>
          </div>
          {homework.map((item) => (
            <div key={item.id} className="card p-4">
              <div className="flex items-center justify-between gap-2">
                <span className="badge bg-brand-50 text-brand-700">{item.subjectName ?? "Matière"}</span>
                {item.dueDate ? <span className="badge bg-amber-100 text-amber-800">À rendre le {formatDate(item.dueDate)}</span> : null}
              </div>
              <p className="mt-1.5 text-sm font-semibold text-ink">{item.title}</p>
              <p className="mt-1 text-xs leading-relaxed text-ink/60">{item.homework}</p>
              <p className="mt-1.5 text-[10px] uppercase tracking-wide text-ink/30">Séance du {formatDate(item.date)}</p>
            </div>
          ))}
          {homework.length === 0 ? <p className="text-center text-sm text-ink/50">Aucun devoir enregistré.</p> : null}
        </div>
      ) : null}

      {vue === "documents" ? (
        <div className="mt-4 space-y-3">
          <div className="card p-4">
            <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-ink/40">
              <FolderOpen className="h-3.5 w-3.5" /> Documents partagés par l&apos;école
            </p>
            <p className="mt-1 text-[11px] text-ink/45">
              Bulletins numérisés, actes et pièces du dossier de {student.firstName}.
            </p>
          </div>
          {data.sharedDocuments.map((doc) => (
            <div key={doc.id} className="card flex items-center justify-between gap-3 p-4">
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-ink">{doc.title}</p>
                <p className="text-[11px] text-ink/45">
                  {doc.term ? `${doc.term} · ` : ""}
                  {doc.average !== null ? `moyenne ${gradeLabel(doc.average)}/20 · ` : ""}
                  {formatDate(doc.createdAt)}
                </p>
              </div>
              <a href={`/api/documents/${doc.id}`} target="_blank" className="btn-outline btn-sm shrink-0">
                <FileText className="h-3.5 w-3.5" /> Ouvrir
              </a>
            </div>
          ))}
          {data.sharedDocuments.length === 0 ? (
            <p className="text-center text-sm text-ink/50">Aucun document partagé pour le moment.</p>
          ) : null}
        </div>
      ) : null}

      {vue === "planning" ? (
        <div className="mt-4 space-y-3">
          <div className="card p-4">
            <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-ink/40">
              <CalendarRange className="h-3.5 w-3.5" /> Emploi du temps — {enrollment?.className}
            </p>
            <p className="mt-1 text-[11px] text-ink/45">Salle {enrollment?.room || "—"} · titulaire {enrollment?.teacher || "—"}</p>
          </div>
          {DAYS.map((day) => {
            const slots = timetable.filter((slot) => slot.day === day.value);
            if (slots.length === 0) return null;
            return (
              <div key={day.value} className="card p-4">
                <p className="text-xs font-bold uppercase tracking-wide text-ink/50">{day.label}</p>
                <div className="mt-2 space-y-1.5">
                  {slots.map((slot) => (
                    <div key={slot.id} className="flex items-center gap-3 rounded-lg bg-sand/60 px-3 py-2">
                      <span className="w-20 shrink-0 text-[10px] font-bold text-ink/45">{slot.startTime}–{slot.endTime}</span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-xs font-semibold text-ink">{slot.subjectName ?? "Créneau libre"}</p>
                        <p className="text-[10px] text-ink/40">{slot.teacher || "—"} · {slot.room || "—"}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
          {timetable.length === 0 ? <p className="text-center text-sm text-ink/50">Emploi du temps non publié.</p> : null}
          <div className="card flex items-center gap-3 p-4">
            <span className="grid h-9 w-9 place-items-center rounded-full bg-brand-100 text-brand-700">
              <CalendarCheck className="h-4 w-4" />
            </span>
            <div>
              <p className="text-xs font-semibold text-ink">Assiduité {data.attendanceRate}%</p>
              <p className="text-[10px] text-ink/45">{data.absences} absence(s) enregistrée(s) cette année</p>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
