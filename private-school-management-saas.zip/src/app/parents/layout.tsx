import type { ReactNode } from "react";
import Link from "next/link";
import { GraduationCap, Smartphone } from "lucide-react";

export const metadata = {
  title: "Portail parents — Scolaris",
  description: "Suivi de la scolarité, paiement en ligne, notes, absences et devoirs.",
};

export default function ParentLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-sand">
      <header className="sticky top-0 z-30 border-b border-ink/8 bg-white/90 backdrop-blur">
        <div className="mx-auto flex h-14 w-full max-w-2xl items-center justify-between px-4">
          <Link href="/parents" className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand-700 text-white">
              <GraduationCap className="h-4 w-4" />
            </span>
            <span className="leading-tight">
              <span className="block font-display text-sm font-bold text-ink">Scolaris</span>
              <span className="block text-[9px] font-semibold uppercase tracking-[0.12em] text-ink/40">Portail parents</span>
            </span>
          </Link>
          <div className="flex items-center gap-2">
            <Link href="/dashboard" className="btn-ghost btn-sm">
              Espace école
            </Link>
            <span className="hidden items-center gap-1 rounded-full bg-brand-50 px-2 py-1 text-[9px] font-bold uppercase tracking-wide text-brand-700 sm:inline-flex">
              <Smartphone className="h-3 w-3" /> Mobile
            </span>
          </div>
        </div>
      </header>
      <main className="mx-auto w-full max-w-2xl px-4 py-5 pb-16">{children}</main>
      <footer className="mx-auto w-full max-w-2xl px-4 pb-8 text-center text-[10px] text-ink/35">
        Scolaris · portail parents de démonstration · données fictives
      </footer>
    </div>
  );
}
