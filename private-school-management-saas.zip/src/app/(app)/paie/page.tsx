import Link from "next/link";
import { Banknote, CheckCircle2, Clock, Download, Users, Wallet } from "lucide-react";
import { Avatar, Badge, EmptyState, Notice, PageHeader, ProgressBar, SectionCard, StatCard } from "@/components/ui";
import { PrintButton, SubmitButton } from "@/components/forms";
import { Restricted } from "@/components/restricted";
import { generatePayroll, payAllPayrolls, payPayroll } from "@/lib/actions";
import { currentPeriod, getPayrollPageData, periodLabel } from "@/lib/data/staff";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import { PAYMENT_METHODS, CHANNEL_LABEL, formatDate, money, percent } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<{ period?: string; genere?: string; paie?: string }> };

export default async function PayrollPage({ searchParams }: Props) {
  const [role, params] = await Promise.all([getRole(), searchParams]);
  if (!can(role, "payroll")) return <Restricted role={role} module="Paie & salaires" />;

  const data = await getPayrollPageData(params.period);
  const { totals } = data;
  const periodChoices = Array.from(new Set([currentPeriod(), currentPeriod(-1), currentPeriod(-2), ...data.periods]));

  return (
    <>
      <PageHeader
        eyebrow="Ressources humaines"
        title="Paie & salaires"
        subtitle="Générez les bulletins du mois, contrôlez les retenues et réglez les salaires de votre équipe."
        actions={
          <>
            <PrintButton />
            <Link href="/personnel" className="btn-outline">
              <Users className="h-4 w-4" /> Équipe
            </Link>
            <form action={generatePayroll} className="flex items-center gap-2">
              <input type="hidden" name="period" value={data.period} />
              <SubmitButton className="btn-primary" pendingLabel="Génération…">
                <Download className="h-4 w-4" /> Générer {periodLabel(data.period)}
              </SubmitButton>
            </form>
          </>
        }
      />

      {params.genere ? (
        <div className="mb-4">
          <Notice>
            {Number(params.genere) > 0
              ? `${params.genere} bulletin(s) de paie généré(s) pour ${periodLabel(data.period)}.`
              : "Tous les bulletins de cette période existent déjà : aucun doublon créé."}
          </Notice>
        </div>
      ) : null}
      {params.paie ? (
        <div className="mb-4">
          <Notice>Paiement enregistré. Les salaires concernés sont désormais marqués comme payés.</Notice>
        </div>
      ) : null}

      <div className="card mb-4 flex flex-col gap-3 p-4 lg:flex-row lg:items-end lg:justify-between">
        <form className="flex flex-col gap-2 sm:flex-row sm:items-end">
          <div className="sm:w-52">
            <label className="label" htmlFor="period">Période de paie</label>
            <select id="period" name="period" className="input" defaultValue={data.period}>
              {periodChoices.map((period) => (
                <option key={period} value={period}>{periodLabel(period)}</option>
              ))}
            </select>
          </div>
          <button type="submit" className="btn-outline">
            <Banknote className="h-4 w-4" /> Afficher
          </button>
        </form>
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-ink/50">
            {data.payrolls.length}/{data.activeStaffCount} bulletins générés ·{" "}
            {data.missing.length > 0 ? `${data.missing.length} à générer` : "complet"}
          </span>
          {totals.pending > 0 ? (
            <form action={payAllPayrolls} className="flex items-center gap-2">
              <input type="hidden" name="period" value={data.period} />
              <select name="method" className="input w-32 py-2 text-xs" defaultValue="virement" aria-label="Moyen de paiement">
                {PAYMENT_METHODS.map((method) => (
                  <option key={method} value={method}>{CHANNEL_LABEL[method] ?? method}</option>
                ))}
              </select>
              <SubmitButton className="btn-primary" pendingLabel="Règlement…">
                <CheckCircle2 className="h-4 w-4" /> Tout payer ({money(totals.pending, false)})
              </SubmitButton>
            </form>
          ) : (
            <Badge tone="success">Toute la paie est réglée</Badge>
          )}
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Masse salariale brute" value={money(totals.gross)} hint={`${periodLabel(data.period)} · ${totals.count} bulletins`} icon={Banknote} />
        <StatCard label="Net à payer" value={money(totals.net)} hint={`Primes ${money(totals.bonuses, false)} · retenues ${money(totals.deductions, false)}`} icon={Wallet} tone="sky" />
        <StatCard
          label="Déjà payé"
          value={money(totals.paid)}
          hint={`${totals.paidCount} bulletin(s) réglé(s)`}
          icon={CheckCircle2}
          tone="brand"
          footer={<ProgressBar value={percent(totals.paid, Math.max(1, totals.net))} />}
        />
        <StatCard label="Reste à payer" value={money(totals.pending)} hint={`${totals.count - totals.paidCount} bulletin(s) en attente`} icon={Clock} tone="amber" />
      </div>

      <SectionCard
        title={`Bulletins de paie — ${periodLabel(data.period)}`}
        description="Brut, primes, retenues sociales et net à payer par membre"
        className="mt-4"
        bodyClassName="overflow-x-auto"
      >
        {data.payrolls.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={Banknote}
              title="Aucun bulletin pour cette période"
              description="Cliquez sur « Générer » pour créer les bulletins de tous les membres actifs."
              action={
                <form action={generatePayroll}>
                  <input type="hidden" name="period" value={data.period} />
                  <SubmitButton className="btn-primary" pendingLabel="Génération…">
                    <Download className="h-4 w-4" /> Générer la paie
                  </SubmitButton>
                </form>
              }
            />
          </div>
        ) : (
          <table className="w-full min-w-[940px] border-collapse">
            <thead className="bg-sand/60">
              <tr>
                <th className="th">Membre</th>
                <th className="th">Fonction</th>
                <th className="th text-right">Brut</th>
                <th className="th text-right">Primes</th>
                <th className="th text-right">Retenues</th>
                <th className="th text-right">Net à payer</th>
                <th className="th">Statut</th>
                <th className="th text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/6">
              {data.payrolls.map((payroll) => (
                <tr key={payroll.id} className="row-hover">
                  <td className="td">
                    <div className="flex items-center gap-2.5">
                      <Avatar first={payroll.firstName} last={payroll.lastName} size="sm" />
                      <div>
                        <p className="font-semibold text-ink">{payroll.lastName} {payroll.firstName}</p>
                        <p className="text-[11px] text-ink/45">{payroll.reference || "Référence à générer"}</p>
                      </div>
                    </div>
                  </td>
                  <td className="td text-xs text-ink/60">{payroll.jobTitle}</td>
                  <td className="td text-right whitespace-nowrap">{money(payroll.grossSalary)}</td>
                  <td className="td text-right whitespace-nowrap text-brand-700">{money(payroll.bonuses)}</td>
                  <td className="td text-right whitespace-nowrap text-red-600">{money(payroll.deductions)}</td>
                  <td className="td text-right whitespace-nowrap font-bold">{money(payroll.netSalary)}</td>
                  <td className="td">
                    <Badge tone={payroll.status === "payé" ? "success" : "warning"}>{payroll.status}</Badge>
                    {payroll.paidAt ? <p className="mt-0.5 text-[10px] text-ink/40">{formatDate(payroll.paidAt)}</p> : null}
                  </td>
                  <td className="td text-right">
                    {payroll.status === "payé" ? (
                      <span className="text-[11px] font-semibold text-brand-700">{CHANNEL_LABEL[payroll.method] ?? payroll.method}</span>
                    ) : (
                      <form action={payPayroll} className="flex items-center justify-end gap-1.5">
                        <input type="hidden" name="payrollId" value={payroll.id} />
                        <input type="hidden" name="period" value={data.period} />
                        <select name="method" className="input w-24 py-1 text-[11px]" defaultValue="virement" aria-label="Moyen">
                          {PAYMENT_METHODS.map((method) => (
                            <option key={method} value={method}>{CHANNEL_LABEL[method] ?? method}</option>
                          ))}
                        </select>
                        <SubmitButton className="btn-soft btn-sm" pendingLabel="…">Payer</SubmitButton>
                      </form>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-sand/60">
              <tr>
                <td className="td font-semibold" colSpan={2}>{data.payrolls.length} bulletins</td>
                <td className="td text-right font-bold">{money(totals.gross, false)}</td>
                <td className="td text-right font-bold text-brand-700">{money(totals.bonuses, false)}</td>
                <td className="td text-right font-bold text-red-600">{money(totals.deductions, false)}</td>
                <td className="td text-right font-bold">{money(totals.net, false)}</td>
                <td className="td" colSpan={2} />
              </tr>
            </tfoot>
          </table>
        )}
      </SectionCard>

      {data.missing.length > 0 ? (
        <SectionCard title="Membres sans bulletin sur la période" className="mt-4" bodyClassName="divide-y divide-ink/6">
          {data.missing.map((member) => (
            <div key={member.id} className="flex items-center justify-between gap-2 px-5 py-2.5">
              <div>
                <p className="text-sm font-semibold text-ink">{member.lastName} {member.firstName}</p>
                <p className="text-[11px] text-ink/45">{member.jobTitle} · {member.status}</p>
              </div>
              <span className="text-sm font-semibold text-ink/60">{money(member.monthlySalary)}</span>
            </div>
          ))}
        </SectionCard>
      ) : null}
    </>
  );
}
