import Link from "next/link";
import {
  BellRing,
  Filter,
  HandCoins,
  Receipt,
  Search,
  Send,
  TrendingUp,
  Wallet,
} from "lucide-react";
import { Avatar, Badge, EmptyState, Notice, PageHeader, SectionCard, StatCard, Tabs } from "@/components/ui";
import { CollectionBars } from "@/components/charts";
import { SubmitButton } from "@/components/forms";
import { Restricted } from "@/components/restricted";
import { createInvoice, recordPayment, sendBulkReminders, sendReminder } from "@/lib/actions";
import {
  getFinanceTotals,
  getInvoiceRows,
  getMonthlyCollections,
  getPaymentMethodBreakdown,
  getRecentPayments,
  getReminders,
  getUnpaidInvoiceOptions,
} from "@/lib/data/finance";
import { getStudentOptions } from "@/lib/data/students";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import {
  CHANNEL_LABEL,
  INVOICE_TONE,
  PAYMENT_METHODS,
  dueLabel,
  formatDate,
  money,
  percent,
  todayISO,
} from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = {
  searchParams: Promise<{ statut?: string; q?: string; relances?: string; erreur?: string; facture?: string }>;
};

const STATUS_TABS = [
  { key: "toutes", label: "Toutes" },
  { key: "impayées", label: "À encaisser" },
  { key: "retard", label: "En retard" },
  { key: "payée", label: "Payées" },
  { key: "partielle", label: "Partielles" },
];

export default async function FinancePage({ searchParams }: Props) {
  const [role, params] = await Promise.all([getRole(), searchParams]);
  if (!can(role, "finance")) return <Restricted role={role} module="Scolarité & paiements" />;

  const statut = params.statut ?? "toutes";
  const [totals, invoices, payments, monthly, methods, options, reminderRows, studentOptions] = await Promise.all([
    getFinanceTotals(),
    getInvoiceRows({ q: params.q, statut }),
    getRecentPayments(12),
    getMonthlyCollections(),
    getPaymentMethodBreakdown(),
    getUnpaidInvoiceOptions(),
    getReminders(5),
    getStudentOptions(),
  ]);

  return (
    <>
      <PageHeader
        eyebrow="Finances"
        title="Scolarité & paiements"
        subtitle="Suivez les encaissements, repérez les impayés et relancez les familles en quelques secondes."
        actions={
          <>
            <Link href="/finances?statut=retard" className="btn-outline">
              <BellRing className="h-4 w-4" /> Impayés ({totals.overdueCount})
            </Link>
            <form action={sendBulkReminders} className="flex items-center gap-2">
              <input type="hidden" name="redirectTo" value="/finances" />
              <select name="channel" className="input w-28 py-2 text-xs" defaultValue="sms" aria-label="Canal de relance">
                <option value="sms">SMS</option>
                <option value="email">E-mail</option>
                <option value="app">Notification</option>
              </select>
              <SubmitButton className="btn-primary" pendingLabel="Envoi groupé…">
                <Send className="h-4 w-4" /> Relancer les retards
              </SubmitButton>
            </form>
          </>
        }
      />

      {params.relances ? (
        <div className="mb-4">
          <Notice>
            {Number(params.relances) > 0
              ? `${params.relances} relance(s) envoyée(s) aux familles en retard et journalisées dans la communication.`
              : "Aucune facture échue à relancer pour le moment."}
          </Notice>
        </div>
      ) : null}
      {params.erreur ? (
        <div className="mb-4">
          <Notice tone="danger">{params.erreur}</Notice>
        </div>
      ) : null}
      {params.facture ? (
        <div className="mb-4">
          <Notice>La facture a été créée et rattachée au dossier de l&apos;élève.</Notice>
        </div>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total facturé" value={money(totals.invoiced)} hint={`${totals.invoiceCount} factures émises`} icon={Receipt} />
        <StatCard label="Encaissé" value={money(totals.paid)} hint={`${money(totals.collected30)} sur 30 jours`} icon={HandCoins} tone="sky" />
        <StatCard
          label="Reste à recouvrer"
          value={money(totals.balance)}
          hint={`dont ${money(totals.overdueAmount)} échus`}
          icon={Wallet}
          tone="amber"
        />
        <StatCard label="Taux de recouvrement" value={`${totals.recoveryRate}%`} hint={`${totals.remindersCount} relances envoyées (30 j)`} icon={TrendingUp} tone="brand" />
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-[1.35fr_1fr]">
        <SectionCard title="Encaissements mensuels" description="6 derniers mois, tous moyens de paiement">
          <CollectionBars data={monthly} />
          <div className="mt-5 border-t border-ink/8 pt-4">
            <p className="mb-3 text-[10px] font-bold uppercase tracking-wide text-ink/40">Répartition par moyen de paiement</p>
            <div className="space-y-2.5">
              {methods.map((method) => (
                <div key={method.method}>
                  <div className="flex items-center justify-between text-[11px] font-semibold text-ink/55">
                    <span>{CHANNEL_LABEL[method.method] ?? method.method} · {method.count} opérations</span>
                    <span>{money(method.total, false)}</span>
                  </div>
                  <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-ink/8">
                    <div
                      className="h-full rounded-full bg-brand-500"
                      style={{ width: `${percent(method.total, Math.max(1, totals.paid))}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </SectionCard>

        <div className="space-y-4">
          <SectionCard title="Encaisser un paiement" description="Sélectionnez la facture et saisissez le montant reçu">
            {options.length === 0 ? (
              <p className="text-sm text-ink/50">Toutes les factures sont réglées.</p>
            ) : (
              <form action={recordPayment} className="space-y-3">
                <input type="hidden" name="redirectTo" value="/finances" />
                <div>
                  <label className="label" htmlFor="invoiceId">Facture à régler</label>
                  <select id="invoiceId" name="invoiceId" className="input" required defaultValue="">
                    <option value="" disabled>Sélectionner une facture…</option>
                    {options.slice(0, 120).map((option) => (
                      <option key={option.id} value={option.id}>
                        {option.firstName} {option.lastName} — {option.label} ({money(option.amount - option.amountPaid, false)} restants)
                      </option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="label" htmlFor="amount">Montant (FC)</label>
                    <input id="amount" name="amount" type="number" min={1} step={500} placeholder="Montant reçu" className="input" required />
                  </div>
                  <div>
                    <label className="label" htmlFor="method">Moyen</label>
                    <select id="method" name="method" className="input" defaultValue="mobile money">
                      {PAYMENT_METHODS.map((method) => (
                        <option key={method} value={method}>{CHANNEL_LABEL[method] ?? method}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="label" htmlFor="reference">Référence</label>
                    <input id="reference" name="reference" className="input" placeholder="OM-458921" />
                  </div>
                  <div>
                    <label className="label" htmlFor="paidAt">Date</label>
                    <input id="paidAt" name="paidAt" type="date" defaultValue={todayISO()} className="input" />
                  </div>
                </div>
                <SubmitButton className="btn-primary w-full" pendingLabel="Encaissement…">
                  <HandCoins className="h-4 w-4" /> Enregistrer le paiement
                </SubmitButton>
                <p className="text-[11px] text-ink/45">
                  Le solde de l&apos;élève, le statut de la facture et le tableau de bord sont mis à jour
                  instantanément.
                </p>
              </form>
            )}
          </SectionCard>

          <SectionCard title="Créer une facture" description="Frais annexes, cantine, transport, rattrapage…">
            <form action={createInvoice} className="space-y-3">
              <div>
                <label className="label" htmlFor="invoice-student">Élève</label>
                <select id="invoice-student" name="studentId" className="input" required defaultValue="">
                  <option value="" disabled>Sélectionner un élève…</option>
                  {studentOptions.map((student) => (
                    <option key={student.id} value={student.id}>
                      {student.lastName} {student.firstName} — {student.className ?? "sans classe"}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label" htmlFor="invoice-label">Libellé</label>
                <input id="invoice-label" name="label" className="input" placeholder="Cantine — Trimestre 2" required />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label" htmlFor="invoice-amount">Montant (FC)</label>
                  <input id="invoice-amount" name="amount" type="number" min={500} step={500} className="input" required />
                </div>
                <div>
                  <label className="label" htmlFor="invoice-due">Échéance</label>
                  <input id="invoice-due" name="dueDate" type="date" defaultValue={todayISO()} className="input" />
                </div>
              </div>
              <SubmitButton className="btn-outline w-full" pendingLabel="Création…">
                <Receipt className="h-4 w-4" /> Émettre la facture
              </SubmitButton>
            </form>
          </SectionCard>

          <SectionCard title="Dernières relances" description={`${totals.remindersCount} relances sur 30 jours`} bodyClassName="divide-y divide-ink/6">
            {reminderRows.length === 0 ? (
              <p className="px-5 py-6 text-sm text-ink/50">Aucune relance envoyée.</p>
            ) : (
              reminderRows.map((reminder) => (
                <div key={reminder.id} className="flex items-center justify-between gap-2 px-5 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-ink">
                      {reminder.firstName} {reminder.lastName}
                    </p>
                    <p className="text-[11px] text-ink/45">
                      {reminder.number} · reste {money(reminder.amount - reminder.amountPaid)} ·{" "}
                      {formatDate(reminder.sentAt)}
                    </p>
                  </div>
                  <Badge tone="warning">{CHANNEL_LABEL[reminder.channel] ?? reminder.channel}</Badge>
                </div>
              ))
            )}
          </SectionCard>
        </div>
      </div>

      <div className="card mt-4 overflow-hidden">
        <div className="flex flex-col gap-3 border-b border-ink/8 p-4 xl:flex-row xl:items-center xl:justify-between">
          <Tabs
            current={STATUS_TABS.find((t) => t.key === statut)?.label ?? "Toutes"}
            items={STATUS_TABS.map((tab) => ({
              label: tab.label,
              href: `/finances?statut=${tab.key}${params.q ? `&q=${encodeURIComponent(params.q)}` : ""}`,
            }))}
          />
          <form className="flex flex-1 items-center gap-2 xl:max-w-md">
            <input type="hidden" name="statut" value={statut} />
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/35" />
              <input name="q" defaultValue={params.q ?? ""} placeholder="Élève, facture, libellé…" className="input pl-9" />
            </div>
            <button type="submit" className="btn-outline">
              <Filter className="h-4 w-4" /> Filtrer
            </button>
          </form>
        </div>

        {invoices.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={Receipt}
              title="Aucune facture ne correspond"
              description="Essayez un autre statut ou un autre terme de recherche."
              action={<Link href="/finances" className="btn-outline">Réinitialiser</Link>}
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[980px] border-collapse">
              <thead className="bg-sand/60">
                <tr>
                  <th className="th">Facture</th>
                  <th className="th">Élève</th>
                  <th className="th">Montant</th>
                  <th className="th">Payé</th>
                  <th className="th">Solde</th>
                  <th className="th">Échéance</th>
                  <th className="th">Statut</th>
                  <th className="th text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink/6">
                {invoices.map((invoice) => {
                  const balance = invoice.amount - invoice.amountPaid;
                  const overdue = balance > 0 && new Date(`${invoice.dueDate}T12:00:00`) < new Date();
                  return (
                    <tr key={invoice.id} className="row-hover">
                      <td className="td">
                        <p className="font-semibold text-ink">{invoice.number}</p>
                        <p className="text-[11px] text-ink/45">{invoice.label}</p>
                      </td>
                      <td className="td">
                        <Link href={`/eleves/${invoice.studentId}`} className="flex items-center gap-2 hover:underline">
                          <Avatar first={invoice.firstName} last={invoice.lastName} size="sm" />
                          <span>
                            <span className="block text-sm font-medium text-ink">
                              {invoice.firstName} {invoice.lastName}
                            </span>
                            <span className="block text-[11px] text-ink/45">{invoice.className ?? "Sans classe"}</span>
                          </span>
                        </Link>
                      </td>
                      <td className="td whitespace-nowrap">{money(invoice.amount)}</td>
                      <td className="td whitespace-nowrap text-brand-700">{money(invoice.amountPaid)}</td>
                      <td className="td whitespace-nowrap">
                        <span className={balance > 0 ? "font-bold text-red-600" : "font-semibold text-ink/40"}>
                          {money(balance)}
                        </span>
                      </td>
                      <td className="td whitespace-nowrap">
                        <p>{formatDate(invoice.dueDate)}</p>
                        {balance > 0 ? (
                          <p className={`text-[11px] ${overdue ? "font-semibold text-red-600" : "text-ink/45"}`}>
                            {dueLabel(invoice.dueDate)}
                          </p>
                        ) : null}
                      </td>
                      <td className="td">
                        <span className={`badge ${INVOICE_TONE[invoice.status] ?? "bg-ink/10 text-ink/60"}`}>
                          {invoice.status}
                        </span>
                      </td>
                      <td className="td">
                        <div className="flex items-center justify-end gap-1.5">
                          {balance > 0 ? (
                            <form action={sendReminder}>
                              <input type="hidden" name="invoiceId" value={invoice.id} />
                              <input type="hidden" name="redirectTo" value={`/finances?statut=${statut}`} />
                              <input type="hidden" name="channel" value="sms" />
                              <SubmitButton className="btn-outline btn-sm" pendingLabel="…">
                                <BellRing className="h-3.5 w-3.5" /> Relancer
                              </SubmitButton>
                            </form>
                          ) : null}
                          <Link href={`/eleves/${invoice.studentId}`} className="btn-ghost btn-sm">
                            Dossier
                          </Link>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-sand/60">
                <tr>
                  <td className="td font-semibold" colSpan={2}>
                    {invoices.length} facture(s) affichée(s)
                  </td>
                  <td className="td font-bold">{money(invoices.reduce((s, i) => s + i.amount, 0), false)}</td>
                  <td className="td font-bold text-brand-700">{money(invoices.reduce((s, i) => s + i.amountPaid, 0), false)}</td>
                  <td className="td font-bold text-red-600">
                    {money(invoices.reduce((s, i) => s + i.amount - i.amountPaid, 0), false)}
                  </td>
                  <td className="td" colSpan={3} />
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>

      <SectionCard
        title="Derniers encaissements"
        description="Journal des paiements reçus"
        className="mt-4"
        action={<Badge tone="brand">{money(totals.collected30)} sur 30 jours</Badge>}
        bodyClassName="overflow-x-auto"
      >
        <table className="w-full min-w-[760px] border-collapse">
          <thead className="bg-sand/60">
            <tr>
              <th className="th">Élève</th>
              <th className="th">Facture</th>
              <th className="th">Moyen</th>
              <th className="th">Référence</th>
              <th className="th">Saisi par</th>
              <th className="th">Date</th>
              <th className="th text-right">Montant</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/6">
            {payments.map((payment) => (
              <tr key={payment.id} className="row-hover">
                <td className="td">
                  <Link href={`/eleves/${payment.studentId}`} className="font-medium text-ink hover:underline">
                    {payment.firstName} {payment.lastName}
                  </Link>
                </td>
                <td className="td">
                  <p className="text-xs font-semibold text-ink/70">{payment.invoiceNumber ?? "—"}</p>
                  <p className="text-[11px] text-ink/45">{payment.invoiceLabel ?? "Paiement libre"}</p>
                </td>
                <td className="td"><Badge tone="info">{CHANNEL_LABEL[payment.method] ?? payment.method}</Badge></td>
                <td className="td text-xs text-ink/50">{payment.reference || "—"}</td>
                <td className="td text-xs text-ink/50">{payment.recordedBy}</td>
                <td className="td whitespace-nowrap">{formatDate(payment.paidAt)}</td>
                <td className="td text-right font-bold text-brand-700">{money(payment.amount)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </SectionCard>
    </>
  );
}
