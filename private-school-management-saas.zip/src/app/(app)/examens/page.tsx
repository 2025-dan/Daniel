import Link from "next/link";
import { CalendarCheck, ClipboardCheck, Clock, Plus, Trash2, UserCheck } from "lucide-react";
import { Badge, EmptyState, Notice, PageHeader, SectionCard, StatCard, Tabs } from "@/components/ui";
import { SubmitButton } from "@/components/forms";
import { Restricted } from "@/components/restricted";
import { createExam, deleteExam, updateExamStatus } from "@/lib/actions";
import { getExamsPageData } from "@/lib/data/school-life";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import { TERMS, dueLabel, formatDate, todayISO } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = {
  searchParams: Promise<{ classId?: string; term?: string; enregistre?: string; erreur?: string }>;
};

const STATUS_TONE: Record<string, "success" | "warning" | "neutral" | "danger"> = {
  planifié: "warning",
  "en cours": "neutral",
  terminé: "success",
  annulé: "danger",
};

export default async function ExamsPage({ searchParams }: Props) {
  const [role, params] = await Promise.all([getRole(), searchParams]);
  if (!can(role, "exams")) return <Restricted role={role} module="Examens" />;

  const { classRows, subjectRows, selectedClass, exams, stats } = await getExamsPageData({
    classId: params.classId,
    term: params.term,
  });
  const upcoming = exams.filter((exam) => exam.date >= todayISO() && exam.status !== "terminé");
  const past = exams.filter((exam) => !(exam.date >= todayISO() && exam.status !== "terminé"));

  return (
    <>
      <PageHeader
        eyebrow="Vie scolaire"
        title="Examens & compositions"
        subtitle="Planifiez les épreuves, les salles et les surveillants. Chaque examen est ensuite noté dans le module Notes."
        actions={<Badge tone="brand">{stats.upcoming} épreuve(s) à venir</Badge>}
      />

      {params.enregistre ? <div className="mb-4"><Notice>L&apos;examen a été planifié.</Notice></div> : null}
      {params.erreur ? <div className="mb-4"><Notice tone="danger">{params.erreur}</Notice></div> : null}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Examens planifiés" value={stats.total} hint="Toutes classes et matières" icon={ClipboardCheck} />
        <StatCard label="À venir" value={stats.upcoming} hint="Date d'épreuve future" icon={CalendarCheck} tone="amber" />
        <StatCard label="Planifiés à confirmer" value={stats.planned} hint="En attente de tenue" icon={Clock} tone="sky" />
        <StatCard label="Corrigés / tenus" value={stats.done} hint="Statut terminé" icon={UserCheck} tone="brand" />
      </div>

      <div className="card my-4 flex flex-col gap-3 p-4 xl:flex-row xl:items-end xl:justify-between">
        <form className="flex flex-1 flex-col gap-2 sm:flex-row sm:items-end">
          <div className="sm:w-52">
            <label className="label" htmlFor="classId">Classe</label>
            <select id="classId" name="classId" className="input" defaultValue={params.classId ?? ""}>
              <option value="">Toutes les classes</option>
              {classRows.map((cls) => (
                <option key={cls.id} value={cls.id}>{cls.name}</option>
              ))}
            </select>
          </div>
          <div className="sm:w-48">
            <label className="label" htmlFor="term">Trimestre</label>
            <select id="term" name="term" className="input" defaultValue={params.term ?? ""}>
              <option value="">Tous les trimestres</option>
              {TERMS.map((term) => (
                <option key={term} value={term}>{term}</option>
              ))}
            </select>
          </div>
          <button type="submit" className="btn-primary">
            <ClipboardCheck className="h-4 w-4" /> Filtrer
          </button>
        </form>
        <Tabs
          current={params.term ?? "Tous"}
          items={[{ label: "Tous", href: "/examens" }, ...TERMS.map((term) => ({ label: term.replace("Trimestre ", "T"), href: `/examens?term=${encodeURIComponent(term)}` }))]}
        />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.5fr_1fr]">
        <SectionCard
          title="Calendrier des épreuves"
          description={selectedClass ? `Classe ${selectedClass.name}` : "Toutes les classes"}
          bodyClassName="divide-y divide-ink/6"
        >
          {exams.length === 0 ? (
            <div className="p-5">
              <EmptyState icon={ClipboardCheck} title="Aucun examen" description="Planifiez la première composition depuis le formulaire." />
            </div>
          ) : (
            exams.map((exam) => (
              <div key={exam.id} className="flex flex-wrap items-start justify-between gap-3 px-5 py-3.5">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Badge tone={STATUS_TONE[exam.status] ?? "neutral"}>{exam.status}</Badge>
                    <Badge tone="info">{exam.className}</Badge>
                    <Badge tone="neutral">{exam.subjectName ?? "—"}</Badge>
                  </div>
                  <p className="mt-1.5 text-sm font-semibold text-ink">{exam.title}</p>
                  <p className="text-[11px] text-ink/45">
                    {formatDate(exam.date)} · {exam.startTime} · {exam.duration} min · salle {exam.room || "—"} · surveillant{" "}
                    {exam.supervisor || "—"}
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  {exam.status !== "terminé" ? (
                    <form action={updateExamStatus}>
                      <input type="hidden" name="examId" value={exam.id} />
                      <input type="hidden" name="status" value="terminé" />
                      <input type="hidden" name="classId" value={params.classId ?? ""} />
                      <input type="hidden" name="term" value={params.term ?? ""} />
                      <SubmitButton className="btn-soft btn-sm" pendingLabel="…">Marquer tenu</SubmitButton>
                    </form>
                  ) : null}
                  <Link href={`/notes${exam.classId ? `?classId=${exam.classId}&term=${encodeURIComponent(exam.term)}` : ""}`} className="btn-outline btn-sm">
                    Notes
                  </Link>
                  <form action={deleteExam}>
                    <input type="hidden" name="examId" value={exam.id} />
                    <input type="hidden" name="classId" value={params.classId ?? ""} />
                    <SubmitButton className="btn-ghost btn-sm !px-2 text-red-500" pendingLabel="">
                      <Trash2 className="h-3.5 w-3.5" />
                    </SubmitButton>
                  </form>
                </div>
              </div>
            ))
          )}
        </SectionCard>

        <div className="space-y-4">
          <SectionCard title="Planifier un examen" description="Date, salle et surveillant">
            <form action={createExam} className="space-y-3">
              <div>
                <label className="label" htmlFor="exam-class">Classe</label>
                <select id="exam-class" name="classId" className="input" defaultValue={selectedClass ? String(selectedClass.id) : ""} required>
                  <option value="">Sélectionner…</option>
                  {classRows.map((cls) => (
                    <option key={cls.id} value={cls.id}>{cls.name}</option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label" htmlFor="exam-subject">Matière</label>
                  <select id="exam-subject" name="subjectId" className="input" defaultValue="">
                    <option value="">—</option>
                    {subjectRows.map((subject) => (
                      <option key={subject.id} value={subject.id}>{subject.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label" htmlFor="exam-term">Trimestre</label>
                  <select id="exam-term" name="term" className="input" defaultValue="Trimestre 2">
                    {TERMS.map((term) => (
                      <option key={term} value={term}>{term}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="label" htmlFor="exam-title">Intitulé</label>
                <input id="exam-title" name="title" className="input" placeholder="Composition — Mathématiques" required />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label" htmlFor="exam-date">Date</label>
                  <input id="exam-date" name="date" type="date" className="input" defaultValue={todayISO()} required />
                </div>
                <div>
                  <label className="label" htmlFor="exam-time">Début</label>
                  <input id="exam-time" name="startTime" type="time" defaultValue="08:00" className="input" />
                </div>
                <div>
                  <label className="label" htmlFor="exam-duration">Durée (min)</label>
                  <input id="exam-duration" name="duration" type="number" min={15} step={15} defaultValue={120} className="input" />
                </div>
                <div>
                  <label className="label" htmlFor="exam-room">Salle</label>
                  <input id="exam-room" name="room" className="input" defaultValue={selectedClass?.room ?? ""} />
                </div>
              </div>
              <div>
                <label className="label" htmlFor="exam-supervisor">Surveillant</label>
                <input id="exam-supervisor" name="supervisor" className="input" placeholder="M. Ehouman Serge" />
              </div>
              <SubmitButton className="btn-primary w-full" pendingLabel="Planification…">
                <Plus className="h-4 w-4" /> Planifier l&apos;examen
              </SubmitButton>
            </form>
          </SectionCard>

          <SectionCard title="Prochaines épreuves" description={`${upcoming.length} à venir / ${past.length} passées`} bodyClassName="divide-y divide-ink/6">
            {upcoming.slice(0, 4).map((exam) => (
              <div key={exam.id} className="flex items-center justify-between gap-2 px-5 py-2.5">
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-ink">{exam.title}</p>
                  <p className="text-[11px] text-ink/45">{exam.className} · {formatDate(exam.date)} · {exam.startTime}</p>
                </div>
                <Badge tone="warning">{dueLabel(exam.date)}</Badge>
              </div>
            ))}
            {upcoming.length === 0 ? <p className="px-5 py-5 text-sm text-ink/50">Aucune épreuve à venir.</p> : null}
          </SectionCard>
        </div>
      </div>
    </>
  );
}
