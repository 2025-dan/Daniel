import Link from "next/link";
import {
  ArrowUpRight,
  Banknote,
  BellRing,
  CalendarRange,
  ClipboardCheck,
  FolderOpen,
  ScanLine,
  UserCog,
  CalendarCheck,
  ChevronRight,
  ClipboardList,
  MessageSquare,
  Send,
  ShieldCheck,
  TrendingUp,
  UserPlus,
  Users,
  Wallet,
} from "lucide-react";
import { Avatar, Badge, PageHeader, ProgressBar, SectionCard, StatCard } from "@/components/ui";
import { CollectionBars, Donut } from "@/components/charts";
import { SubmitButton } from "@/components/forms";
import { sendReminder } from "@/lib/actions";
import { getDashboardData } from "@/lib/data/dashboard";
import { getRole } from "@/lib/session";
import { can, roleLabel } from "@/lib/roles";
import {
  CHANNEL_LABEL,
  compactMoney,
  dueLabel,
  formatDate,
  formatDateLong,
  money,
  percent,
  relativeTime,
} from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const [data, role] = await Promise.all([getDashboardData(), getRole()]);
  const { school, year, students, finance, classRows, monthly, recentPayments, topDebts, lastMessages, attendance } =
    data;

  const remaining = finance.balance - finance.overdueAmount;
  const donutSegments = [
    { label: "Encaissé", value: finance.paid, color: "#0e6e4f" },
    { label: "En retard", value: finance.overdueAmount, color: "#c6453b" },
    { label: "À échoir", value: Math.max(0, remaining), color: "#e8a33d" },
  ];

  return (
    <>
      <PageHeader
        eyebrow={`${formatDateLong(new Date())} · Profil ${roleLabel(role)}`}
        title={`Bonjour, ${school.directorName || "Direction"}`}
        subtitle={`${school.name} · ${students.active} élèves inscrits · année ${year.label}. Voici la situation de l'établissement aujourd'hui.`}
        actions={
          <>
            {can(role, "documents") ? (
              <Link href="/documents/scan" className="btn-outline">
                <FolderOpen className="h-4 w-4" /> Scanner un bulletin
              </Link>
            ) : null}
            {can(role, "students") ? (
              <Link href="/eleves/nouveau" className="btn-primary">
                <UserPlus className="h-4 w-4" /> Inscrire un élève
              </Link>
            ) : null}
            {can(role, "finance") ? (
              <Link href="/finances" className="btn-outline">
                <Wallet className="h-4 w-4" /> Encaisser
              </Link>
            ) : null}
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Élèves inscrits"
          value={students.active}
          hint={`${classRows.length} classes · ${students.girls} filles / ${students.boys} garçons`}
          icon={Users}
          tone="brand"
          footer={
            <p className="text-xs text-brand-700">
              <span className="font-bold">+{students.recent}</span> nouvelles inscriptions sur 30 jours
            </p>
          }
        />
        <StatCard
          label="Encaissé (30 jours)"
          value={money(finance.collected30)}
          hint={`${money(finance.paid)} sur ${compactMoney(finance.invoiced)} FC facturés`}
          icon={TrendingUp}
          tone="sky"
          footer={
            <div className="flex items-center gap-2">
              <ProgressBar value={finance.recoveryRate} tone="sky" />
              <span className="text-xs font-bold text-ink/50">{finance.recoveryRate}%</span>
            </div>
          }
        />
        <StatCard
          label="Impayés"
          value={money(finance.overdueAmount)}
          hint={`${finance.overdueCount} facture(s) échue(s) · ${finance.unpaidCount} à suivre`}
          icon={BellRing}
          tone="danger"
          footer={
            <Link href="/finances?statut=retard" className="inline-flex items-center gap-1 text-xs font-semibold text-red-600 hover:underline">
              Traiter les impayés <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          }
        />
        <StatCard
          label="Assiduité (7 jours)"
          value={`${attendance.rate}%`}
          hint={`${attendance.total} pointages enregistrés`}
          icon={CalendarCheck}
          tone="amber"
          footer={
            <Link href="/presences" className="inline-flex items-center gap-1 text-xs font-semibold text-brand-700 hover:underline">
              Faire l&apos;appel du jour <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          }
        />
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-[1.4fr_1fr]">
        <SectionCard
          title="Encaissements des 6 derniers mois"
          description="Paiements enregistrés, toutes classes confondues"
          action={<Badge tone="brand">{money(finance.collected30)} ce mois</Badge>}
        >
          <CollectionBars data={monthly} />
          <div className="mt-5 grid grid-cols-3 gap-3 border-t border-ink/8 pt-4">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Facturé</p>
              <p className="mt-1 text-sm font-semibold text-ink">{money(finance.invoiced)}</p>
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Recouvré</p>
              <p className="mt-1 text-sm font-semibold text-brand-700">{money(finance.paid)}</p>
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Reste à recouvrer</p>
              <p className="mt-1 text-sm font-semibold text-amber-700">{money(finance.balance)}</p>
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Situation des factures" description={`${finance.invoiceCount} factures émises cette année`}>
          <Donut segments={donutSegments} centerValue={`${finance.recoveryRate}%`} centerLabel="recouvrement" />
          <div className="mt-5 flex items-center justify-between rounded-xl bg-sand px-3.5 py-3">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Relances envoyées (30 j)</p>
              <p className="mt-0.5 text-sm font-semibold text-ink">{finance.remindersCount} relances</p>
            </div>
            {can(role, "finance") ? (
              <Link href="/finances?statut=retard" className="btn-soft btn-sm">
                Relancer
              </Link>
            ) : null}
          </div>
        </SectionCard>
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-[1.2fr_1fr]">
        <SectionCard
          title="Effectifs par classe"
          description="Remplissage et assiduité sur 30 jours"
          action={
            can(role, "classes") ? (
              <Link href="/classes" className="text-xs font-semibold text-brand-700 hover:underline">
                Gérer les classes
              </Link>
            ) : null
          }
          bodyClassName="divide-y divide-ink/6"
        >
          {classRows.map((cls) => (
            <div key={cls.id} className="px-5 py-3.5">
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-ink">{cls.name}</p>
                  <p className="text-[11px] text-ink/45">
                    {cls.cycle} · {cls.mainTeacher || "Titulaire non défini"}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-3">
                  <span className="text-xs font-semibold text-ink/60">
                    {cls.studentCount}/{cls.capacity}
                  </span>
                  <Badge tone={cls.attendanceRate >= 90 ? "success" : cls.attendanceRate >= 75 ? "warning" : "danger"}>
                    {cls.attendanceRate}% présence
                  </Badge>
                </div>
              </div>
              <ProgressBar
                value={percent(cls.studentCount, cls.capacity)}
                tone={cls.studentCount >= cls.capacity ? "danger" : "brand"}
                className="mt-2"
              />
            </div>
          ))}
        </SectionCard>

        <SectionCard
          title="Derniers paiements"
          description="Encaissements enregistrés par la comptabilité"
          action={
            can(role, "finance") ? (
              <Link href="/finances" className="text-xs font-semibold text-brand-700 hover:underline">
                Tout voir
              </Link>
            ) : null
          }
          bodyClassName="divide-y divide-ink/6"
        >
          {recentPayments.length === 0 ? (
            <p className="px-5 py-8 text-center text-sm text-ink/50">Aucun paiement enregistré.</p>
          ) : (
            recentPayments.map((payment) => (
              <Link
                key={payment.id}
                href={`/eleves/${payment.studentId}`}
                className="flex items-center gap-3 px-5 py-3 transition hover:bg-sand/60"
              >
                <Avatar first={payment.firstName} last={payment.lastName} size="sm" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-ink">
                    {payment.firstName} {payment.lastName}
                  </p>
                  <p className="text-[11px] text-ink/45">
                    {CHANNEL_LABEL[payment.method] ?? payment.method} · {formatDate(payment.paidAt)}
                  </p>
                </div>
                <span className="shrink-0 text-sm font-bold text-brand-700">{money(payment.amount)}</span>
              </Link>
            ))
          )}
        </SectionCard>
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-[1.2fr_1fr]">
        <SectionCard
          title="Impayés prioritaires"
          description="Soldes échus les plus élevés"
          action={<Badge tone="danger">{finance.overdueCount} dossiers</Badge>}
          bodyClassName="divide-y divide-ink/6"
        >
          {topDebts.length === 0 ? (
            <p className="px-5 py-8 text-center text-sm text-ink/50">Aucun impayé échu. Bravo !</p>
          ) : (
            topDebts.map((debt) => (
              <div key={debt.id} className="flex flex-wrap items-center gap-3 px-5 py-3.5">
                <Avatar first={debt.firstName} last={debt.lastName} size="sm" tone="sand" />
                <div className="min-w-0 flex-1">
                  <Link href={`/eleves/${debt.studentId}`} className="truncate text-sm font-semibold text-ink hover:underline">
                    {debt.firstName} {debt.lastName}
                  </Link>
                  <p className="text-[11px] text-ink/45">
                    {debt.className ?? "Sans classe"} · {debt.label} · {dueLabel(debt.dueDate)}
                  </p>
                </div>
                <span className="text-sm font-bold text-red-600">{money(debt.amount - debt.amountPaid)}</span>
                {can(role, "finance") ? (
                  <form action={sendReminder}>
                    <input type="hidden" name="invoiceId" value={debt.id} />
                    <input type="hidden" name="redirectTo" value="/dashboard" />
                    <input type="hidden" name="channel" value="sms" />
                    <SubmitButton className="btn-outline btn-sm" pendingLabel="Envoi…">
                      <Send className="h-3.5 w-3.5" /> Relancer
                    </SubmitButton>
                  </form>
                ) : null}
              </div>
            ))
          )}
        </SectionCard>

        <div className="space-y-4">
          <SectionCard
            title="Vie scolaire"
            description="Assiduité des 7 derniers jours"
            action={<Badge tone={attendance.rate >= 90 ? "success" : "warning"}>{attendance.rate}%</Badge>}
          >
            <div className="flex items-end justify-between gap-4">
              <div>
                <p className="font-display text-3xl font-bold text-ink">{attendance.rate}%</p>
                <p className="mt-1 text-xs text-ink/50">Taux de présence global</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-semibold text-ink">{attendance.total}</p>
                <p className="text-[11px] text-ink/45">pointages (7 j)</p>
              </div>
            </div>
            <ProgressBar value={attendance.rate} tone={attendance.rate >= 90 ? "brand" : "amber"} className="mt-4" />
            <div className="mt-4 grid grid-cols-2 gap-2">
              <Link href="/presences" className="btn-soft btn-sm justify-center">
                <CalendarCheck className="h-3.5 w-3.5" /> Appel du jour
              </Link>
              {can(role, "grades") ? (
                <Link href="/bulletins" className="btn-outline btn-sm justify-center">
                  <ClipboardList className="h-3.5 w-3.5" /> Bulletins
                </Link>
              ) : null}
            </div>
          </SectionCard>

          <SectionCard
            title="Derniers messages"
            description={`${data.messages.recipients} familles touchées`}
            action={
              can(role, "messages") ? (
                <Link href="/communication" className="text-xs font-semibold text-brand-700 hover:underline">
                  Écrire
                </Link>
              ) : null
            }
            bodyClassName="divide-y divide-ink/6"
          >
            {lastMessages.map((message) => (
              <div key={message.id} className="px-5 py-3">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-sm font-semibold text-ink">{message.subject}</p>
                  <Badge tone={message.status === "brouillon" ? "warning" : "success"}>
                    {message.status === "brouillon" ? "Brouillon" : CHANNEL_LABEL[message.channel] ?? message.channel}
                  </Badge>
                </div>
                <p className="mt-1 line-clamp-1 text-xs text-ink/50">{message.body}</p>
                <p className="mt-1 text-[10px] font-medium uppercase tracking-wide text-ink/35">
                  {message.recipientLabel} · {relativeTime(message.sentAt)}
                </p>
              </div>
            ))}
          </SectionCard>
        </div>
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-2">
        <SectionCard
          title="Prochaines épreuves"
          description="Compositions et devoirs surveillés planifiés"
          action={
            can(role, "exams") ? (
              <Link href="/examens" className="text-xs font-semibold text-brand-700 hover:underline">Calendrier</Link>
            ) : null
          }
          bodyClassName="divide-y divide-ink/6"
        >
          {data.nextExams.length === 0 ? (
            <p className="px-5 py-8 text-center text-sm text-ink/50">Aucune épreuve planifiée.</p>
          ) : (
            data.nextExams.map((exam) => (
              <div key={exam.id} className="flex items-center gap-3 px-5 py-3">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-amber-50 text-amber-700">
                  <ClipboardCheck className="h-4 w-4" strokeWidth={1.8} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-ink">{exam.title}</p>
                  <p className="text-[11px] text-ink/45">
                    {exam.className} · {exam.subjectName ?? "—"} · {formatDate(exam.date)} à {exam.startTime}
                  </p>
                </div>
                <Badge tone="warning">{dueLabel(exam.date)}</Badge>
              </div>
            ))
          )}
        </SectionCard>

        <SectionCard
          title="Ressources humaines"
          description={`${data.staff.total} membres du personnel · ${data.staff.teaching} enseignants`}
          action={
            can(role, "payroll") ? (
              <Link href="/paie" className="text-xs font-semibold text-brand-700 hover:underline">Ouvrir la paie</Link>
            ) : null
          }
        >
          <div className="flex items-end justify-between gap-4">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Net à payer — {data.staff.period}</p>
              <p className="mt-1 font-display text-2xl font-bold text-ink">{money(data.staff.pendingAmount)}</p>
              <p className="mt-0.5 text-[11px] text-ink/45">{data.staff.pending} bulletin(s) en attente de règlement</p>
            </div>
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-50 text-brand-700">
              <Banknote className="h-5 w-5" strokeWidth={1.8} />
            </span>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <Link href="/personnel" className="btn-soft btn-sm justify-center">
              <UserCog className="h-3.5 w-3.5" /> Équipe
            </Link>
            <Link href="/emploi-du-temps" className="btn-outline btn-sm justify-center">
              <CalendarRange className="h-3.5 w-3.5" /> Emplois du temps
            </Link>
          </div>
        </SectionCard>
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          {
            title: `${finance.unpaidCount} dossiers à relancer`,
            text: "Relances groupées par SMS aux familles en retard.",
            href: "/finances?statut=retard",
            icon: BellRing,
            show: can(role, "finance"),
          },
          {
            title: `${data.messages.drafts} message(s) en brouillon`,
            text: "Finalisez et diffusez vos annonces aux parents.",
            href: "/communication",
            icon: MessageSquare,
            show: can(role, "messages"),
          },
          {
            title: `Échéances sous 15 jours`,
            text: `${money(data.dueSoon.amount)} à encaisser sur ${data.dueSoon.count} facture(s).`,
            href: "/finances",
            icon: Wallet,
            show: can(role, "finance"),
          },
          {
            title: "Emploi du temps & examens",
            text: "Plannings hebdomadaires, salles et surveillants.",
            href: "/emploi-du-temps",
            icon: CalendarRange,
            show: can(role, "timetable"),
          },
          {
            title: "Bulletins scannés",
            text: "Numérisez les bulletins papier et importez les pièces des dossiers.",
            href: "/documents",
            icon: ScanLine,
            show: can(role, "documents"),
          },
          {
            title: "Cahier de textes",
            text: "Séances menées et devoirs à rendre par classe.",
            href: "/cahier-de-textes",
            icon: ClipboardCheck,
            show: can(role, "lessons"),
          },
          {
            title: "Bulletins du trimestre",
            text: "Moyennes, rangs et appréciations prêts à imprimer.",
            href: "/bulletins",
            icon: ShieldCheck,
            show: can(role, "reports"),
          },
        ]
          .filter((item) => item.show)
          .map((item) => (
            <Link key={item.title} href={item.href} className="card group flex items-start gap-3 p-4 transition hover:border-brand-200">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-brand-50 text-brand-700">
                <item.icon className="h-4 w-4" strokeWidth={1.8} />
              </span>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-ink">{item.title}</p>
                <p className="mt-0.5 text-xs text-ink/50">{item.text}</p>
              </div>
              <ChevronRight className="ml-auto h-4 w-4 shrink-0 text-ink/25 transition group-hover:text-brand-600" />
            </Link>
          ))}
      </div>
    </>
  );
}
