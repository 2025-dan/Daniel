import Link from "next/link";
import { ArrowLeft, CheckCircle2, Info, UserPlus } from "lucide-react";
import { PageHeader, Notice, SectionCard } from "@/components/ui";
import { SubmitButton } from "@/components/forms";
import { Restricted } from "@/components/restricted";
import { createStudent } from "@/lib/actions";
import { getClassSummaries, requireContext } from "@/lib/data/context";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import { CYCLES, LEVELS, money, todayISO } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<{ erreur?: string }> };

export default async function NewStudentPage({ searchParams }: Props) {
  const [role, params, ctx, classRows] = await Promise.all([
    getRole(),
    searchParams,
    requireContext(),
    getClassSummaries(),
  ]);
  if (!can(role, "students")) return <Restricted role={role} module="Inscriptions" />;

  return (
    <>
      <PageHeader
        eyebrow="Scolarité"
        title="Inscrire un nouvel élève"
        subtitle={`Année ${ctx.year.label} · le matricule est généré automatiquement, les frais de scolarité peuvent l'être aussi.`}
        actions={
          <Link href="/eleves" className="btn-outline">
            <ArrowLeft className="h-4 w-4" /> Retour à la liste
          </Link>
        }
      />

      {params.erreur ? (
        <div className="mb-4">
          <Notice tone="danger">{params.erreur}</Notice>
        </div>
      ) : null}

      <form action={createStudent} className="grid gap-4 xl:grid-cols-[1.6fr_1fr]">
        <div className="space-y-4">
          <SectionCard title="Identité de l'élève" description="Informations reprises sur le dossier et les bulletins">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="label" htmlFor="lastName">Nom *</label>
                <input id="lastName" name="lastName" required className="input" placeholder="KONAN" />
              </div>
              <div>
                <label className="label" htmlFor="firstName">Prénom(s) *</label>
                <input id="firstName" name="firstName" required className="input" placeholder="Aya" />
              </div>
              <div>
                <label className="label" htmlFor="gender">Sexe</label>
                <select id="gender" name="gender" className="input" defaultValue="F">
                  <option value="F">Féminin</option>
                  <option value="M">Masculin</option>
                </select>
              </div>
              <div>
                <label className="label" htmlFor="birthDate">Date de naissance</label>
                <input id="birthDate" name="birthDate" type="date" className="input" max={todayISO()} />
              </div>
              <div>
                <label className="label" htmlFor="birthPlace">Lieu de naissance</label>
                <input id="birthPlace" name="birthPlace" className="input" placeholder="Abidjan" />
              </div>
              <div>
                <label className="label" htmlFor="bloodGroup">Groupe sanguin</label>
                <select id="bloodGroup" name="bloodGroup" className="input" defaultValue="">
                  <option value="">Non renseigné</option>
                  {["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"].map((g) => (
                    <option key={g} value={g}>{g}</option>
                  ))}
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className="label" htmlFor="address">Adresse / quartier</label>
                <input id="address" name="address" className="input" placeholder="Cocody, Abidjan" />
              </div>
              <div className="sm:col-span-2">
                <label className="label" htmlFor="notes">Observations (santé, besoins particuliers…)</label>
                <textarea id="notes" name="notes" rows={2} className="input" placeholder="Facultatif" />
              </div>
            </div>
          </SectionCard>

          <SectionCard title="Tuteur principal" description="Le contact qui reçoit les SMS et les relances de scolarité">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="label" htmlFor="guardianName">Nom complet</label>
                <input id="guardianName" name="guardianName" className="input" placeholder="Konan Yao" />
              </div>
              <div>
                <label className="label" htmlFor="guardianRelation">Lien de parenté</label>
                <select id="guardianRelation" name="guardianRelation" className="input" defaultValue="Père">
                  <option>Père</option>
                  <option>Mère</option>
                  <option>Tuteur</option>
                  <option>Autre</option>
                </select>
              </div>
              <div>
                <label className="label" htmlFor="guardianPhone">Téléphone</label>
                <input id="guardianPhone" name="guardianPhone" className="input" placeholder="+225 07 00 00 00 00" />
              </div>
              <div>
                <label className="label" htmlFor="guardianEmail">E-mail</label>
                <input id="guardianEmail" name="guardianEmail" type="email" className="input" placeholder="parent@mail.ci" />
              </div>
              <div className="sm:col-span-2">
                <label className="label" htmlFor="guardianProfession">Profession</label>
                <input id="guardianProfession" name="guardianProfession" className="input" placeholder="Commerçante" />
              </div>
            </div>

            <details className="mt-4 rounded-xl border border-ink/10 bg-sand/50 p-3">
              <summary className="cursor-pointer text-xs font-bold uppercase tracking-wide text-ink/50">
                Ajouter un second tuteur (facultatif)
              </summary>
              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                <div>
                  <label className="label" htmlFor="secondGuardianName">Nom complet</label>
                  <input id="secondGuardianName" name="secondGuardianName" className="input" />
                </div>
                <div>
                  <label className="label" htmlFor="secondGuardianRelation">Lien</label>
                  <select id="secondGuardianRelation" name="secondGuardianRelation" className="input" defaultValue="Mère">
                    <option>Mère</option>
                    <option>Père</option>
                    <option>Tuteur</option>
                  </select>
                </div>
                <div>
                  <label className="label" htmlFor="secondGuardianPhone">Téléphone</label>
                  <input id="secondGuardianPhone" name="secondGuardianPhone" className="input" />
                </div>
              </div>
            </details>
          </SectionCard>
        </div>

        <div className="space-y-4">
          <SectionCard title="Affectation & scolarité" description="Classe et génération des frais">
            <div className="space-y-4">
              <div>
                <label className="label" htmlFor="classId">Classe d&apos;accueil</label>
                <select id="classId" name="classId" className="input" defaultValue="">
                  <option value="">Affecter plus tard</option>
                  {classRows.map((cls) => (
                    <option key={cls.id} value={cls.id}>
                      {cls.name} — {money(cls.monthlyFee)}/mois ({cls.studentCount}/{cls.capacity})
                    </option>
                  ))}
                </select>
                <p className="mt-1.5 text-[11px] text-ink/45">
                  Structure RDC : {CYCLES.join(", ")} · niveaux de {LEVELS[0]} à {LEVELS[LEVELS.length - 1]}.
                </p>
              </div>
              <div>
                <label className="label" htmlFor="matricule">Matricule (optionnel)</label>
                <input id="matricule" name="matricule" className="input" placeholder="Généré automatiquement" />
              </div>
              <div>
                <label className="label" htmlFor="status">Statut du dossier</label>
                <select id="status" name="status" className="input" defaultValue="actif">
                  <option value="actif">Actif</option>
                  <option value="suspendu">Suspendu</option>
                </select>
              </div>
              <label className="flex cursor-pointer items-start gap-2.5 rounded-xl border border-brand-200 bg-brand-50 p-3">
                <input type="checkbox" name="generateFees" defaultChecked className="mt-0.5 h-4 w-4 accent-brand-700" />
                <span>
                  <span className="block text-xs font-bold text-brand-900">Générer les frais de scolarité</span>
                  <span className="mt-0.5 block text-[11px] leading-snug text-brand-800/70">
                    1 facture d&apos;inscription (35 000 FC) + 3 versements trimestriels calculés sur le tarif
                    mensuel de la classe.
                  </span>
                </span>
              </label>
            </div>
          </SectionCard>

          <SectionCard title="Récapitulatif">
            <ul className="space-y-2.5 text-sm text-ink/65">
              {[
                "Dossier élève créé et rattaché à l'année en cours",
                "Tuteur(s) enregistré(s) pour les relances",
                "Inscription rattachée à la classe choisie",
                "Factures créées et visibles dans Finances",
              ].map((line) => (
                <li key={line} className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-brand-600" />
                  {line}
                </li>
              ))}
            </ul>
            <div className="mt-4 flex items-start gap-2 rounded-xl bg-sand p-3 text-[11px] text-ink/55">
              <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              Un seul paiement enregistré met à jour la facture, le solde de l&apos;élève et le tableau de bord.
            </div>
            <div className="mt-4 flex flex-col gap-2">
              <SubmitButton className="btn-primary w-full" pendingLabel="Création du dossier…">
                <UserPlus className="h-4 w-4" /> Enregistrer l&apos;inscription
              </SubmitButton>
              <Link href="/eleves" className="btn-outline w-full justify-center">
                Annuler
              </Link>
            </div>
          </SectionCard>
        </div>
      </form>
    </>
  );
}
