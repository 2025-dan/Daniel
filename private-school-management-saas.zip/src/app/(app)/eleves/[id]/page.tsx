import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  BellRing,
  CalendarDays,
  FileText,
  Mail,
  MapPin,
  Phone,
  Receipt,
  Send,
  Stethoscope,
  Wallet,
} from "lucide-react";
import { Avatar, Badge, InfoRow, Notice, ProgressBar, SectionCard } from "@/components/ui";
import { SubmitButton } from "@/components/forms";
import { Restricted } from "@/components/restricted";
import { recordPayment, sendReminder, updateStudent } from "@/lib/actions";
import { getStudentDetail } from "@/lib/data/students";
import { computeClassResults } from "@/lib/data/academics";
import { formatFileSize, getStudentDocuments } from "@/lib/data/documents";
import { DOCUMENT_CATEGORIES, DOCUMENT_STATUS_LABEL } from "@/lib/format";
import { getClassSummaries } from "@/lib/data/context";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import {
  ATTENDANCE_TONE,
  CHANNEL_LABEL,
  INVOICE_TONE,
  PAYMENT_METHODS,
  appreciationFor,
  dueLabel,
  formatDate,
  gradeLabel,
  money,
  percent,
  todayISO,
} from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ inscription?: string; modifie?: string }>;
};

export default async function StudentDetailPage({ params, searchParams }: Props) {
  const [role, { id }, query] = await Promise.all([getRole(), params, searchParams]);
  if (!can(role, "students")) return <Restricted role={role} module="Dossiers élèves" />;

  const studentId = Number(id);
  if (!Number.isFinite(studentId)) notFound();

  const detail = await getStudentDetail(studentId);
  if (!detail) notFound();

  const { student, enrollment, guardians, invoices, payments, attendance, finance } = detail;
  const [results, classRows, docs] = await Promise.all([
    enrollment ? computeClassResults(enrollment.classId, "Trimestre 1") : Promise.resolve(null),
    getClassSummaries(),
    getStudentDocuments(studentId, 8),
  ]);
  const myResult = results?.students.find((s) => s.id === student.id) ?? null;
  const canPay = can(role, "finance");

  return (
    <>
      <Link href="/eleves" className="mb-4 inline-flex items-center gap-1.5 text-xs font-semibold text-ink/50 hover:text-ink">
        <ArrowLeft className="h-3.5 w-3.5" /> Tous les élèves
      </Link>

      {query.inscription ? (
        <div className="mb-4">
          <Notice>Inscription enregistrée. Le dossier, les tuteurs et les frais sont désormais disponibles.</Notice>
        </div>
      ) : null}
      {query.modifie ? (
        <div className="mb-4">
          <Notice>Le dossier de l&apos;élève a été mis à jour.</Notice>
        </div>
      ) : null}

      <div className="card mb-4 flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <Avatar first={student.firstName} last={student.lastName} size="lg" />
          <div>
            <h1 className="font-display text-xl font-semibold tracking-tight text-ink sm:text-2xl">
              {student.lastName} {student.firstName}
            </h1>
            <p className="mt-0.5 text-xs text-ink/50">
              {student.matricule} · {student.gender === "F" ? "Fille" : "Garçon"} · inscrit le{" "}
              {formatDate(student.enrolledAt)}
            </p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              <Badge tone={student.status === "actif" ? "success" : "warning"}>
                {student.status === "actif" ? "Dossier actif" : "Suspendu"}
              </Badge>
              {enrollment ? <Badge tone="info">{enrollment.className}</Badge> : <Badge>Sans classe</Badge>}
              {finance.balance > 0 ? (
                <Badge tone="danger">Solde {money(finance.balance)}</Badge>
              ) : (
                <Badge tone="success">Scolarité à jour</Badge>
              )}
            </div>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link href={`/bulletins/${student.id}?term=Trimestre%201`} className="btn-outline">
            <FileText className="h-4 w-4" /> Bulletin
          </Link>
          {can(role, "messages") ? (
            <Link href={`/communication?eleve=${student.id}`} className="btn-soft">
              <Send className="h-4 w-4" /> Contacter le tuteur
            </Link>
          ) : null}
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.55fr_1fr]">
        <div className="space-y-4">
          <SectionCard
            title="Scolarité & factures"
            description={`${invoices.length} facture(s) · ${money(finance.paid)} encaissés`}
            action={
              <Badge tone={finance.balance <= 0 ? "success" : "danger"}>
                Solde {money(finance.balance)}
              </Badge>
            }
            bodyClassName="p-5"
          >
            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-xl bg-sand p-3">
                <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Facturé</p>
                <p className="mt-1 text-sm font-bold text-ink">{money(finance.invoiced)}</p>
              </div>
              <div className="rounded-xl bg-brand-50 p-3">
                <p className="text-[10px] font-bold uppercase tracking-wide text-brand-700/60">Encaissé</p>
                <p className="mt-1 text-sm font-bold text-brand-800">{money(finance.paid)}</p>
              </div>
              <div className="rounded-xl bg-amber-50 p-3">
                <p className="text-[10px] font-bold uppercase tracking-wide text-amber-700/70">Reste</p>
                <p className="mt-1 text-sm font-bold text-amber-800">{money(finance.balance)}</p>
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2">
              <ProgressBar value={finance.rate} tone={finance.rate >= 80 ? "brand" : finance.rate >= 40 ? "amber" : "danger"} />
              <span className="text-xs font-bold text-ink/50">{finance.rate}%</span>
            </div>

            <div className="mt-4 space-y-2">
              {invoices.map((invoice) => {
                const balance = invoice.amount - invoice.amountPaid;
                return (
                  <div key={invoice.id} className="rounded-xl border border-ink/8 p-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <p className="text-sm font-semibold text-ink">{invoice.label}</p>
                        <p className="text-[11px] text-ink/45">
                          {invoice.number} · échéance {formatDate(invoice.dueDate)} ·{" "}
                          {balance > 0 ? dueLabel(invoice.dueDate) : "soldée"}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-ink">{money(invoice.amount, false)}</span>
                        <Badge tone={invoice.status === "payée" ? "success" : invoice.status === "partielle" ? "warning" : "danger"}>
                          {invoice.status}
                        </Badge>
                      </div>
                    </div>
                    {balance > 0 && canPay ? (
                      <div className="mt-2 flex flex-wrap items-center gap-2">
                        <details className="flex-1">
                          <summary className="btn-soft btn-sm inline-flex cursor-pointer list-none">
                            <Wallet className="h-3.5 w-3.5" /> Encaisser {money(balance)}
                          </summary>
                          <form action={recordPayment} className="mt-2 grid gap-2 rounded-xl border border-ink/10 bg-sand/60 p-3 sm:grid-cols-2">
                            <input type="hidden" name="invoiceId" value={invoice.id} />
                            <input type="hidden" name="redirectTo" value={`/eleves/${student.id}`} />
                            <div>
                              <label className="label" htmlFor={`amount-${invoice.id}`}>Montant reçu (FC)</label>
                              <input
                                id={`amount-${invoice.id}`}
                                name="amount"
                                type="number"
                                min={1}
                                max={balance}
                                defaultValue={balance}
                                className="input"
                              />
                            </div>
                            <div>
                              <label className="label" htmlFor={`method-${invoice.id}`}>Moyen de paiement</label>
                              <select id={`method-${invoice.id}`} name="method" className="input">
                                {PAYMENT_METHODS.map((m) => (
                                  <option key={m} value={m}>{CHANNEL_LABEL[m] ?? m}</option>
                                ))}
                              </select>
                            </div>
                            <div>
                              <label className="label" htmlFor={`reference-${invoice.id}`}>Référence</label>
                              <input id={`reference-${invoice.id}`} name="reference" className="input" placeholder="OM-458921" />
                            </div>
                            <div>
                              <label className="label" htmlFor={`paidAt-${invoice.id}`}>Date</label>
                              <input id={`paidAt-${invoice.id}`} name="paidAt" type="date" defaultValue={todayISO()} className="input" />
                            </div>
                            <div className="sm:col-span-2">
                              <SubmitButton className="btn-primary w-full btn-sm" pendingLabel="Encaissement…">
                                <Receipt className="h-3.5 w-3.5" /> Valider le paiement
                              </SubmitButton>
                            </div>
                          </form>
                        </details>
                        <form action={sendReminder}>
                          <input type="hidden" name="invoiceId" value={invoice.id} />
                          <input type="hidden" name="redirectTo" value={`/eleves/${student.id}`} />
                          <input type="hidden" name="channel" value="sms" />
                          <SubmitButton className="btn-outline btn-sm" pendingLabel="Envoi…">
                            <BellRing className="h-3.5 w-3.5" /> Relancer
                          </SubmitButton>
                        </form>
                      </div>
                    ) : (
                      <p className="mt-2 text-[11px] font-semibold text-brand-700">
                        {balance > 0 ? `Reste ${money(balance)} à encaisser` : "Facture réglée intégralement"}
                      </p>
                    )}
                  </div>
                );
              })}
              {invoices.length === 0 ? <p className="text-sm text-ink/50">Aucune facture pour cet élève.</p> : null}
            </div>
          </SectionCard>

          <SectionCard
            title="Résultats — Trimestre 1"
            description={enrollment ? `${enrollment.className} · moyenne pondérée par coefficient` : "Aucune classe"}
            action={myResult?.rank ? <Badge tone="brand">{myResult.rank}ᵉ / {results?.students.length}</Badge> : null}
          >
            {results && myResult ? (
              <>
                <div className="mb-4 flex flex-wrap items-center gap-4 rounded-xl bg-sand p-4">
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Moyenne générale</p>
                    <p className="font-display text-2xl font-bold text-ink">{gradeLabel(myResult.average)}/20</p>
                  </div>
                  <div className="h-10 w-px bg-ink/10" />
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Moyenne de classe</p>
                    <p className="font-display text-2xl font-bold text-ink/70">{gradeLabel(results.classAverage)}/20</p>
                  </div>
                  <p className="ml-auto max-w-[220px] text-xs text-ink/55">{appreciationFor(myResult.average)}</p>
                </div>
                <div className="space-y-1.5">
                  {results.subjects.map((subject) => {
                    const avg = myResult.subjectAverages[subject.id] ?? null;
                    return (
                      <div key={subject.id} className="flex items-center justify-between gap-3 rounded-lg px-2 py-1.5 hover:bg-sand/60">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium text-ink/80">{subject.name}</p>
                          <p className="text-[10px] text-ink/40">Coef. {subject.coefficient} · moy. classe {gradeLabel(subject.classAverage)}</p>
                        </div>
                        <span className={`text-sm font-bold ${avg === null ? "text-ink/30" : avg >= 10 ? "text-brand-700" : "text-red-600"}`}>
                          {gradeLabel(avg)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </>
            ) : (
              <p className="text-sm text-ink/50">Aucune évaluation enregistrée pour cette classe.</p>
            )}
          </SectionCard>

          <SectionCard title="Historique des paiements" description={`${payments.length} encaissement(s)`} bodyClassName="divide-y divide-ink/6">
            {payments.length === 0 ? (
              <p className="px-5 py-6 text-sm text-ink/50">Aucun paiement enregistré.</p>
            ) : (
              payments.map((payment) => (
                <div key={payment.id} className="flex flex-wrap items-center justify-between gap-2 px-5 py-3">
                  <div>
                    <p className="text-sm font-semibold text-ink">{money(payment.amount)}</p>
                    <p className="text-[11px] text-ink/45">
                      {CHANNEL_LABEL[payment.method] ?? payment.method}
                      {payment.reference ? ` · ${payment.reference}` : ""} · {formatDate(payment.paidAt)}
                    </p>
                  </div>
                  <span className="text-[11px] font-medium text-ink/40">{payment.recordedBy}</span>
                </div>
              ))
            )}
          </SectionCard>
        </div>

        <div className="space-y-4">
          <SectionCard title="Informations personnelles">
            <div className="flex items-center gap-3">
              <Avatar first={student.firstName} last={student.lastName} size="lg" />
              <div>
                <p className="text-sm font-semibold text-ink">{student.lastName} {student.firstName}</p>
                <p className="text-[11px] text-ink/45">{student.matricule}</p>
              </div>
            </div>
            <div className="mt-3">
              <InfoRow label="Naissance" value={student.birthDate ? formatDate(student.birthDate) : "—"} />
              <InfoRow label="Lieu" value={<span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5 text-ink/30" />{student.birthPlace || "—"}</span>} />
              <InfoRow label="Adresse" value={student.address || "—"} />
              <InfoRow label="Groupe sanguin" value={<span className="inline-flex items-center gap-1"><Stethoscope className="h-3.5 w-3.5 text-ink/30" />{student.bloodGroup || "—"}</span>} />
              <InfoRow label="Classe" value={enrollment ? `${enrollment.className} · ${enrollment.cycle}` : "Non affecté"} />
              <InfoRow label="Titulaire" value={enrollment?.teacher || "—"} />
              <InfoRow label="Salle" value={enrollment?.room || "—"} />
              <InfoRow label="Inscription" value={<span className="inline-flex items-center gap-1"><CalendarDays className="h-3.5 w-3.5 text-ink/30" />{formatDate(student.enrolledAt)}</span>} />
            </div>
            {student.notes ? (
              <p className="mt-3 rounded-xl bg-amber-50 p-3 text-xs text-amber-800">{student.notes}</p>
            ) : null}

            {role === "directeur" || role === "enseignant" ? (
              <details className="mt-3 rounded-xl border border-ink/10 bg-sand/50 p-3">
                <summary className="cursor-pointer text-xs font-bold uppercase tracking-wide text-ink/50">
                  Modifier le dossier
                </summary>
                <form action={updateStudent} className="mt-3 space-y-2.5">
                  <input type="hidden" name="studentId" value={student.id} />
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="label" htmlFor="edit-last">Nom</label>
                      <input id="edit-last" name="lastName" defaultValue={student.lastName} className="input" required />
                    </div>
                    <div>
                      <label className="label" htmlFor="edit-first">Prénom</label>
                      <input id="edit-first" name="firstName" defaultValue={student.firstName} className="input" required />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="label" htmlFor="edit-gender">Sexe</label>
                      <select id="edit-gender" name="gender" defaultValue={student.gender} className="input">
                        <option value="F">Féminin</option>
                        <option value="M">Masculin</option>
                      </select>
                    </div>
                    <div>
                      <label className="label" htmlFor="edit-status">Statut</label>
                      <select id="edit-status" name="status" defaultValue={student.status} className="input">
                        <option value="actif">Actif</option>
                        <option value="suspendu">Suspendu</option>
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="label" htmlFor="edit-birth">Naissance</label>
                      <input id="edit-birth" name="birthDate" type="date" defaultValue={student.birthDate ?? ""} className="input" />
                    </div>
                    <div>
                      <label className="label" htmlFor="edit-birthplace">Lieu</label>
                      <input id="edit-birthplace" name="birthPlace" defaultValue={student.birthPlace} className="input" />
                    </div>
                  </div>
                  <div>
                    <label className="label" htmlFor="edit-class">Classe</label>
                    <select id="edit-class" name="classId" defaultValue={enrollment ? String(enrollment.classId) : ""} className="input">
                      <option value="">Retirer de la classe</option>
                      {classRows.map((cls) => (
                        <option key={cls.id} value={cls.id}>{cls.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="label" htmlFor="edit-address">Adresse</label>
                    <input id="edit-address" name="address" defaultValue={student.address} className="input" />
                  </div>
                  <div>
                    <label className="label" htmlFor="edit-notes">Observations</label>
                    <textarea id="edit-notes" name="notes" rows={2} defaultValue={student.notes} className="input" />
                  </div>
                  <SubmitButton className="btn-primary w-full btn-sm" pendingLabel="Mise à jour…">
                    Enregistrer les modifications
                  </SubmitButton>
                </form>
              </details>
            ) : null}
          </SectionCard>

          <SectionCard
            title="Documents du dossier"
            description={`${docs.length} pièce(s) — actes, bulletins scannés, imports`}
            action={
              can(role, "documents") ? (
                <Link href={`/documents?eleve=${student.id}`} className="text-xs font-semibold text-brand-700 hover:underline">
                  Gérer
                </Link>
              ) : null
            }
            bodyClassName="divide-y divide-ink/6"
          >
            {docs.length === 0 ? (
              <div className="px-5 py-4">
                <p className="text-sm text-ink/50">Aucun document au dossier.</p>
                {can(role, "documents") ? (
                  <Link href={`/documents?eleve=${student.id}`} className="btn-soft btn-sm mt-2 inline-flex">
                    Importer un document
                  </Link>
                ) : null}
              </div>
            ) : (
              docs.map((doc) => (
                <div key={doc.id} className="flex items-center justify-between gap-2 px-5 py-2.5">
                  <div className="min-w-0">
                    <p className="truncate text-xs font-semibold text-ink">{doc.title}</p>
                    <p className="text-[10px] text-ink/40">
                      {DOCUMENT_CATEGORIES.find((c) => c.key === doc.category)?.label ?? "Document"} ·{" "}
                      {formatFileSize(doc.fileSize)}
                      {doc.term ? ` · ${doc.term}` : ""}
                      {doc.average !== null ? ` · ${gradeLabel(doc.average)}/20` : ""}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-1.5">
                    <Badge tone={doc.status === "validé" ? "success" : doc.status === "rejeté" ? "danger" : "warning"}>
                      {DOCUMENT_STATUS_LABEL[doc.status] ?? doc.status}
                    </Badge>
                    <a href={`/api/documents/${doc.id}`} target="_blank" className="btn-ghost btn-sm !px-2" aria-label="Ouvrir le document">
                      <FileText className="h-3.5 w-3.5" />
                    </a>
                  </div>
                </div>
              ))
            )}
          </SectionCard>

          <SectionCard title="Tuteurs" description="Contacts pour les relances et messages">
            <div className="space-y-2.5">
              {guardians.map((guardian) => (
                <div key={guardian.id} className="rounded-xl border border-ink/8 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-semibold text-ink">{guardian.fullName}</p>
                    <Badge tone={guardian.isPrimary ? "brand" : "neutral"}>{guardian.relation}</Badge>
                  </div>
                  <p className="mt-1 text-[11px] text-ink/45">{guardian.profession || "Profession non renseignée"}</p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {guardian.phone ? (
                      <a href={`tel:${guardian.phone.replace(/\s/g, "")}`} className="btn-outline btn-sm">
                        <Phone className="h-3.5 w-3.5" /> {guardian.phone}
                      </a>
                    ) : null}
                    {guardian.email ? (
                      <a href={`mailto:${guardian.email}`} className="btn-ghost btn-sm">
                        <Mail className="h-3.5 w-3.5" /> {guardian.email}
                      </a>
                    ) : null}
                  </div>
                </div>
              ))}
              {guardians.length === 0 ? <p className="text-sm text-ink/50">Aucun tuteur renseigné.</p> : null}
            </div>
          </SectionCard>

          <SectionCard title="Assiduité" description={`${attendance.rate}% de présence`}>
            <div className="flex items-end justify-between">
              <p className="font-display text-3xl font-bold text-ink">{attendance.rate}%</p>
              <p className="text-[11px] text-ink/45">{attendance.present}/{attendance.total} pointages</p>
            </div>
            <ProgressBar value={attendance.rate} tone={attendance.rate >= 90 ? "brand" : "amber"} className="mt-2" />
            <div className="mt-3 flex flex-wrap gap-1.5">
              {attendance.breakdown.map((item) => (
                <span key={item.status} className={`badge ${ATTENDANCE_TONE[item.status] ?? ""}`}>
                  {item.status} · {item.total}
                </span>
              ))}
            </div>
            {attendance.absences.length > 0 ? (
              <div className="mt-4">
                <p className="mb-1.5 text-[10px] font-bold uppercase tracking-wide text-ink/40">Dernières absences / retards</p>
                <ul className="space-y-1">
                  {attendance.absences.map((absence, index) => (
                    <li key={`${absence.date}-${index}`} className="flex items-center justify-between text-xs">
                      <span className="text-ink/60">{formatDate(absence.date)}</span>
                      <span className={`badge ${ATTENDANCE_TONE[absence.status] ?? ""}`}>{absence.status}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </SectionCard>
        </div>
      </div>
    </>
  );
}
