import Link from "next/link";
import { ChevronRight, Filter, Search, UserPlus, Users, Wallet } from "lucide-react";
import { Avatar, Badge, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { Restricted } from "@/components/restricted";
import { getStudents } from "@/lib/data/students";
import { getClassSummaries } from "@/lib/data/context";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import { formatDate, money, percent } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = {
  searchParams: Promise<{ q?: string; classe?: string; statut?: string }>;
};

export default async function StudentsPage({ searchParams }: Props) {
  const [role, params] = await Promise.all([getRole(), searchParams]);
  if (!can(role, "students")) return <Restricted role={role} module="Élèves & dossiers" />;

  const [filtered, all, classRows] = await Promise.all([
    getStudents({ q: params.q, classId: params.classe, status: params.statut }),
    getStudents(),
    getClassSummaries(),
  ]);

  const totalBalance = all.reduce((sum, s) => sum + Math.max(0, s.invoiced - s.paid), 0);
  const withDebt = all.filter((s) => s.invoiced - s.paid > 0).length;
  const activeFilters = Boolean(params.q || params.classe || params.statut);

  return (
    <>
      <PageHeader
        eyebrow="Scolarité"
        title="Élèves & dossiers"
        subtitle="Toutes les inscriptions de l'année en cours, avec la situation financière et le tuteur principal."
        actions={
          <Link href="/eleves/nouveau" className="btn-primary">
            <UserPlus className="h-4 w-4" /> Inscrire un élève
          </Link>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Dossiers élèves" value={all.length} hint={`${classRows.length} classes ouvertes`} icon={Users} />
        <StatCard
          label="Élèves actifs"
          value={all.filter((s) => s.status === "actif").length}
          hint={`${all.filter((s) => s.status !== "actif").length} dossier(s) suspendu(s)`}
          icon={Users}
          tone="sky"
        />
        <StatCard
          label="Soldes à recouvrer"
          value={money(totalBalance)}
          hint={`${withDebt} famille(s) concernée(s)`}
          icon={Wallet}
          tone="amber"
        />
        <StatCard
          label="Taux de recouvrement"
          value={`${percent(
            all.reduce((s, r) => s + r.paid, 0),
            Math.max(1, all.reduce((s, r) => s + r.invoiced, 0)),
          )}%`}
          hint="Sur l'ensemble des factures émises"
          icon={Wallet}
          tone="brand"
        />
      </div>

      <div className="card mt-4 overflow-hidden">
        <div className="flex flex-col gap-3 border-b border-ink/8 p-4 lg:flex-row lg:items-center lg:justify-between">
          <form className="flex flex-1 flex-col gap-2 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/35" />
              <input
                name="q"
                defaultValue={params.q ?? ""}
                placeholder="Nom, matricule, téléphone du tuteur…"
                className="input pl-9"
              />
            </div>
            <select name="classe" defaultValue={params.classe ?? ""} className="input sm:w-44">
              <option value="">Toutes les classes</option>
              {classRows.map((cls) => (
                <option key={cls.id} value={cls.id}>
                  {cls.name}
                </option>
              ))}
            </select>
            <select name="statut" defaultValue={params.statut ?? ""} className="input sm:w-36">
              <option value="">Tous statuts</option>
              <option value="actif">Actif</option>
              <option value="suspendu">Suspendu</option>
            </select>
            <button type="submit" className="btn-outline sm:w-auto">
              <Filter className="h-4 w-4" /> Filtrer
            </button>
          </form>
          <p className="text-xs font-semibold text-ink/45">
            {filtered.length} élève{filtered.length > 1 ? "s" : ""} affiché{filtered.length > 1 ? "s" : ""}
            {activeFilters ? (
              <Link href="/eleves" className="ml-2 font-semibold text-brand-700 hover:underline">
                Réinitialiser
              </Link>
            ) : null}
          </p>
        </div>

        {filtered.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={Users}
              title="Aucun élève trouvé"
              description="Modifiez vos filtres ou inscrivez un nouvel élève dans une classe."
              action={
                <Link href="/eleves/nouveau" className="btn-primary">
                  <UserPlus className="h-4 w-4" /> Inscrire un élève
                </Link>
              }
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px] border-collapse">
              <thead className="bg-sand/60">
                <tr>
                  <th className="th">Élève</th>
                  <th className="th">Classe</th>
                  <th className="th">Tuteur principal</th>
                  <th className="th">Scolarité</th>
                  <th className="th">Solde</th>
                  <th className="th">Statut</th>
                  <th className="th text-right">Dossier</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink/6">
                {filtered.map((student) => {
                  const balance = student.invoiced - student.paid;
                  return (
                    <tr key={student.id} className="row-hover">
                      <td className="td">
                        <div className="flex items-center gap-3">
                          <Avatar first={student.firstName} last={student.lastName} size="sm" />
                          <div className="min-w-0">
                            <Link href={`/eleves/${student.id}`} className="block truncate font-semibold text-ink hover:underline">
                              {student.lastName} {student.firstName}
                            </Link>
                            <span className="text-[11px] text-ink/45">
                              {student.matricule} · {student.gender === "F" ? "Fille" : "Garçon"} · inscrit le{" "}
                              {formatDate(student.enrolledAt)}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="td">
                        <p className="font-medium text-ink/80">{student.className ?? "Non affecté"}</p>
                        <p className="text-[11px] text-ink/45">{student.cycle ?? "—"}</p>
                      </td>
                      <td className="td">
                        <p className="text-sm text-ink/80">{student.guardianName}</p>
                        <p className="text-[11px] text-ink/45">
                          {student.guardianRelation} · {student.guardianPhone || "téléphone non renseigné"}
                        </p>
                      </td>
                      <td className="td w-44">
                        <div className="flex items-center justify-between text-[11px] text-ink/50">
                          <span>{money(student.paid, false)}</span>
                          <span>{money(student.invoiced, false)}</span>
                        </div>
                        <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-ink/8">
                          <div
                            className={`h-full rounded-full ${balance <= 0 ? "bg-brand-500" : student.paid > 0 ? "bg-amber-400" : "bg-red-400"}`}
                            style={{ width: `${Math.min(100, percent(student.paid, Math.max(1, student.invoiced)))}%` }}
                          />
                        </div>
                      </td>
                      <td className="td">
                        {balance <= 0 ? (
                          <Badge tone="success">À jour</Badge>
                        ) : (
                          <span className="text-sm font-bold text-red-600">{money(balance)}</span>
                        )}
                      </td>
                      <td className="td">
                        <Badge tone={student.status === "actif" ? "success" : "warning"}>
                          {student.status === "actif" ? "Actif" : "Suspendu"}
                        </Badge>
                      </td>
                      <td className="td text-right">
                        <Link href={`/eleves/${student.id}`} className="btn-ghost btn-sm inline-flex">
                          Ouvrir <ChevronRight className="h-3.5 w-3.5" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
