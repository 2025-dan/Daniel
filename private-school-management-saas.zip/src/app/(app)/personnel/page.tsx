import Link from "next/link";
import { Banknote, BriefcaseBusiness, Mail, Phone, Plus, UserCog, Users } from "lucide-react";
import { Avatar, Badge, Notice, PageHeader, SectionCard, StatCard } from "@/components/ui";
import { SubmitButton } from "@/components/forms";
import { Restricted } from "@/components/restricted";
import { createStaff, updateStaffStatus } from "@/lib/actions";
import { getStaffPageData } from "@/lib/data/staff";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import { formatDate, money, todayISO } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<{ enregistre?: string; erreur?: string; categorie?: string }> };

const CATEGORIES: Record<string, string> = {
  direction: "Direction",
  administration: "Administration",
  enseignement: "Enseignement",
  surveillance: "Surveillance",
  support: "Support",
};

export default async function StaffPage({ searchParams }: Props) {
  const [role, params] = await Promise.all([getRole(), searchParams]);
  if (!can(role, "staff")) return <Restricted role={role} module="Personnel" />;

  const { staff, stats } = await getStaffPageData();
  const filtered = params.categorie ? staff.filter((s) => s.category === params.categorie) : staff;

  return (
    <>
      <PageHeader
        eyebrow="Ressources humaines"
        title="Équipe & contrats"
        subtitle="Enseignants, administration et surveillance : contrats, coordonnées et masse salariale."
        actions={
          <Link href="/paie" className="btn-primary">
            <Banknote className="h-4 w-4" /> Gérer la paie
          </Link>
        }
      />

      {params.enregistre === "membre" ? <div className="mb-4"><Notice>Le membre du personnel a été ajouté.</Notice></div> : null}
      {params.enregistre === "statut" ? <div className="mb-4"><Notice>Le statut du membre a été mis à jour.</Notice></div> : null}
      {params.erreur ? <div className="mb-4"><Notice tone="danger">{params.erreur}</Notice></div> : null}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Membres du personnel" value={stats.total} hint={`${stats.active} en activité`} icon={Users} />
        <StatCard label="Enseignants" value={stats.teaching} hint="Corps enseignant" icon={BriefcaseBusiness} tone="sky" />
        <StatCard label="Masse salariale" value={money(stats.payroll)} hint="Somme des salaires bruts mensuels" icon={Banknote} tone="amber" />
        <StatCard label="Paie en attente" value={money(stats.pendingAmount)} hint={`${stats.pending} bulletin(s) non réglé(s)`} icon={UserCog} tone="brand" />
      </div>

      <div className="card my-4 flex flex-wrap items-center gap-2 p-3">
        <Link href="/personnel" className={`badge ${!params.categorie ? "bg-brand-700 text-white" : "bg-ink/6 text-ink/60"}`}>
          Tous ({staff.length})
        </Link>
        {Object.entries(CATEGORIES).map(([key, label]) => {
          const count = staff.filter((s) => s.category === key).length;
          return (
            <Link
              key={key}
              href={`/personnel?categorie=${key}`}
              className={`badge ${params.categorie === key ? "bg-brand-700 text-white" : "bg-ink/6 text-ink/60"}`}
            >
              {label} ({count})
            </Link>
          );
        })}
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.55fr_1fr]">
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[780px] border-collapse">
              <thead className="bg-sand/60">
                <tr>
                  <th className="th">Membre</th>
                  <th className="th">Fonction</th>
                  <th className="th">Contact</th>
                  <th className="th">Embauche</th>
                  <th className="th">Salaire brut</th>
                  <th className="th">Statut</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink/6">
                {filtered.map((member) => (
                  <tr key={member.id} className="row-hover">
                    <td className="td">
                      <div className="flex items-center gap-2.5">
                        <Avatar first={member.firstName} last={member.lastName} size="sm" />
                        <div>
                          <p className="font-semibold text-ink">{member.lastName} {member.firstName}</p>
                          <p className="text-[11px] text-ink/45">{member.qualification || CATEGORIES[member.category]}</p>
                        </div>
                      </div>
                    </td>
                    <td className="td">
                      <p className="text-sm text-ink/80">{member.jobTitle}</p>
                      <p className="text-[11px] text-ink/45">{CATEGORIES[member.category] ?? member.category}</p>
                    </td>
                    <td className="td">
                      <p className="flex items-center gap-1 text-[11px] text-ink/60">
                        <Phone className="h-3 w-3" /> {member.phone || "—"}
                      </p>
                      <p className="flex items-center gap-1 text-[11px] text-ink/45">
                        <Mail className="h-3 w-3" /> {member.email || "—"}
                      </p>
                    </td>
                    <td className="td whitespace-nowrap text-xs text-ink/55">{formatDate(member.hireDate)}</td>
                    <td className="td whitespace-nowrap font-semibold">{money(member.monthlySalary)}</td>
                    <td className="td">
                      <div className="flex items-center gap-1.5">
                        <Badge tone={member.status === "actif" ? "success" : member.status === "congé" ? "warning" : "neutral"}>
                          {member.status}
                        </Badge>
                        {role === "directeur" ? (
                          <form action={updateStaffStatus}>
                            <input type="hidden" name="staffId" value={member.id} />
                            <input type="hidden" name="status" value={member.status === "actif" ? "congé" : "actif"} />
                            <SubmitButton className="btn-ghost btn-sm !px-1.5 text-[10px]" pendingLabel="">
                              {member.status === "actif" ? "Congé" : "Activer"}
                            </SubmitButton>
                          </form>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 ? <p className="p-6 text-center text-sm text-ink/50">Aucun membre dans cette catégorie.</p> : null}
        </div>

        <div className="space-y-4">
          <SectionCard title="Ajouter un membre" description="Contrat et salaire de base">
            <form action={createStaff} className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className="label" htmlFor="lastName">Nom *</label>
                <input id="lastName" name="lastName" className="input" required />
              </div>
              <div>
                <label className="label" htmlFor="firstName">Prénom *</label>
                <input id="firstName" name="firstName" className="input" required />
              </div>
              <div>
                <label className="label" htmlFor="jobTitle">Fonction</label>
                <input id="jobTitle" name="jobTitle" className="input" defaultValue="Enseignant" />
              </div>
              <div>
                <label className="label" htmlFor="category">Catégorie</label>
                <select id="category" name="category" className="input" defaultValue="enseignement">
                  {Object.entries(CATEGORIES).map(([key, label]) => (
                    <option key={key} value={key}>{label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label" htmlFor="phone">Téléphone</label>
                <input id="phone" name="phone" className="input" placeholder="+225 ..." />
              </div>
              <div>
                <label className="label" htmlFor="email">E-mail</label>
                <input id="email" name="email" type="email" className="input" />
              </div>
              <div className="sm:col-span-2">
                <label className="label" htmlFor="qualification">Diplôme / qualification</label>
                <input id="qualification" name="qualification" className="input" placeholder="Licence, CAFOP…" />
              </div>
              <div>
                <label className="label" htmlFor="hireDate">Date d&apos;embauche</label>
                <input id="hireDate" name="hireDate" type="date" defaultValue={todayISO()} className="input" />
              </div>
              <div>
                <label className="label" htmlFor="monthlySalary">Salaire brut (FC)</label>
                <input id="monthlySalary" name="monthlySalary" type="number" min={0} step={5000} defaultValue={150000} className="input" />
              </div>
              <div className="sm:col-span-2">
                <SubmitButton className="btn-primary w-full" pendingLabel="Création du contrat…">
                  <Plus className="h-4 w-4" /> Enregistrer le membre
                </SubmitButton>
              </div>
            </form>
          </SectionCard>

          <SectionCard title="À retenir" description="Gestion sociale simplifiée">
            <ul className="space-y-2 text-xs leading-relaxed text-ink/60">
              <li>• Les retenues sociales sont calculées automatiquement (5,75 %) sur le brut.</li>
              <li>• La génération de paie est idempotente : aucun doublon par période.</li>
              <li>• Un membre en congé reste payé ; un membre inactif sort de la paie.</li>
              <li>• Chaque bulletin payé génère une référence unique pour la comptabilité.</li>
            </ul>
            <Link href="/paie" className="btn-outline mt-3 w-full justify-center">
              <Banknote className="h-4 w-4" /> Ouvrir la paie
            </Link>
          </SectionCard>
        </div>
      </div>
    </>
  );
}
