import Link from "next/link";
import { CalendarCheck, CheckCircle2, Clock, Phone, Save, UserX } from "lucide-react";
import { Avatar, Badge, Notice, PageHeader, ProgressBar, SectionCard, StatCard } from "@/components/ui";
import { TrendBars } from "@/components/charts";
import { SubmitButton } from "@/components/forms";
import { Restricted } from "@/components/restricted";
import { saveAttendance } from "@/lib/actions";
import { getAttendancePageData } from "@/lib/data/academics";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import { ATTENDANCE_TONE, formatDate, percent } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<{ classId?: string; date?: string; enregistre?: string }> };

const STATUS_OPTIONS = [
  { value: "présent", label: "Présent" },
  { value: "absent", label: "Absent" },
  { value: "retard", label: "Retard" },
  { value: "excusé", label: "Excusé" },
];

export default async function AttendancePage({ searchParams }: Props) {
  const [role, params] = await Promise.all([getRole(), searchParams]);
  if (!can(role, "attendance")) return <Restricted role={role} module="Présences" />;

  const data = await getAttendancePageData({ classId: params.classId, date: params.date });
  const { classRows, selectedClass, date, pupils, summary, recentAbsences, trend, saved } = data;

  if (!selectedClass || !summary) {
    return (
      <>
        <PageHeader eyebrow="Vie scolaire" title="Présences" subtitle="Aucune classe n'est ouverte pour le moment." />
        <Notice tone="warning">Créez une classe puis inscrivez des élèves pour faire l&apos;appel.</Notice>
      </>
    );
  }

  const rate = percent(summary.présent + summary.retard, Math.max(1, summary.total));

  return (
    <>
      <PageHeader
        eyebrow="Vie scolaire"
        title="Présences & absences"
        subtitle="L'appel du jour, les retards et les absences justifiées — visibles immédiatement par la direction et les familles."
        actions={
          <Link href={`/classes/${selectedClass.id}`} className="btn-outline">
            Voir la classe
          </Link>
        }
      />

      {params.enregistre ? (
        <div className="mb-4">
          <Notice>L&apos;appel du {formatDate(date)} a été enregistré pour la classe {selectedClass.name}.</Notice>
        </div>
      ) : null}

      <div className="card mb-4 flex flex-col gap-3 p-4 lg:flex-row lg:items-end lg:justify-between">
        <form className="flex flex-1 flex-col gap-2 sm:flex-row sm:items-end">
          <div className="sm:w-56">
            <label className="label" htmlFor="classId">Classe</label>
            <select id="classId" name="classId" className="input" defaultValue={String(selectedClass.id)}>
              {classRows.map((cls) => (
                <option key={cls.id} value={cls.id}>{cls.name}</option>
              ))}
            </select>
          </div>
          <div className="sm:w-48">
            <label className="label" htmlFor="date">Journée</label>
            <input id="date" name="date" type="date" defaultValue={date} className="input" />
          </div>
          <button type="submit" className="btn-primary">
            <CalendarCheck className="h-4 w-4" /> Afficher la feuille
          </button>
        </form>
        <p className="text-xs text-ink/50">
          {saved ? "Feuille déjà enregistrée pour cette date." : "Aucun appel enregistré pour cette date : les élèves sont présents par défaut."}
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Effectif" value={summary.total} hint={`${selectedClass.name} · ${formatDate(date)}`} icon={CalendarCheck} />
        <StatCard label="Présents" value={summary.présent + summary.retard} hint={`${rate}% de présence`} icon={CheckCircle2} tone="brand" footer={<ProgressBar value={rate} />} />
        <StatCard label="Absents" value={summary.absent} hint={`${summary.excusé} absence(s) excusée(s)`} icon={UserX} tone="danger" />
        <StatCard label="Retards" value={summary.retard} hint="Arrivées tardives du jour" icon={Clock} tone="amber" />
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-[1.6fr_1fr]">
        <SectionCard
          title={`Feuille d'appel — ${selectedClass.name}`}
          description={`${formatDate(date)} · cochez le statut de chaque élève puis enregistrez`}
          action={<Badge tone={saved ? "success" : "warning"}>{saved ? "Enregistré" : "À faire"}</Badge>}
        >
          <form action={saveAttendance}>
            <input type="hidden" name="classId" value={selectedClass.id} />
            <input type="hidden" name="date" value={date} />
            <div className="divide-y divide-ink/6">
              {pupils.map((pupil) => (
                <div key={pupil.id} className="flex flex-col gap-2 py-2.5 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <Avatar first={pupil.firstName} last={pupil.lastName} size="sm" />
                    <div className="min-w-0">
                      <Link href={`/eleves/${pupil.id}`} className="block truncate text-sm font-semibold text-ink hover:underline">
                        {pupil.lastName} {pupil.firstName}
                      </Link>
                      <p className="text-[11px] text-ink/45">{pupil.matricule}</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {STATUS_OPTIONS.map((option) => (
                      <label key={option.value} className="cursor-pointer">
                        <input
                          type="radio"
                          name={`status_${pupil.id}`}
                          value={option.value}
                          defaultChecked={pupil.status === option.value}
                          className="peer sr-only"
                        />
                        <span className={`inline-block rounded-lg border border-ink/10 px-2.5 py-1 text-[11px] font-semibold text-ink/50 transition peer-checked:border-brand-700 peer-checked:bg-brand-700 peer-checked:text-white peer-focus-visible:ring-2 peer-focus-visible:ring-brand-300 ${
                          option.value === "absent" ? "peer-checked:border-red-600 peer-checked:bg-red-600" : ""
                        }`}>
                          {option.label}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            {pupils.length === 0 ? (
              <p className="py-6 text-center text-sm text-ink/50">Aucun élève inscrit dans cette classe.</p>
            ) : (
              <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-ink/8 pt-4">
                <SubmitButton className="btn-primary" pendingLabel="Enregistrement de l'appel…">
                  <Save className="h-4 w-4" /> Enregistrer l&apos;appel
                </SubmitButton>
                <p className="text-[11px] text-ink/45">
                  Ré-enregistrer remplace la feuille existante pour cette date.
                </p>
              </div>
            )}
          </form>
        </SectionCard>

        <div className="space-y-4">
          <SectionCard title="Tendance d'assiduité" description="8 dernières journées de classe">
            <TrendBars data={trend} />
            <div className="mt-4 space-y-2">
              {[
                { label: "Présents", value: summary.présent, tone: "brand" as const },
                { label: "Retards", value: summary.retard, tone: "amber" as const },
                { label: "Absents", value: summary.absent, tone: "danger" as const },
                { label: "Excusés", value: summary.excusé, tone: "sky" as const },
              ].map((row) => (
                <div key={row.label}>
                  <div className="flex items-center justify-between text-[11px] font-semibold text-ink/55">
                    <span>{row.label}</span>
                    <span>{row.value}</span>
                  </div>
                  <ProgressBar value={percent(row.value, Math.max(1, summary.total))} tone={row.tone} className="mt-1" />
                </div>
              ))}
            </div>
          </SectionCard>

          <SectionCard title="Dernières absences signalées" description="À destination de la vie scolaire et des familles" bodyClassName="divide-y divide-ink/6">
            {recentAbsences.length === 0 ? (
              <p className="px-5 py-6 text-sm text-ink/50">Aucune absence signalée.</p>
            ) : (
              recentAbsences.map((absence, index) => (
                <div key={`${absence.studentId}-${absence.date}-${index}`} className="flex items-center justify-between gap-2 px-5 py-3">
                  <div className="min-w-0">
                    <Link href={`/eleves/${absence.studentId}`} className="block truncate text-sm font-semibold text-ink hover:underline">
                      {absence.lastName} {absence.firstName}
                    </Link>
                    <p className="text-[11px] text-ink/45">
                      {absence.className} · {formatDate(absence.date)}
                    </p>
                    {absence.guardianPhone ? (
                      <a href={`tel:${absence.guardianPhone.replace(/\s/g, "")}`} className="mt-0.5 inline-flex items-center gap-1 text-[11px] font-semibold text-brand-700">
                        <Phone className="h-3 w-3" /> {absence.guardianPhone}
                      </a>
                    ) : null}
                  </div>
                  <span className={`badge ${ATTENDANCE_TONE[absence.status] ?? ""}`}>{absence.status}</span>
                </div>
              ))
            )}
          </SectionCard>
        </div>
      </div>
    </>
  );
}
