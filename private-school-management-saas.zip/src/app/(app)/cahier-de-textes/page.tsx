import Link from "next/link";
import { BookOpen, Filter, Home, Plus, Trash2 } from "lucide-react";
import { Badge, EmptyState, Notice, PageHeader, SectionCard, StatCard } from "@/components/ui";
import { SubmitButton } from "@/components/forms";
import { Restricted } from "@/components/restricted";
import { createLessonLog, deleteLessonLog } from "@/lib/actions";
import { getLessonsPageData } from "@/lib/data/school-life";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import { formatDate, todayISO } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = {
  searchParams: Promise<{ classId?: string; subjectId?: string; enregistre?: string; erreur?: string }>;
};

export default async function LessonLogsPage({ searchParams }: Props) {
  const [role, params] = await Promise.all([getRole(), searchParams]);
  if (!can(role, "lessons")) return <Restricted role={role} module="Cahier de textes" />;

  const { logs, classRows, subjectRows, homeworkTotal } = await getLessonsPageData({
    classId: params.classId,
    subjectId: params.subjectId,
  });

  const selectedClass = classRows.find((c) => String(c.id) === params.classId) ?? classRows[0] ?? null;

  return (
    <>
      <PageHeader
        eyebrow="Vie scolaire"
        title="Cahier de textes"
        subtitle="Séances réalisées, contenus abordés et devoirs à rendre : les familles et les élèves suivent le programme."
        actions={<Badge tone="brand">{logs.length} séance(s) · {homeworkTotal} devoirs</Badge>}
      />

      {params.enregistre ? <div className="mb-4"><Notice>La séance a été enregistrée dans le cahier de textes.</Notice></div> : null}
      {params.erreur ? <div className="mb-4"><Notice tone="danger">{params.erreur}</Notice></div> : null}

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Séances documentées" value={logs.length} hint="Sur les 60 dernières entrées" icon={BookOpen} />
        <StatCard label="Devoirs assignés" value={homeworkTotal} hint="Toutes classes confondues" icon={Home} tone="sky" />
        <StatCard label="Classes suivies" value={classRows.length} hint="Cahier de textes par classe" icon={Filter} tone="amber" />
      </div>

      <div className="card my-4 p-4">
        <form className="flex flex-col gap-2 sm:flex-row sm:items-end">
          <div className="sm:w-52">
            <label className="label" htmlFor="classId">Classe</label>
            <select id="classId" name="classId" className="input" defaultValue={params.classId ?? ""}>
              <option value="">Toutes les classes</option>
              {classRows.map((cls) => (
                <option key={cls.id} value={cls.id}>{cls.name}</option>
              ))}
            </select>
          </div>
          <div className="sm:w-52">
            <label className="label" htmlFor="subjectId">Matière</label>
            <select id="subjectId" name="subjectId" className="input" defaultValue={params.subjectId ?? ""}>
              <option value="">Toutes les matières</option>
              {subjectRows.map((subject) => (
                <option key={subject.id} value={subject.id}>{subject.name}</option>
              ))}
            </select>
          </div>
          <button type="submit" className="btn-primary">
            <Filter className="h-4 w-4" /> Filtrer
          </button>
          <Link href="/cahier-de-textes" className="btn-ghost">Réinitialiser</Link>
        </form>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.5fr_1fr]">
        <SectionCard title="Séances enregistrées" description="Les plus récentes en premier" bodyClassName="divide-y divide-ink/6">
          {logs.length === 0 ? (
            <div className="p-5">
              <EmptyState icon={BookOpen} title="Aucune séance" description="Ajoutez la première séance de cours avec son contenu et ses devoirs." />
            </div>
          ) : (
            logs.map((log) => (
              <div key={log.id} className="px-5 py-4">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <Badge tone="brand">{log.className}</Badge>
                      <Badge tone="info">{log.subjectName ?? "Matière libre"}</Badge>
                      <span className="text-[11px] font-medium text-ink/40">{formatDate(log.date)}</span>
                    </div>
                    <p className="mt-1.5 text-sm font-semibold text-ink">{log.title}</p>
                    <p className="mt-0.5 text-xs leading-relaxed text-ink/55">{log.content}</p>
                  </div>
                  <form action={deleteLessonLog}>
                    <input type="hidden" name="logId" value={log.id} />
                    <input type="hidden" name="classId" value={params.classId ?? ""} />
                    <SubmitButton className="btn-ghost btn-sm !px-2 text-red-500" pendingLabel="">
                      <Trash2 className="h-3.5 w-3.5" />
                    </SubmitButton>
                  </form>
                </div>
                {log.homework ? (
                  <div className="mt-2 rounded-lg border border-amber-200 bg-amber-50/60 px-3 py-2">
                    <p className="text-[10px] font-bold uppercase tracking-wide text-amber-700">Devoir à faire</p>
                    <p className="text-xs text-amber-900">{log.homework}</p>
                    {log.dueDate ? (
                      <p className="mt-0.5 text-[10px] font-semibold text-amber-700">À rendre le {formatDate(log.dueDate)}</p>
                    ) : null}
                  </div>
                ) : null}
                <p className="mt-1.5 text-[10px] uppercase tracking-wide text-ink/30">Enseignant : {log.teacher || "—"}</p>
              </div>
            ))
          )}
        </SectionCard>

        <SectionCard title="Nouvelle séance" description={selectedClass ? `Classe : ${selectedClass.name}` : "Choisissez une classe"}>
          <form action={createLessonLog} className="space-y-3">
            <div>
              <label className="label" htmlFor="log-class">Classe</label>
              <select id="log-class" name="classId" className="input" defaultValue={selectedClass ? String(selectedClass.id) : ""} required>
                <option value="">Sélectionner…</option>
                {classRows.map((cls) => (
                  <option key={cls.id} value={cls.id}>{cls.name}</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label" htmlFor="log-subject">Matière</label>
                <select id="log-subject" name="subjectId" className="input" defaultValue="">
                  <option value="">—</option>
                  {subjectRows.map((subject) => (
                    <option key={subject.id} value={subject.id}>{subject.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label" htmlFor="log-date">Date</label>
                <input id="log-date" name="date" type="date" defaultValue={todayISO()} className="input" />
              </div>
            </div>
            <div>
              <label className="label" htmlFor="log-title">Titre de la séance</label>
              <input id="log-title" name="title" className="input" placeholder="Les fractions décimales" required />
            </div>
            <div>
              <label className="label" htmlFor="log-content">Contenu abordé</label>
              <textarea id="log-content" name="content" rows={3} className="input" placeholder="Rappel, activité, exercices…" />
            </div>
            <div>
              <label className="label" htmlFor="log-homework">Devoir à faire</label>
              <textarea id="log-homework" name="homework" rows={2} className="input" placeholder="Exercices n°4 à 8 page 42" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label" htmlFor="log-due">À rendre le</label>
                <input id="log-due" name="dueDate" type="date" className="input" />
              </div>
              <div>
                <label className="label" htmlFor="log-teacher">Enseignant</label>
                <input id="log-teacher" name="teacher" className="input" defaultValue={selectedClass?.mainTeacher ?? ""} />
              </div>
            </div>
            <SubmitButton className="btn-primary w-full" pendingLabel="Enregistrement…">
              <Plus className="h-4 w-4" /> Ajouter la séance
            </SubmitButton>
          </form>
        </SectionCard>
      </div>
    </>
  );
}
