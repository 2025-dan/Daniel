import Link from "next/link";
import { CalendarDays, ClipboardList, FileText, Plus, Save, TrendingUp, TriangleAlert } from "lucide-react";
import { Avatar, Badge, EmptyState, Notice, PageHeader, SectionCard, StatCard } from "@/components/ui";
import { SubmitButton } from "@/components/forms";
import { Restricted } from "@/components/restricted";
import { createAssessment, saveGrades } from "@/lib/actions";
import { getClassSummaries } from "@/lib/data/context";
import { getFirstEvaluatedSubject, getGradeMatrix, getSubjects } from "@/lib/data/academics";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import { TERMS, formatDate, gradeLabel, todayISO } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = {
  searchParams: Promise<{ classId?: string; subjectId?: string; term?: string; enregistre?: string; erreur?: string }>;
};

export default async function GradesPage({ searchParams }: Props) {
  const [role, params] = await Promise.all([getRole(), searchParams]);
  if (!can(role, "grades")) return <Restricted role={role} module="Notes" />;

  const term = params.term && TERMS.includes(params.term as (typeof TERMS)[number]) ? params.term : "Trimestre 1";
  const [classRows, subjectRows] = await Promise.all([getClassSummaries(), getSubjects()]);
  const selectedClass = classRows.find((c) => String(c.id) === params.classId) ?? classRows[0] ?? null;

  if (!selectedClass) {
    return (
      <>
        <PageHeader eyebrow="Pédagogie" title="Saisie des notes" />
        <EmptyState icon={ClipboardList} title="Aucune classe" description="Créez une classe et inscrivez des élèves pour saisir des notes." />
      </>
    );
  }

  const defaultSubjectId = await getFirstEvaluatedSubject(selectedClass.id, term);
  const selectedSubject =
    subjectRows.find((s) => String(s.id) === params.subjectId) ??
    subjectRows.find((s) => s.id === defaultSubjectId) ??
    subjectRows[0] ??
    null;

  const matrix = selectedSubject ? await getGradeMatrix(selectedClass.id, selectedSubject.id, term) : null;

  return (
    <>
      <PageHeader
        eyebrow="Pédagogie"
        title="Notes & évaluations"
        subtitle="Saisissez les notes d'un devoir ou d'une composition : les moyennes, rangs et bulletins se calculent automatiquement."
        actions={
          <Link href={`/bulletins?classId=${selectedClass.id}&term=${encodeURIComponent(term)}`} className="btn-outline">
            <FileText className="h-4 w-4" /> Voir les bulletins
          </Link>
        }
      />

      {params.enregistre === "notes" ? (
        <div className="mb-4"><Notice>Les notes ont été enregistrées et les moyennes recalculées.</Notice></div>
      ) : null}
      {params.enregistre === "evaluation" ? (
        <div className="mb-4"><Notice>Nouvelle évaluation créée. Vous pouvez saisir les notes.</Notice></div>
      ) : null}
      {params.erreur ? (
        <div className="mb-4"><Notice tone="danger">{params.erreur}</Notice></div>
      ) : null}

      <div className="card mb-4 p-4">
        <form className="grid gap-3 sm:grid-cols-4 sm:items-end">
          <div>
            <label className="label" htmlFor="classId">Classe</label>
            <select id="classId" name="classId" className="input" defaultValue={String(selectedClass.id)}>
              {classRows.map((cls) => (
                <option key={cls.id} value={cls.id}>{cls.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="subjectId">Matière</label>
            <select id="subjectId" name="subjectId" className="input" defaultValue={String(selectedSubject?.id ?? "")}>
              {subjectRows.map((subject) => (
                <option key={subject.id} value={subject.id}>
                  {subject.name} (coef. {subject.coefficient})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="term">Période</label>
            <select id="term" name="term" className="input" defaultValue={term}>
              {TERMS.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
          <button type="submit" className="btn-primary">
            <ClipboardList className="h-4 w-4" /> Afficher
          </button>
        </form>
      </div>

      {matrix ? (
        <>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard label="Moyenne de la matière" value={`${gradeLabel(matrix.stats.average)}/20`} hint={`${matrix.students.length} élèves · ${term}`} icon={TrendingUp} />
            <StatCard label="Meilleure moyenne" value={`${gradeLabel(matrix.stats.best)}/20`} hint="Meilleure note pondérée" icon={ClipboardList} tone="sky" />
            <StatCard label="Élèves en difficulté" value={matrix.stats.below10} hint="Moyenne inférieure à 10/20" icon={TriangleAlert} tone="danger" />
            <StatCard label="Notes saisies" value={`${matrix.stats.filled}/${matrix.students.length * matrix.assessments.length}`} hint={`${matrix.assessments.length} évaluation(s)`} icon={FileText} tone="amber" />
          </div>

          <div className="mt-4 grid gap-4 xl:grid-cols-[1.7fr_1fr]">
            <SectionCard
              title={`${selectedSubject?.name ?? "Matière"} — ${selectedClass.name}`}
              description={`${term} · coefficient matière ${selectedSubject?.coefficient ?? 1} · ${selectedSubject?.teacher || "enseignant non défini"}`}
              action={<Badge tone="brand">{matrix.assessments.length} évaluation(s)</Badge>}
            >
              {matrix.assessments.length === 0 ? (
                <EmptyState
                  icon={ClipboardList}
                  title="Aucune évaluation pour cette matière"
                  description="Créez une évaluation dans le panneau de droite pour commencer à saisir des notes."
                />
              ) : (
                <form action={saveGrades}>
                  <input type="hidden" name="classId" value={selectedClass.id} />
                  <input type="hidden" name="subjectId" value={selectedSubject?.id ?? ""} />
                  <input type="hidden" name="term" value={term} />
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[560px] border-collapse">
                      <thead className="bg-sand/60">
                        <tr>
                          <th className="th">Élève</th>
                          {matrix.assessments.map((assessment) => (
                            <th key={assessment.id} className="th text-center">
                              <span className="block">{assessment.title}</span>
                              <span className="block text-[10px] font-medium normal-case tracking-normal text-ink/35">
                                coef. {assessment.coefficient} · /{assessment.maxScore}
                              </span>
                            </th>
                          ))}
                          <th className="th text-center">Moyenne</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-ink/6">
                        {matrix.students.map((student) => (
                          <tr key={student.id} className="row-hover">
                            <td className="td">
                              <div className="flex items-center gap-2.5">
                                <Avatar first={student.firstName} last={student.lastName} size="sm" />
                                <div>
                                  <p className="text-sm font-medium text-ink">{student.lastName} {student.firstName}</p>
                                  <p className="text-[11px] text-ink/45">{student.matricule}</p>
                                </div>
                              </div>
                            </td>
                            {matrix.assessments.map((assessment) => (
                              <td key={assessment.id} className="td text-center">
                                <input
                                  name={`score_${assessment.id}_${student.id}`}
                                  type="number"
                                  min={0}
                                  max={20}
                                  step={0.25}
                                  defaultValue={student.scores[assessment.id] ?? ""}
                                  placeholder="—"
                                  aria-label={`${assessment.title} — ${student.lastName}`}
                                  className="input w-20 py-1.5 text-center"
                                />
                              </td>
                            ))}
                            <td className="td text-center">
                              <span className={`font-bold ${(student.average ?? 0) >= 10 ? "text-brand-700" : "text-red-600"}`}>
                                {gradeLabel(student.average)}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-ink/8 pt-4">
                    <SubmitButton className="btn-primary" pendingLabel="Enregistrement des notes…">
                      <Save className="h-4 w-4" /> Enregistrer les notes
                    </SubmitButton>
                    <p className="text-[11px] text-ink/45">
                      Notes sur 20 · laissez vide pour effacer une note. Moyennes pondérées par le coefficient de
                      chaque évaluation.
                    </p>
                  </div>
                </form>
              )}
            </SectionCard>

            <div className="space-y-4">
              <SectionCard title="Créer une évaluation" description="Devoir, composition ou interrogation">
                <form action={createAssessment} className="space-y-3">
                  <input type="hidden" name="classId" value={selectedClass.id} />
                  <input type="hidden" name="subjectId" value={selectedSubject?.id ?? ""} />
                  <input type="hidden" name="term" value={term} />
                  <div>
                    <label className="label" htmlFor="title">Intitulé</label>
                    <input id="title" name="title" className="input" placeholder="Composition du 1er trimestre" required />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="label" htmlFor="date">Date</label>
                      <input id="date" name="date" type="date" defaultValue={todayISO()} className="input" />
                    </div>
                    <div>
                      <label className="label" htmlFor="coefficient">Coefficient</label>
                      <input id="coefficient" name="coefficient" type="number" min={1} max={5} defaultValue={1} className="input" />
                    </div>
                  </div>
                  <div>
                    <label className="label" htmlFor="maxScore">Barème</label>
                    <select id="maxScore" name="maxScore" className="input" defaultValue={20}>
                      <option value={20}>Notes sur 20</option>
                      <option value={10}>Notes sur 10</option>
                    </select>
                  </div>
                  <SubmitButton className="btn-soft w-full" pendingLabel="Création…">
                    <Plus className="h-4 w-4" /> Créer l&apos;évaluation
                  </SubmitButton>
                </form>
              </SectionCard>

              <SectionCard title="Évaluations de la période" description={`${selectedClass.name} · ${selectedSubject?.name ?? ""}`}>
                {matrix.assessments.length === 0 ? (
                  <p className="text-sm text-ink/50">Aucune évaluation enregistrée.</p>
                ) : (
                  <ul className="space-y-2">
                    {matrix.assessments.map((assessment) => (
                      <li key={assessment.id} className="flex items-center justify-between gap-2 rounded-lg border border-ink/8 px-3 py-2">
                        <div>
                          <p className="text-sm font-semibold text-ink">{assessment.title}</p>
                          <p className="text-[11px] text-ink/45">
                            <CalendarDays className="mr-1 inline h-3 w-3" />
                            {formatDate(assessment.date)} · coef. {assessment.coefficient} · /{assessment.maxScore}
                          </p>
                        </div>
                        <Badge tone="neutral">{term.replace("Trimestre ", "T")}</Badge>
                      </li>
                    ))}
                  </ul>
                )}
              </SectionCard>

              <SectionCard title="Barème de l'établissement">
                <p className="text-sm leading-relaxed text-ink/60">
                  Les moyennes par matière sont pondérées par le coefficient de chaque évaluation, puis la moyenne
                  générale par le coefficient de la matière. Le rang est calculé automatiquement à chaque
                  enregistrement.
                </p>
                <Link
                  href={`/bulletins?classId=${selectedClass.id}&term=${encodeURIComponent(term)}`}
                  className="btn-outline mt-3 w-full justify-center"
                >
                  <FileText className="h-4 w-4" /> Générer les bulletins
                </Link>
              </SectionCard>
            </div>
          </div>
        </>
      ) : (
        <EmptyState icon={ClipboardList} title="Aucune matière paramétrée" description="Ajoutez des matières dans les paramètres de l'établissement." />
      )}
    </>
  );
}
