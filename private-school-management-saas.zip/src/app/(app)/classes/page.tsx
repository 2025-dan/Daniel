import Link from "next/link";
import { CalendarCheck, ClipboardList, GraduationCap, MapPin, Plus, Users } from "lucide-react";
import { Badge, EmptyState, PageHeader, ProgressBar, SectionCard, StatCard } from "@/components/ui";
import { SubmitButton } from "@/components/forms";
import { Restricted } from "@/components/restricted";
import { createClass } from "@/lib/actions";
import { getClassSummaries } from "@/lib/data/context";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import { CYCLES, LEVELS, money, percent } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<{ classe?: string; erreur?: string }> };

export default async function ClassesPage({ searchParams }: Props) {
  const [role, params, classRows] = await Promise.all([getRole(), searchParams, getClassSummaries()]);
  if (!can(role, "classes")) return <Restricted role={role} module="Classes" />;

  const totalPupils = classRows.reduce((sum, c) => sum + c.studentCount, 0);
  const totalSeats = classRows.reduce((sum, c) => sum + c.capacity, 0);
  const averageAttendance = classRows.length
    ? Math.round(classRows.reduce((sum, c) => sum + c.attendanceRate, 0) / classRows.length)
    : 0;

  return (
    <>
      <PageHeader
        eyebrow="Scolarité"
        title="Classes & effectifs"
        subtitle="Organisation pédagogique de l'établissement : niveaux, titulaires, capacités et assiduité."
        actions={
          <Link href="/eleves/nouveau" className="btn-primary">
            <Plus className="h-4 w-4" /> Inscrire un élève
          </Link>
        }
      />

      {params.classe ? (
        <div className="mb-4 rounded-xl border border-brand-200 bg-brand-50 px-3.5 py-2.5 text-sm text-brand-800">
          La classe a été créée avec succès.
        </div>
      ) : null}
      {params.erreur ? (
        <div className="mb-4 rounded-xl border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-700">{params.erreur}</div>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Classes ouvertes" value={classRows.length} hint={`${CYCLES.join(" · ")}`} icon={GraduationCap} />
        <StatCard label="Élèves affectés" value={totalPupils} hint={`${totalSeats - totalPupils} places disponibles`} icon={Users} tone="sky" />
        <StatCard
          label="Taux de remplissage"
          value={`${percent(totalPupils, Math.max(1, totalSeats))}%`}
          hint={`${totalPupils}/${totalSeats} places`}
          icon={Users}
          tone="amber"
          footer={<ProgressBar value={percent(totalPupils, Math.max(1, totalSeats))} tone="amber" />}
        />
        <StatCard label="Assiduité moyenne" value={`${averageAttendance}%`} hint="Sur les 30 derniers jours" icon={CalendarCheck} tone="brand" />
      </div>

      {classRows.length === 0 ? (
        <div className="mt-4">
          <EmptyState icon={GraduationCap} title="Aucune classe" description="Créez votre première classe pour commencer à inscrire des élèves." />
        </div>
      ) : (
        <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {classRows.map((cls) => (
            <div key={cls.id} className="card flex flex-col p-5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-brand-600">{cls.cycle}</p>
                  <h2 className="font-display text-lg font-semibold text-ink">{cls.name}</h2>
                  <p className="text-[11px] text-ink/45">
                    {cls.mainTeacher || "Titulaire non défini"} {cls.room ? `· ${cls.room}` : ""}
                  </p>
                </div>
                <Badge tone={cls.studentCount >= cls.capacity ? "danger" : "brand"}>
                  {cls.studentCount}/{cls.capacity}
                </Badge>
              </div>

              <div className="mt-4 space-y-2">
                <div className="flex items-center justify-between text-[11px] font-semibold text-ink/50">
                  <span>Remplissage</span>
                  <span>{percent(cls.studentCount, cls.capacity)}%</span>
                </div>
                <ProgressBar
                  value={percent(cls.studentCount, cls.capacity)}
                  tone={cls.studentCount >= cls.capacity ? "danger" : "brand"}
                />
                <div className="flex items-center justify-between text-[11px] font-semibold text-ink/50">
                  <span>Assiduité 30 j</span>
                  <span>{cls.attendanceRate}%</span>
                </div>
                <ProgressBar value={cls.attendanceRate} tone={cls.attendanceRate >= 90 ? "brand" : "amber"} />
              </div>

              <div className="mt-4 flex items-center justify-between rounded-xl bg-sand px-3 py-2 text-xs">
                <span className="text-ink/50">Scolarité mensuelle</span>
                <span className="font-bold text-ink">{money(cls.monthlyFee)}</span>
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                <Link href={`/classes/${cls.id}`} className="btn-primary btn-sm flex-1 justify-center">
                  Ouvrir la classe
                </Link>
                <Link href={`/presences?classId=${cls.id}`} className="btn-outline btn-sm">
                  <CalendarCheck className="h-3.5 w-3.5" />
                </Link>
                <Link href={`/notes?classId=${cls.id}`} className="btn-outline btn-sm">
                  <ClipboardList className="h-3.5 w-3.5" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}

      {role === "directeur" ? (
        <div className="mt-4">
          <SectionCard title="Créer une classe" description="La classe sera immédiatement ouverte pour l'année en cours">
            <details>
              <summary className="btn-soft inline-flex cursor-pointer list-none">
                <Plus className="h-4 w-4" /> Nouvelle classe
              </summary>
              <form action={createClass} className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                <div>
                  <label className="label" htmlFor="name">Nom de la classe *</label>
                  <input id="name" name="name" required className="input" placeholder="CM1 B" />
                </div>
                <div>
                  <label className="label" htmlFor="level">Niveau</label>
                  <select id="level" name="level" className="input" defaultValue="1ère Primaire">
                    {LEVELS.map((level) => (
                      <option key={level} value={level}>{level}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label" htmlFor="cycle">Cycle</label>
                  <select id="cycle" name="cycle" className="input" defaultValue="Primaire">
                    {CYCLES.map((cycle) => (
                      <option key={cycle} value={cycle}>{cycle}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label" htmlFor="capacity">Capacité</label>
                  <input id="capacity" name="capacity" type="number" min={1} defaultValue={40} className="input" />
                </div>
                <div>
                  <label className="label" htmlFor="room">Salle</label>
                  <input id="room" name="room" className="input" placeholder="Bât. B1" />
                </div>
                <div>
                  <label className="label" htmlFor="mainTeacher">Enseignant titulaire</label>
                  <input id="mainTeacher" name="mainTeacher" className="input" placeholder="Mme Traoré Fatou" />
                </div>
                <div>
                  <label className="label" htmlFor="monthlyFee">Mensualité (FC)</label>
                  <input id="monthlyFee" name="monthlyFee" type="number" min={0} step={500} defaultValue={50000} className="input" />
                </div>
                <div className="sm:col-span-2 xl:col-span-3">
                  <SubmitButton className="btn-primary">
                    <Plus className="h-4 w-4" /> Créer la classe
                  </SubmitButton>
                </div>
              </form>
            </details>
            <p className="mt-3 flex items-center gap-1.5 text-[11px] text-ink/45">
              <MapPin className="h-3.5 w-3.5" /> Les frais annuels sont calculés sur 9 mensualités lors de l&apos;inscription.
            </p>
          </SectionCard>
        </div>
      ) : null}
    </>
  );
}
