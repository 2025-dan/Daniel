import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, CalendarCheck, ClipboardList, FileText, Users, Wallet } from "lucide-react";
import { Avatar, Badge, InfoRow, PageHeader, ProgressBar, SectionCard, StatCard } from "@/components/ui";
import { Restricted } from "@/components/restricted";
import { getClassById, getClassSummaries } from "@/lib/data/context";
import { computeClassResults, getPupilsOfClass, getSubjects } from "@/lib/data/academics";
import { getStudents } from "@/lib/data/students";
import { DAYS, getClassHomework, getClassTimetable } from "@/lib/data/school-life";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import { formatDate, gradeLabel, money, percent } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ id: string }> };

export default async function ClassDetailPage({ params }: Props) {
  const [role, { id }] = await Promise.all([getRole(), params]);
  if (!can(role, "classes")) return <Restricted role={role} module="Classes" />;

  const classId = Number(id);
  if (!Number.isFinite(classId)) notFound();
  const classRow = await getClassById(classId);
  if (!classRow) notFound();

  const [pupils, results, financeRows, summaries, subjectRows, timetable, homework] = await Promise.all([
    getPupilsOfClass(classId),
    computeClassResults(classId, "Trimestre 1"),
    getStudents({ classId: String(classId) }),
    getClassSummaries(),
    getSubjects(),
    getClassTimetable(classId),
    getClassHomework(classId, 3),
  ]);
  const summary = summaries.find((c) => c.id === classId);
  const invoiced = financeRows.reduce((s, r) => s + r.invoiced, 0);
  const paid = financeRows.reduce((s, r) => s + r.paid, 0);

  return (
    <>
      <Link href="/classes" className="mb-4 inline-flex items-center gap-1.5 text-xs font-semibold text-ink/50 hover:text-ink">
        <ArrowLeft className="h-3.5 w-3.5" /> Toutes les classes
      </Link>

      <PageHeader
        eyebrow={`${classRow.cycle} · ${classRow.level}`}
        title={classRow.name}
        subtitle={`${classRow.mainTeacher || "Titulaire non défini"}${classRow.room ? ` · salle ${classRow.room}` : ""} · ${money(classRow.monthlyFee)} / mois`}
        actions={
          <>
            <Link href={`/presences?classId=${classId}`} className="btn-outline">
              <CalendarCheck className="h-4 w-4" /> Faire l&apos;appel
            </Link>
            {can(role, "grades") ? (
              <Link href={`/notes?classId=${classId}`} className="btn-primary">
                <ClipboardList className="h-4 w-4" /> Saisir des notes
              </Link>
            ) : null}
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Effectif"
          value={`${summary?.studentCount ?? pupils.length}/${classRow.capacity}`}
          hint={`${percent(pupils.length, classRow.capacity)}% de remplissage`}
          icon={Users}
          footer={<ProgressBar value={percent(pupils.length, classRow.capacity)} />}
        />
        <StatCard label="Moyenne de classe" value={`${gradeLabel(results.classAverage)}/20`} hint="Trimestre 1 · notes pondérées" icon={FileText} tone="sky" />
        <StatCard label="Taux de réussite" value={`${results.successRate}%`} hint="Élèves avec moyenne ≥ 10" icon={ClipboardList} tone="amber" />
        <StatCard
          label="Recouvrement"
          value={`${percent(paid, Math.max(1, invoiced))}%`}
          hint={`${money(paid)} sur ${money(invoiced)}`}
          icon={Wallet}
          tone="brand"
          footer={<ProgressBar value={percent(paid, Math.max(1, invoiced))} tone={paid >= invoiced ? "brand" : "amber"} />}
        />
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-[1.6fr_1fr]">
        <SectionCard
          title="Élèves de la classe"
          description="Classement provisoire du trimestre 1"
          action={<Badge tone="brand">{pupils.length} élèves</Badge>}
          bodyClassName="overflow-x-auto"
        >
          <table className="w-full min-w-[560px] border-collapse">
            <thead className="bg-sand/60">
              <tr>
                <th className="th">Rang</th>
                <th className="th">Élève</th>
                <th className="th">Moyenne</th>
                <th className="th">Statut</th>
                <th className="th text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/6">
              {results.students.map((student) => (
                <tr key={student.id} className="row-hover">
                  <td className="td font-semibold text-ink/50">{student.rank ?? "—"}</td>
                  <td className="td">
                    <div className="flex items-center gap-2.5">
                      <Avatar first={student.firstName} last={student.lastName} size="sm" />
                      <div>
                        <Link href={`/eleves/${student.id}`} className="font-semibold text-ink hover:underline">
                          {student.lastName} {student.firstName}
                        </Link>
                        <p className="text-[11px] text-ink/45">{student.matricule}</p>
                      </div>
                    </div>
                  </td>
                  <td className="td">
                    <span className={`font-bold ${(student.average ?? 0) >= 10 ? "text-brand-700" : "text-red-600"}`}>
                      {gradeLabel(student.average)}
                    </span>
                  </td>
                  <td className="td">
                    <Badge tone={(student.average ?? 0) >= 10 ? "success" : "danger"}>
                      {(student.average ?? 0) >= 10 ? "Admis" : "À soutenir"}
                    </Badge>
                  </td>
                  <td className="td text-right">
                    <Link href={`/bulletins/${student.id}?term=Trimestre%201`} className="btn-ghost btn-sm">
                      Bulletin
                    </Link>
                  </td>
                </tr>
              ))}
              {results.students.length === 0
                ? pupils.map((pupil) => (
                    <tr key={pupil.id} className="row-hover">
                      <td className="td text-ink/40">—</td>
                      <td className="td">
                        <Link href={`/eleves/${pupil.id}`} className="font-semibold text-ink hover:underline">
                          {pupil.lastName} {pupil.firstName}
                        </Link>
                      </td>
                      <td className="td text-ink/40">Non évalué</td>
                      <td className="td"><Badge>En attente</Badge></td>
                      <td className="td text-right">
                        <Link href={`/eleves/${pupil.id}`} className="btn-ghost btn-sm">Dossier</Link>
                      </td>
                    </tr>
                  ))
                : null}
            </tbody>
          </table>
        </SectionCard>

        <div className="space-y-4">
          <SectionCard title="Informations" description="Données de la classe">
            <InfoRow label="Cycle" value={classRow.cycle} />
            <InfoRow label="Niveau" value={classRow.level} />
            <InfoRow label="Salle" value={classRow.room || "—"} />
            <InfoRow label="Titulaire" value={classRow.mainTeacher || "—"} />
            <InfoRow label="Capacité" value={`${classRow.capacity} places`} />
            <InfoRow label="Mensualité" value={money(classRow.monthlyFee)} />
            <InfoRow label="Assiduité 30 j" value={`${summary?.attendanceRate ?? 0}%`} />
          </SectionCard>

          <SectionCard title="Matières & coefficients" description={`${subjectRows.length} matières paramétrées`}>
            <div className="space-y-1.5">
              {results.subjects.map((subject) => (
                <div key={subject.id} className="flex items-center justify-between gap-2 rounded-lg px-2 py-1.5 hover:bg-sand/60">
                  <div>
                    <p className="text-sm font-medium text-ink/80">{subject.name}</p>
                    <p className="text-[10px] text-ink/40">{subject.teacher || "Enseignant non défini"}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge tone="neutral">Coef. {subject.coefficient}</Badge>
                    <span className="text-xs font-bold text-ink/60">{gradeLabel(subject.classAverage)}</span>
                  </div>
                </div>
              ))}
              {results.subjects.length === 0 ? (
                <p className="text-sm text-ink/50">Aucune évaluation dans cette classe pour le moment.</p>
              ) : null}
            </div>
          </SectionCard>

          <SectionCard title="Emploi du temps" description="Planning hebdomadaire publié aux familles">
            {timetable.length === 0 ? (
              <p className="text-sm text-ink/50">Aucun créneau planifié.</p>
            ) : (
              <div className="space-y-2">
                {DAYS.map((day) => {
                  const slots = timetable.filter((slot) => slot.day === day.value);
                  if (slots.length === 0) return null;
                  return (
                    <div key={day.value}>
                      <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">{day.label}</p>
                      <div className="mt-0.5 space-y-0.5">
                        {slots.map((slot) => (
                          <div key={slot.id} className="flex items-center gap-2 text-[11px]">
                            <span className="w-24 shrink-0 font-semibold text-ink/45">{slot.startTime}–{slot.endTime}</span>
                            <span className="min-w-0 flex-1 truncate text-ink/70">{slot.subjectName ?? "Créneau libre"}</span>
                            <span className="text-ink/35">{slot.room}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
            <Link href={`/emploi-du-temps?classId=${classId}`} className="btn-outline btn-sm mt-3 w-full justify-center">
              Modifier le planning
            </Link>
          </SectionCard>

          <SectionCard title="Derniers devoirs" description="Extraits du cahier de textes">
            {homework.length === 0 ? (
              <p className="text-sm text-ink/50">Aucun devoir enregistré.</p>
            ) : (
              <ul className="space-y-2">
                {homework.map((item) => (
                  <li key={item.id} className="rounded-lg bg-sand/70 px-3 py-2">
                    <p className="text-xs font-semibold text-ink">{item.title}</p>
                    <p className="mt-0.5 text-[11px] text-ink/55">{item.homework}</p>
                    {item.dueDate ? <p className="mt-0.5 text-[10px] font-semibold text-amber-700">À rendre le {formatDate(item.dueDate)}</p> : null}
                  </li>
                ))}
              </ul>
            )}
            <Link href={`/cahier-de-textes?classId=${classId}`} className="btn-outline btn-sm mt-3 w-full justify-center">
              Cahier de textes
            </Link>
          </SectionCard>
        </div>
      </div>
    </>
  );
}
