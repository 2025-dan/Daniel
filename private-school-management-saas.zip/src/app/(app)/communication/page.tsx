import Link from "next/link";
import { BellRing, MessageSquare, Send, Smartphone, Sparkles, Users } from "lucide-react";
import { Avatar, Badge, Notice, PageHeader, SectionCard, StatCard } from "@/components/ui";
import { SubmitButton } from "@/components/forms";
import { Restricted } from "@/components/restricted";
import { sendMessage, sendReminder } from "@/lib/actions";
import { getMessagesPageData } from "@/lib/data/messages";
import { requireContext } from "@/lib/data/context";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import { CHANNEL_LABEL, formatDateTime, money, relativeTime } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = {
  searchParams: Promise<{ envoye?: string; brouillon?: string; modele?: string; eleve?: string }>;
};

const TEMPLATES: Record<string, { title: string; subject: string; body: string }> = {
  reunion: {
    title: "Réunion de parents",
    subject: "Réunion de parents d'élèves",
    body: "Chers parents, nous avons le plaisir de vous convier à la réunion de parents qui se tiendra samedi à 9h00 dans la cour de l'établissement. Votre présence est vivement souhaitée.",
  },
  relance: {
    title: "Relance scolarité",
    subject: "Rappel de scolarité",
    body: "Chers parents, nous vous rappelons que le solde de scolarité de votre enfant reste à régler. Merci de vous rapprocher de la comptabilité pour régulariser votre situation.",
  },
  info: {
    title: "Information générale",
    subject: "Information de l'établissement",
    body: "Chers parents, nous portons à votre attention l'information suivante : ",
  },
};

export default async function CommunicationPage({ searchParams }: Props) {
  const [role, params] = await Promise.all([getRole(), searchParams]);
  if (!can(role, "messages")) return <Restricted role={role} module="Communication parents" />;

  const [data, ctx] = await Promise.all([getMessagesPageData(), requireContext()]);
  const template = params.modele ? TEMPLATES[params.modele] : undefined;
  const preselectedPupil = params.eleve ? data.pupils.find((p) => String(p.id) === params.eleve) : undefined;

  return (
    <>
      <PageHeader
        eyebrow="Communication"
        title="Messages aux parents"
        subtitle="Un canal unique pour les annonces, les réunions et les relances de scolarité. Chaque envoi est journalisé."
        actions={
          <Badge tone="brand">
            <Smartphone className="h-3.5 w-3.5" /> SMS · E-mail · Notifications
          </Badge>
        }
      />

      {params.envoye ? (
        <div className="mb-4"><Notice>Message diffusé aux destinataires et enregistré dans l&apos;historique.</Notice></div>
      ) : null}
      {params.brouillon ? (
        <div className="mb-4"><Notice tone="info">Message enregistré comme brouillon. Il n&apos;a pas encore été envoyé.</Notice></div>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Messages envoyés" value={data.stats.sent} hint="Depuis le début de l'année" icon={MessageSquare} />
        <StatCard label="Familles touchées" value={data.stats.recipients} hint="Cumul des destinataires" icon={Users} tone="sky" />
        <StatCard label="Brouillons" value={data.stats.drafts} hint="À finaliser et envoyer" icon={Sparkles} tone="amber" />
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-[1.35fr_1fr]">
        <SectionCard
          title="Historique des communications"
          description={`${data.messages.length} message(s) récents`}
          bodyClassName="divide-y divide-ink/6"
        >
          {data.messages.length === 0 ? (
            <p className="px-5 py-8 text-center text-sm text-ink/50">Aucun message envoyé pour le moment.</p>
          ) : (
            data.messages.map((message) => (
              <details key={message.id} className="group px-5 py-3.5">
                <summary className="cursor-pointer list-none">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-ink">{message.subject}</p>
                      <p className="mt-0.5 text-[11px] text-ink/45">
                        {message.recipientLabel} · {CHANNEL_LABEL[message.channel] ?? message.channel} ·{" "}
                        {formatDateTime(message.sentAt)}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge tone={message.status === "brouillon" ? "warning" : "success"}>
                        {message.status === "brouillon" ? "Brouillon" : `${message.recipientsCount} destinataire(s)`}
                      </Badge>
                    </div>
                  </div>
                  <p className="mt-1.5 line-clamp-2 text-xs text-ink/55">{message.body}</p>
                </summary>
                <div className="mt-3 rounded-xl bg-sand p-3 text-sm leading-relaxed text-ink/70">{message.body}</div>
              </details>
            ))
          )}
        </SectionCard>

        <div className="space-y-4">
          <SectionCard title="Nouveau message" description={`Diffusion depuis ${ctx.school.shortName}`}>
            <form action={sendMessage} className="space-y-3">
              <div>
                <label className="label" htmlFor="audience">Audience</label>
                <select id="audience" name="audience" className="input" defaultValue={preselectedPupil ? "parent" : "tous"}>
                  <option value="tous">Tous les parents ({data.pupils.length} familles)</option>
                  <option value="classe">Une classe</option>
                  <option value="parent">Un parent en particulier</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label" htmlFor="classId">Classe (si audience classe)</label>
                  <select id="classId" name="classId" className="input" defaultValue="">
                    <option value="">—</option>
                    {data.classes.map((cls) => (
                      <option key={cls.id} value={cls.id}>{cls.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label" htmlFor="studentId">Élève (si parent)</label>
                  <select id="studentId" name="studentId" className="input" defaultValue={preselectedPupil ? String(preselectedPupil.id) : ""}>
                    <option value="">—</option>
                    {data.pupils.map((pupil) => (
                      <option key={pupil.id} value={pupil.id}>
                        {pupil.lastName} {pupil.firstName}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="label" htmlFor="channel">Canal</label>
                <select id="channel" name="channel" className="input" defaultValue="sms">
                  <option value="sms">SMS</option>
                  <option value="email">E-mail</option>
                  <option value="app">Notification application</option>
                </select>
              </div>
              <div>
                <label className="label" htmlFor="subject">Objet</label>
                <input id="subject" name="subject" className="input" defaultValue={template?.subject ?? ""} required />
              </div>
              <div>
                <label className="label" htmlFor="body">Message</label>
                <textarea
                  id="body"
                  name="body"
                  rows={5}
                  className="input"
                  defaultValue={template?.body ?? ""}
                  placeholder="Rédigez votre message aux familles…"
                  required
                />
              </div>
              <div className="flex flex-col gap-2 sm:flex-row">
                <SubmitButton className="btn-primary flex-1" pendingLabel="Envoi aux familles…">
                  <Send className="h-4 w-4" /> Envoyer
                </SubmitButton>
                <SubmitButton className="btn-outline" name="intent" value="brouillon" pendingLabel="Enregistrement…">
                  Brouillon
                </SubmitButton>
              </div>
            </form>
          </SectionCard>

          <SectionCard title="Modèles de messages" description="Pré-remplissez le formulaire en un clic">
            <div className="space-y-2">
              {Object.entries(TEMPLATES).map(([key, value]) => (
                <Link
                  key={key}
                  href={`/communication?modele=${key}`}
                  className="flex items-center justify-between gap-2 rounded-xl border border-ink/8 px-3 py-2.5 transition hover:border-brand-200 hover:bg-brand-50/50"
                >
                  <div>
                    <p className="text-sm font-semibold text-ink">{value.title}</p>
                    <p className="text-[11px] text-ink/45">{value.subject}</p>
                  </div>
                  <Sparkles className="h-4 w-4 text-brand-500" />
                </Link>
              ))}
            </div>
          </SectionCard>

          <SectionCard title="Relances récentes" description="Envoyées depuis le module finances" bodyClassName="divide-y divide-ink/6">
            {data.reminders.length === 0 ? (
              <p className="px-5 py-6 text-sm text-ink/50">Aucune relance envoyée.</p>
            ) : (
              data.reminders.map((reminder) => (
                <div key={reminder.id} className="flex items-center justify-between gap-2 px-5 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-ink">
                      {reminder.firstName} {reminder.lastName}
                    </p>
                    <p className="text-[11px] text-ink/45">
                      {reminder.number} · reste {money(reminder.amount - reminder.amountPaid)} ·{" "}
                      {relativeTime(reminder.sentAt)}
                    </p>
                  </div>
                  <Badge tone="warning">{CHANNEL_LABEL[reminder.channel] ?? reminder.channel}</Badge>
                </div>
              ))
            )}
            {can(role, "messages") && data.reminders[0]?.invoiceId ? (
              <div className="flex items-center justify-between gap-2 px-5 py-3">
                <p className="text-[11px] text-ink/50">Relancer une famille depuis son dossier :</p>
                <form action={sendReminder}>
                  <input type="hidden" name="invoiceId" value={data.reminders[0]?.invoiceId ?? ""} />
                  <input type="hidden" name="redirectTo" value="/communication" />
                  <SubmitButton className="btn-outline btn-sm" pendingLabel="Envoi…">
                    <BellRing className="h-3.5 w-3.5" /> Rappel
                  </SubmitButton>
                </form>
              </div>
            ) : null}
          </SectionCard>
        </div>
      </div>
    </>
  );
}
