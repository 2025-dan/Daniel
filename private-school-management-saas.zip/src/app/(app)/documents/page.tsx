import Link from "next/link";
import {
  CheckCircle2,
  Download,
  Eye,
  FileText,
  FolderOpen,
  ScanLine,
  Search,
  Share2,
  ShieldCheck,
  Trash2,
  XCircle,
} from "lucide-react";
import { Badge, EmptyState, Notice, PageHeader, SectionCard, StatCard } from "@/components/ui";
import { SubmitButton } from "@/components/forms";
import { DocumentUploader } from "@/components/document-uploader";
import { Restricted } from "@/components/restricted";
import { deleteDocument, updateDocument, uploadDocument } from "@/lib/actions";
import { formatFileSize, getDocumentsPageData } from "@/lib/data/documents";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import {
  DOCUMENT_CATEGORIES,
  DOCUMENT_STATUS_LABEL,
  TERMS,
  formatDate,
  formatDateTime,
  gradeLabel,
} from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = {
  searchParams: Promise<{ q?: string; categorie?: string; statut?: string; eleve?: string; importe?: string; erreur?: string }>;
};

function statusTone(status: string): "success" | "warning" | "danger" {
  if (status === "validé") return "success";
  if (status === "rejeté") return "danger";
  return "warning";
}

export default async function DocumentsPage({ searchParams }: Props) {
  const [role, params] = await Promise.all([getRole(), searchParams]);
  if (!can(role, "documents")) return <Restricted role={role} module="Documents & scans" />;

  const data = await getDocumentsPageData({
    q: params.q,
    category: params.categorie,
    status: params.statut,
    studentId: params.eleve,
  });
  const redirectTo = `/documents${params.eleve ? `?eleve=${params.eleve}` : ""}`;

  return (
    <>
      <PageHeader
        eyebrow="Scolarité"
        title="Documents & bulletins scannés"
        subtitle="Importez les pièces des dossiers, scannez les bulletins papier et partagez-les avec les parents."
        actions={
          <>
            <Link href={`/documents/scan${params.eleve ? `?eleve=${params.eleve}` : ""}`} className="btn-primary">
              <ScanLine className="h-4 w-4" /> Scanner un bulletin
            </Link>
            <Link href="/eleves" className="btn-outline">
              <FolderOpen className="h-4 w-4" /> Dossiers élèves
            </Link>
          </>
        }
      />

      {params.importe ? (
        <div className="mb-4"><Notice>Document importé. Il est désormais disponible dans le dossier et le portail parents si vous l&apos;avez partagé.</Notice></div>
      ) : null}
      {params.erreur ? <div className="mb-4"><Notice tone="danger">{params.erreur}</Notice></div> : null}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Documents archivés" value={data.stats.total} hint={`${formatFileSize(data.stats.bytes)} stockés`} icon={FolderOpen} />
        <StatCard label="Bulletins scannés" value={data.stats.bulletins} hint="Numérisations de bulletins papier" icon={ScanLine} tone="sky" />
        <StatCard label="À vérifier" value={data.stats.pending} hint="Scans en attente de validation" icon={ShieldCheck} tone="amber" />
        <StatCard label="Partagés aux parents" value={data.stats.shared} hint="Visibles dans le portail famille" icon={Share2} tone="brand" />
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-[1.45fr_1fr]">
        <SectionCard
          title="Importer un document"
          description="Drag & drop, fichier ou photo prise avec la caméra"
        >
          <DocumentUploader
            action={uploadDocument}
            redirectTo={redirectTo}
            students={data.students}
            categories={[...DOCUMENT_CATEGORIES]}
            terms={TERMS}
            defaultStudentId={params.eleve}
          />
        </SectionCard>

        <div className="space-y-4">
          <SectionCard title="Chaîne de traitement" description="Du papier au dossier numérique">
            <ol className="space-y-3">
              {[
                { title: "1. Numériser", text: "Photo du bulletin ou import du PDF fourni par l'école." },
                { title: "2. Vérifier", text: "Contrôlez l'élève, le trimestre, la moyenne et la décision lus." },
                { title: "3. Valider", text: "La direction valide le document : il devient une pièce officielle." },
                { title: "4. Partager", text: "Le parent consulte le document depuis son portail, sans passage au secrétariat." },
              ].map((step) => (
                <li key={step.title} className="rounded-xl border border-ink/8 bg-sand/40 px-3 py-2.5">
                  <p className="text-xs font-bold text-ink">{step.title}</p>
                  <p className="mt-0.5 text-[11px] leading-snug text-ink/55">{step.text}</p>
                </li>
              ))}
            </ol>
            <Link href="/documents/scan" className="btn-soft mt-3 w-full justify-center">
              <ScanLine className="h-4 w-4" /> Ouvrir le scanner de bulletins
            </Link>
          </SectionCard>

          <SectionCard title="Bonnes pratiques de scan">
            <ul className="space-y-2 text-[11px] leading-relaxed text-ink/60">
              <li>• Posez le bulletin à plat, sur un fond sombre pour le contraste.</li>
              <li>• Cadrez uniquement la page, sans ombre portée du téléphone.</li>
              <li>• Vérifiez la lisibilité des notes avant de valider le scan.</li>
              <li>• Un scan validé reste archivé même si l&apos;élève change de classe.</li>
            </ul>
          </SectionCard>
        </div>
      </div>

      <div className="card mt-4 overflow-hidden">
        <div className="flex flex-col gap-3 border-b border-ink/8 p-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <h2 className="section-title">Bibliothèque de documents</h2>
            <p className="mt-0.5 text-xs text-ink/50">
              {data.documents.length} document(s) affiché(s)
              {params.eleve ? " — filtrés sur un élève" : ""}
            </p>
          </div>
          <form className="flex flex-1 flex-col gap-2 sm:flex-row sm:items-center lg:max-w-2xl">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/35" />
              <input name="q" defaultValue={params.q ?? ""} placeholder="Titre, fichier, élève, matricule…" className="input pl-9" />
            </div>
            <select name="categorie" defaultValue={params.categorie ?? ""} className="input sm:w-44">
              <option value="">Tous les types</option>
              {DOCUMENT_CATEGORIES.map((category) => (
                <option key={category.key} value={category.key}>{category.label}</option>
              ))}
            </select>
            <select name="statut" defaultValue={params.statut ?? ""} className="input sm:w-36">
              <option value="">Tous statuts</option>
              <option value="à vérifier">À vérifier</option>
              <option value="validé">Validé</option>
              <option value="rejeté">Rejeté</option>
            </select>
            {params.eleve ? <input type="hidden" name="eleve" value={params.eleve} /> : null}
            <button type="submit" className="btn-outline">Filtrer</button>
          </form>
        </div>

        {data.documents.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={FolderOpen}
              title="Aucun document trouvé"
              description="Importez un acte de naissance, une fiche d'inscription ou scannez un bulletin pour commencer."
            />
          </div>
        ) : (
          <ul className="divide-y divide-ink/6">
            {data.documents.map((doc) => {
              const isImage = doc.mimeType.startsWith("image/");
              const categoryLabel =
                DOCUMENT_CATEGORIES.find((c) => c.key === doc.category)?.label ?? "Document";
              return (
                <li key={doc.id} className="px-4 py-3.5">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-start">
                    <div className="flex min-w-0 flex-1 items-start gap-3">
                      <span className={`grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-xl ${isImage ? "bg-sky-50 text-sky-600" : "bg-brand-50 text-brand-700"}`}>
                        {isImage ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={`/api/documents/${doc.id}`} alt={doc.title} className="h-full w-full object-cover" />
                        ) : (
                          <FileText className="h-5 w-5" />
                        )}
                      </span>
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <Badge tone={statusTone(doc.status)}>{DOCUMENT_STATUS_LABEL[doc.status] ?? doc.status}</Badge>
                          <Badge tone="neutral">{categoryLabel}</Badge>
                          {doc.source === "scan" ? <Badge tone="info">Scan</Badge> : null}
                          {doc.shared ? <Badge tone="success">Partagé</Badge> : null}
                        </div>
                        <p className="mt-1 truncate text-sm font-semibold text-ink">{doc.title}</p>
                        <p className="text-[11px] text-ink/45">
                          {doc.studentId ? (
                            <Link href={`/eleves/${doc.studentId}`} className="font-medium text-ink/60 hover:underline">
                              {doc.lastName} {doc.firstName}
                            </Link>
                          ) : (
                            "Établissement"
                          )}
                          {doc.className ? ` · ${doc.className}` : ""} · {doc.fileName} · {formatFileSize(doc.fileSize)}
                        </p>
                        <p className="text-[10px] text-ink/35">
                          {formatDateTime(doc.createdAt)} · importé par {doc.uploadedBy}
                          {doc.term ? ` · ${doc.term}` : ""}
                          {doc.average !== null ? ` · moyenne ${gradeLabel(doc.average)}/20` : ""}
                          {doc.decision ? ` · ${doc.decision}` : ""}
                        </p>
                        {doc.notes ? <p className="mt-1 text-[11px] italic text-ink/45">{doc.notes}</p> : null}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-1.5 sm:justify-end">
                      <Link href={`/api/documents/${doc.id}`} target="_blank" className="btn-ghost btn-sm">
                        <Eye className="h-3.5 w-3.5" /> Voir
                      </Link>
                      <Link href={`/api/documents/${doc.id}?download=1`} className="btn-ghost btn-sm">
                        <Download className="h-3.5 w-3.5" />
                      </Link>
                      {doc.status !== "validé" ? (
                        <form action={updateDocument}>
                          <input type="hidden" name="documentId" value={doc.id} />
                          <input type="hidden" name="intent" value="validate" />
                          <input type="hidden" name="redirectTo" value={redirectTo} />
                          <SubmitButton className="btn-soft btn-sm" pendingLabel="…">
                            <CheckCircle2 className="h-3.5 w-3.5" /> Valider
                          </SubmitButton>
                        </form>
                      ) : (
                        <form action={updateDocument}>
                          <input type="hidden" name="documentId" value={doc.id} />
                          <input type="hidden" name="intent" value={doc.shared ? "unshare" : "share"} />
                          <input type="hidden" name="redirectTo" value={redirectTo} />
                          <SubmitButton className="btn-outline btn-sm" pendingLabel="…">
                            <Share2 className="h-3.5 w-3.5" /> {doc.shared ? "Retirer" : "Partager"}
                          </SubmitButton>
                        </form>
                      )}
                      <form action={updateDocument}>
                        <input type="hidden" name="documentId" value={doc.id} />
                        <input type="hidden" name="intent" value="reject" />
                        <input type="hidden" name="redirectTo" value={redirectTo} />
                        <SubmitButton className="btn-ghost btn-sm !px-2 text-red-500" pendingLabel="">
                          <XCircle className="h-3.5 w-3.5" />
                        </SubmitButton>
                      </form>
                      <form action={deleteDocument}>
                        <input type="hidden" name="documentId" value={doc.id} />
                        <input type="hidden" name="redirectTo" value={redirectTo} />
                        <SubmitButton className="btn-ghost btn-sm !px-2 text-red-500" pendingLabel="">
                          <Trash2 className="h-3.5 w-3.5" />
                        </SubmitButton>
                      </form>
                    </div>
                  </div>
                  {doc.status === "à vérifier" && doc.category === "bulletin" ? (
                    <form action={updateDocument} className="mt-2 grid gap-2 rounded-xl bg-sand/60 p-3 sm:grid-cols-5">
                      <input type="hidden" name="documentId" value={doc.id} />
                      <input type="hidden" name="intent" value="update" />
                      <input type="hidden" name="redirectTo" value={redirectTo} />
                      <div className="sm:col-span-2">
                        <label className="label" htmlFor={`title-${doc.id}`}>Titre du bulletin</label>
                        <input id={`title-${doc.id}`} name="title" defaultValue={doc.title} className="input" />
                      </div>
                      <div>
                        <label className="label" htmlFor={`term-${doc.id}`}>Trimestre</label>
                        <select id={`term-${doc.id}`} name="term" defaultValue={doc.term || TERMS[0]} className="input">
                          {TERMS.map((term) => (
                            <option key={term} value={term}>{term}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="label" htmlFor={`average-${doc.id}`}>Moyenne /20</label>
                        <input id={`average-${doc.id}`} name="average" type="number" min={0} max={20} step={0.01} defaultValue={doc.average ?? ""} className="input" />
                      </div>
                      <div>
                        <label className="label" htmlFor={`decision-${doc.id}`}>Décision</label>
                        <select id={`decision-${doc.id}`} name="decision" defaultValue={doc.decision} className="input">
                          <option value="">À déterminer</option>
                          <option value="admis">Admis</option>
                          <option value="à soutenir">À soutenir</option>
                          <option value="redouble">Redouble</option>
                        </select>
                      </div>
                      <div className="sm:col-span-5 flex flex-wrap items-center gap-2">
                        <input type="hidden" name="category" value={doc.category} />
                        <label className="flex items-center gap-1.5 text-[11px] font-semibold text-ink/55">
                          <input type="checkbox" name="shared" defaultChecked={doc.shared} className="h-3.5 w-3.5 accent-brand-700" />
                          Partager aux parents
                        </label>
                        <SubmitButton className="btn-primary btn-sm" pendingLabel="Mise à jour…">
                          Enregistrer la lecture
                        </SubmitButton>
                        <span className="text-[10px] text-ink/35">Scanné le {formatDate(doc.createdAt)}</span>
                      </div>
                    </form>
                  ) : null}
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </>
  );
}
