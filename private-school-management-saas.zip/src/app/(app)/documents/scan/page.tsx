import Link from "next/link";
import { ArrowLeft, CheckCircle2, FileText, ScanLine, ShieldCheck, Sparkles } from "lucide-react";
import { Badge, Notice, PageHeader, SectionCard } from "@/components/ui";
import { SubmitButton } from "@/components/forms";
import { DocumentUploader } from "@/components/document-uploader";
import { Restricted } from "@/components/restricted";
import { updateDocument, uploadDocument } from "@/lib/actions";
import { formatFileSize, getDocumentsPageData } from "@/lib/data/documents";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import { DOCUMENT_CATEGORIES, TERMS, formatDateTime, gradeLabel } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<{ eleve?: string; importe?: string; erreur?: string }> };

export default async function ScanPage({ searchParams }: Props) {
  const [role, params] = await Promise.all([getRole(), searchParams]);
  if (!can(role, "documents")) return <Restricted role={role} module="Scanner de bulletins" />;

  const data = await getDocumentsPageData({ category: "bulletin" });
  const selectedStudent = params.eleve ? data.students.find((s) => String(s.id) === params.eleve) : undefined;
  const redirectTo = `/documents/scan${params.eleve ? `?eleve=${params.eleve}` : ""}`;
  const pending = data.documents.filter((doc) => doc.status === "à vérifier");
  const validated = data.documents.filter((doc) => doc.status !== "à vérifier");

  return (
    <>
      <Link href="/documents" className="mb-4 inline-flex items-center gap-1.5 text-xs font-semibold text-ink/50 hover:text-ink">
        <ArrowLeft className="h-3.5 w-3.5" /> Bibliothèque de documents
      </Link>

      <PageHeader
        eyebrow="Numérisation"
        title="Scanner un bulletin"
        subtitle="Photographiez le bulletin papier, vérifiez la moyenne lue puis validez : le parent le retrouve immédiatement dans son portail."
        actions={<Badge tone="brand">{pending.length} scan(s) à vérifier</Badge>}
      />

      {params.importe ? (
        <div className="mb-4"><Notice>Scan enregistré. Vérifiez les informations lues puis validez le document dans la liste ci-dessous.</Notice></div>
      ) : null}
      {params.erreur ? <div className="mb-4"><Notice tone="danger">{params.erreur}</Notice></div> : null}

      <div className="grid gap-4 xl:grid-cols-[1.3fr_1fr]">
        <SectionCard
          title="1. Capturer le bulletin"
          description={selectedStudent ? `Élève présélectionné : ${selectedStudent.lastName} ${selectedStudent.firstName}` : "Prenez une photo nette ou importez le PDF du bulletin"}
        >
          <DocumentUploader
            action={uploadDocument}
            redirectTo={redirectTo}
            students={data.students}
            categories={[...DOCUMENT_CATEGORIES]}
            terms={TERMS}
            mode="scan"
            defaultStudentId={params.eleve}
            defaultCategory="bulletin"
          />
        </SectionCard>

        <div className="space-y-4">
          <SectionCard title="2. Vérifier les informations lues" description="Moyenne, trimestre et décision">
            <div className="space-y-2.5 text-[11px] leading-relaxed text-ink/60">
              <p className="flex items-start gap-2">
                <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand-600" />
                Le scanner extrait l&apos;élève, le trimestre et la moyenne. Corrigez-les si la photo est floue.
              </p>
              <p className="flex items-start gap-2">
                <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand-600" />
                Tant que le document n&apos;est pas validé, il n&apos;apparaît pas comme pièce officielle.
              </p>
              <p className="flex items-start gap-2">
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand-600" />
                La validation partage automatiquement le bulletin aux parents.
              </p>
            </div>
            <div className="mt-3 rounded-xl border border-ink/8 bg-sand/50 p-3">
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Formats acceptés</p>
              <p className="mt-1 text-[11px] text-ink/55">PDF, JPG, PNG, WEBP ou DOCX · 8 Mo maximum par document.</p>
            </div>
          </SectionCard>

          <SectionCard title="Conseils de numérisation">
            <ul className="space-y-1.5 text-[11px] leading-relaxed text-ink/60">
              <li>• Éclairage uniforme, sans flash direct.</li>
              <li>• Le bulletin entier doit tenir dans le cadre.</li>
              <li>• Évitez les doigts sur les notes et la moyenne.</li>
              <li>• En cas de doute, rescannez plutôt que de valider un document illisible.</li>
            </ul>
          </SectionCard>
        </div>
      </div>

      <SectionCard
        title="File de vérification"
        description={`${pending.length} scan(s) en attente de validation`}
        className="mt-4"
        bodyClassName="divide-y divide-ink/6"
      >
        {pending.length === 0 ? (
          <p className="px-5 py-8 text-center text-sm text-ink/50">Aucun scan en attente. Tout est à jour.</p>
        ) : (
          pending.map((doc) => (
            <div key={doc.id} className="px-5 py-4">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Badge tone="warning">À vérifier</Badge>
                    {doc.term ? <Badge tone="neutral">{doc.term}</Badge> : null}
                    {doc.shared ? <Badge tone="success">Partagé</Badge> : <Badge tone="neutral">Non partagé</Badge>}
                  </div>
                  <p className="mt-1 text-sm font-semibold text-ink">{doc.title}</p>
                  <p className="text-[11px] text-ink/45">
                    {doc.lastName ? `${doc.lastName} ${doc.firstName}` : "Élève non identifié"}
                    {doc.className ? ` · ${doc.className}` : ""} · {doc.fileName} · {formatFileSize(doc.fileSize)} ·{" "}
                    {formatDateTime(doc.createdAt)}
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <Link href={`/api/documents/${doc.id}`} target="_blank" className="btn-ghost btn-sm">
                    <FileText className="h-3.5 w-3.5" /> Ouvrir
                  </Link>
                  <form action={updateDocument}>
                    <input type="hidden" name="documentId" value={doc.id} />
                    <input type="hidden" name="intent" value="validate" />
                    <input type="hidden" name="redirectTo" value={redirectTo} />
                    <SubmitButton className="btn-primary btn-sm" pendingLabel="Validation…">
                      <CheckCircle2 className="h-3.5 w-3.5" /> Valider
                    </SubmitButton>
                  </form>
                </div>
              </div>
              <form action={updateDocument} className="mt-2 grid gap-2 sm:grid-cols-4">
                <input type="hidden" name="documentId" value={doc.id} />
                <input type="hidden" name="intent" value="update" />
                <input type="hidden" name="redirectTo" value={redirectTo} />
                <input type="hidden" name="category" value="bulletin" />
                <div className="sm:col-span-2">
                  <label className="label" htmlFor={`scan-title-${doc.id}`}>Élève / titre</label>
                  <input id={`scan-title-${doc.id}`} name="title" defaultValue={doc.title} className="input" />
                </div>
                <div>
                  <label className="label" htmlFor={`scan-term-${doc.id}`}>Trimestre</label>
                  <select id={`scan-term-${doc.id}`} name="term" defaultValue={doc.term || TERMS[0]} className="input">
                    {TERMS.map((term) => (
                      <option key={term} value={term}>{term}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label" htmlFor={`scan-average-${doc.id}`}>
                    Moyenne lue {doc.average !== null ? `(${gradeLabel(doc.average)})` : ""}
                  </label>
                  <input id={`scan-average-${doc.id}`} name="average" type="number" min={0} max={20} step={0.01} defaultValue={doc.average ?? ""} className="input" />
                </div>
                <div className="sm:col-span-4">
                  <SubmitButton className="btn-outline btn-sm" pendingLabel="Enregistrement…">
                    Corriger la lecture
                  </SubmitButton>
                </div>
              </form>
            </div>
          ))
        )}
      </SectionCard>

      <SectionCard
        title="Bulletins validés"
        description={`${validated.length} bulletin(s) officiellement archivés`}
        className="mt-4"
        bodyClassName="divide-y divide-ink/6"
      >
        {validated.length === 0 ? (
          <p className="px-5 py-6 text-center text-sm text-ink/50">Aucun bulletin validé pour le moment.</p>
        ) : (
          validated.slice(0, 8).map((doc) => (
            <div key={doc.id} className="flex flex-wrap items-center justify-between gap-2 px-5 py-3">
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-ink">{doc.title}</p>
                <p className="text-[11px] text-ink/45">
                  {doc.lastName ? `${doc.lastName} ${doc.firstName}` : "—"} · {doc.term || "—"} ·{" "}
                  {doc.average !== null ? `moyenne ${gradeLabel(doc.average)}/20` : "moyenne non renseignée"}
                  {doc.decision ? ` · ${doc.decision}` : ""}
                </p>
              </div>
              <div className="flex items-center gap-1.5">
                <Badge tone="success">Validé</Badge>
                <Link href={`/api/documents/${doc.id}`} target="_blank" className="btn-ghost btn-sm">
                  <ScanLine className="h-3.5 w-3.5" /> Voir le scan
                </Link>
              </div>
            </div>
          ))
        )}
      </SectionCard>
    </>
  );
}
