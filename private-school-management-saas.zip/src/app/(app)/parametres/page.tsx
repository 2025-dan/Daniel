import { Building2, CalendarRange, Check, Coins, GraduationCap, Plus, Save, ShieldCheck, Wallet } from "lucide-react";
import { Badge, Notice, PageHeader, SectionCard } from "@/components/ui";
import { SubmitButton } from "@/components/forms";
import { Restricted } from "@/components/restricted";
import { createFeeStructure, createSubject, saveSchool, setCurrentYear } from "@/lib/actions";
import { getAcademicYears, getClassSummaries, requireContext } from "@/lib/data/context";
import { getFeeStructures } from "@/lib/data/finance";
import { getSubjects } from "@/lib/data/academics";
import { getRole } from "@/lib/session";
import { can, ROLES, SECTION_ACCESS } from "@/lib/roles";
import { COUNTRIES, CYCLES, DRC_CITIES, LEVELS, formatDate, money } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<{ enregistre?: string; erreur?: string }> };

const SECTION_LABELS: Record<string, string> = {
  dashboard: "Tableau de bord",
  students: "Élèves",
  classes: "Classes",
  documents: "Documents & scans",
  finance: "Finances",
  attendance: "Présences",
  timetable: "Emploi du temps",
  lessons: "Cahier de textes",
  exams: "Examens",
  grades: "Notes",
  reports: "Bulletins",
  staff: "Personnel",
  payroll: "Paie",
  messages: "Communication",
  settings: "Paramètres",
};

export default async function SettingsPage({ searchParams }: Props) {
  const [role, params] = await Promise.all([getRole(), searchParams]);
  if (!can(role, "settings")) return <Restricted role={role} module="Paramètres de l'établissement" />;

  const [ctx, years, fees, subjects, classRows] = await Promise.all([
    requireContext(),
    getAcademicYears(),
    getFeeStructures(),
    getSubjects(),
    getClassSummaries(),
  ]);
  const { school, year } = ctx;
  const totalFee = fees.reduce((sum, fee) => sum + fee.amount, 0);

  return (
    <>
      <PageHeader
        eyebrow="Établissement"
        title="Paramètres"
        subtitle="Identité de l'école, année scolaire, barèmes de frais et matières enseignées."
        actions={<Badge tone="brand">{school.shortName} · {year.label}</Badge>}
      />

      {params.enregistre ? (
        <div className="mb-4"><Notice>Paramètres enregistrés avec succès.</Notice></div>
      ) : null}
      {params.erreur ? (
        <div className="mb-4"><Notice tone="danger">{params.erreur}</Notice></div>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-2">
        <SectionCard
          title="Identité de l'établissement"
          description="Modifiez librement le nom, le pays, la ville et les coordonnées : ils figurent sur les bulletins et reçus"
        >
          <form action={saveSchool} className="grid gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="label" htmlFor="name">Nom complet</label>
              <input id="name" name="name" defaultValue={school.name} className="input" required />
            </div>
            <div>
              <label className="label" htmlFor="shortName">Sigle</label>
              <input id="shortName" name="shortName" defaultValue={school.shortName} className="input" />
            </div>
            <div>
              <label className="label" htmlFor="directorName">Directeur / promotrice</label>
              <input id="directorName" name="directorName" defaultValue={school.directorName} className="input" />
            </div>
            <div>
              <label className="label" htmlFor="country">Pays</label>
              <select id="country" name="country" defaultValue={school.country} className="input">
                {[...new Set([school.country, ...COUNTRIES])].filter(Boolean).map((country) => (
                  <option key={country} value={country}>{country}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="city">Ville / province</label>
              <input id="city" name="city" defaultValue={school.city} list="drc-cities" className="input" />
              <datalist id="drc-cities">
                {DRC_CITIES.map((city) => (
                  <option key={city} value={city} />
                ))}
              </datalist>
            </div>
            <div>
              <label className="label" htmlFor="phone">Téléphone</label>
              <input id="phone" name="phone" defaultValue={school.phone} className="input" />
            </div>
            <div>
              <label className="label" htmlFor="email">E-mail</label>
              <input id="email" name="email" type="email" defaultValue={school.email} className="input" />
            </div>
            <div className="sm:col-span-2">
              <label className="label" htmlFor="address">Adresse</label>
              <input id="address" name="address" defaultValue={school.address} className="input" />
            </div>
            <div className="sm:col-span-2">
              <label className="label" htmlFor="motto">Devise de l&apos;école</label>
              <input id="motto" name="motto" defaultValue={school.motto} className="input" />
            </div>
            <div className="sm:col-span-2">
              <SubmitButton className="btn-primary" pendingLabel="Enregistrement…">
                <Save className="h-4 w-4" /> Enregistrer les informations
              </SubmitButton>
            </div>
          </form>
        </SectionCard>

        <div className="space-y-4">
          <SectionCard title="Année scolaire" description="L'année courante pilote les inscriptions et les factures">
            <div className="space-y-2">
              {years.map((item) => (
                <div key={item.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-ink/8 px-3 py-2.5">
                  <div>
                    <p className="text-sm font-semibold text-ink">{item.label}</p>
                    <p className="text-[11px] text-ink/45">
                      Du {formatDate(item.startDate)} au {formatDate(item.endDate)}
                    </p>
                  </div>
                  {item.isCurrent ? (
                    <Badge tone="success"><Check className="h-3 w-3" /> Année en cours</Badge>
                  ) : (
                    <form action={setCurrentYear}>
                      <input type="hidden" name="yearId" value={item.id} />
                      <SubmitButton className="btn-outline btn-sm" pendingLabel="Bascule…">
                        Activer
                      </SubmitButton>
                    </form>
                  )}
                </div>
              ))}
            </div>
          </SectionCard>

          <SectionCard title="Établissement en chiffres">
            <dl className="grid grid-cols-2 gap-3">
              {[
                { label: "Classes", value: classRows.length, icon: GraduationCap },
                { label: "Élèves inscrits", value: classRows.reduce((s, c) => s + c.studentCount, 0), icon: Building2 },
                { label: "Matières", value: subjects.length, icon: CalendarRange },
                { label: "Lignes de frais", value: fees.length, icon: Coins },
              ].map((stat) => (
                <div key={stat.label} className="rounded-xl bg-sand p-3">
                  <stat.icon className="h-4 w-4 text-brand-600" />
                  <p className="mt-2 font-display text-lg font-bold text-ink">{stat.value}</p>
                  <p className="text-[11px] text-ink/45">{stat.label}</p>
                </div>
              ))}
            </dl>
            <div className="mt-3 flex items-center justify-between rounded-xl border border-brand-200 bg-brand-50 px-3 py-2.5">
              <span className="text-xs font-semibold text-brand-800">Total des frais paramétrés</span>
              <span className="text-sm font-bold text-brand-900">{money(totalFee)}</span>
            </div>
          </SectionCard>
        </div>
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-2">
        <SectionCard
          title="Frais & barèmes"
          description={`${fees.length} ligne(s) pour l'année ${year.label}`}
          bodyClassName="p-0"
        >
          <div className="max-h-[320px] overflow-y-auto">
            <table className="w-full border-collapse">
              <thead className="sticky top-0 bg-sand/90 backdrop-blur">
                <tr>
                  <th className="th">Niveau</th>
                  <th className="th">Libellé</th>
                  <th className="th">Type</th>
                  <th className="th text-right">Montant</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink/6">
                {fees.map((fee) => (
                  <tr key={fee.id} className="row-hover">
                    <td className="td font-medium text-ink">{fee.level}</td>
                    <td className="td">
                      {fee.label}
                      {fee.dueDate ? <span className="block text-[11px] text-ink/40">échéance {formatDate(fee.dueDate)}</span> : null}
                    </td>
                    <td className="td"><Badge tone="neutral">{fee.type}</Badge></td>
                    <td className="td text-right font-semibold">{money(fee.amount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="border-t border-ink/8 p-4">
            <details>
              <summary className="btn-soft btn-sm inline-flex cursor-pointer list-none">
                <Plus className="h-3.5 w-3.5" /> Ajouter une ligne de frais
              </summary>
              <form action={createFeeStructure} className="mt-3 grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="label" htmlFor="fee-level">Niveau</label>
                  <select id="fee-level" name="level" className="input" defaultValue="1ère Primaire">
                    {LEVELS.map((level) => (
                      <option key={level} value={level}>{level}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label" htmlFor="fee-type">Type</label>
                  <select id="fee-type" name="type" className="input" defaultValue="scolarité">
                    <option value="inscription">Inscription</option>
                    <option value="scolarité">Scolarité</option>
                    <option value="cantine">Cantine</option>
                    <option value="transport">Transport</option>
                    <option value="autre">Autre</option>
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <label className="label" htmlFor="fee-label">Libellé</label>
                  <input id="fee-label" name="label" className="input" placeholder="Scolarité — 2e versement" required />
                </div>
                <div>
                  <label className="label" htmlFor="fee-amount">Montant (FC)</label>
                  <input id="fee-amount" name="amount" type="number" min={0} step={500} className="input" required />
                </div>
                <div>
                  <label className="label" htmlFor="fee-due">Échéance</label>
                  <input id="fee-due" name="dueDate" type="date" className="input" />
                </div>
                <div className="sm:col-span-2">
                  <SubmitButton className="btn-primary btn-sm" pendingLabel="Ajout…">
                    <Plus className="h-3.5 w-3.5" /> Ajouter
                  </SubmitButton>
                </div>
              </form>
            </details>
          </div>
        </SectionCard>

        <SectionCard
          title="Matières & coefficients"
          description={`${subjects.length} matières · cycle et enseignant`}
          bodyClassName="p-0"
        >
          <div className="max-h-[320px] overflow-y-auto">
            <table className="w-full border-collapse">
              <thead className="sticky top-0 bg-sand/90 backdrop-blur">
                <tr>
                  <th className="th">Matière</th>
                  <th className="th">Code</th>
                  <th className="th">Enseignant</th>
                  <th className="th text-center">Coef.</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink/6">
                {subjects.map((subject) => (
                  <tr key={subject.id} className="row-hover">
                    <td className="td font-medium text-ink">{subject.name}</td>
                    <td className="td text-xs text-ink/50">{subject.code}</td>
                    <td className="td text-xs text-ink/55">{subject.teacher || "—"}</td>
                    <td className="td text-center font-semibold">{subject.coefficient}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="border-t border-ink/8 p-4">
            <details>
              <summary className="btn-soft btn-sm inline-flex cursor-pointer list-none">
                <Plus className="h-3.5 w-3.5" /> Ajouter une matière
              </summary>
              <form action={createSubject} className="mt-3 grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="label" htmlFor="subject-name">Nom</label>
                  <input id="subject-name" name="name" className="input" placeholder="Sciences physiques" required />
                </div>
                <div>
                  <label className="label" htmlFor="subject-code">Code</label>
                  <input id="subject-code" name="code" className="input" placeholder="PC" />
                </div>
                <div>
                  <label className="label" htmlFor="subject-cycle">Cycle</label>
                  <select id="subject-cycle" name="cycle" className="input" defaultValue="Collège">
                    {CYCLES.map((cycle) => (
                      <option key={cycle} value={cycle}>{cycle}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label" htmlFor="subject-coef">Coefficient</label>
                  <input id="subject-coef" name="coefficient" type="number" min={1} max={5} defaultValue={2} className="input" />
                </div>
                <div className="sm:col-span-2">
                  <label className="label" htmlFor="subject-teacher">Enseignant</label>
                  <input id="subject-teacher" name="teacher" className="input" placeholder="M. Diallo Ismaël" />
                </div>
                <div className="sm:col-span-2">
                  <SubmitButton className="btn-primary btn-sm" pendingLabel="Ajout…">
                    <Plus className="h-3.5 w-3.5" /> Ajouter
                  </SubmitButton>
                </div>
              </form>
            </details>
          </div>
        </SectionCard>
      </div>

      <SectionCard
        title="Rôles & permissions"
        description="Chaque profil accède uniquement aux modules de son métier"
        className="mt-4"
        bodyClassName="overflow-x-auto"
      >
        <table className="w-full min-w-[720px] border-collapse">
          <thead className="bg-sand/60">
            <tr>
              <th className="th">Module</th>
              {ROLES.map((r) => (
                <th key={r.key} className="th text-center">{r.short}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/6">
            {Object.entries(SECTION_ACCESS).map(([section, allowed]) => (
              <tr key={section} className="row-hover">
                <td className="td font-medium text-ink">{SECTION_LABELS[section] ?? section}</td>
                {ROLES.map((r) => (
                  <td key={r.key} className="td text-center">
                    {allowed.includes(r.key) ? (
                      <span className="inline-grid h-5 w-5 place-items-center rounded-full bg-brand-100 text-brand-700">
                        <Check className="h-3 w-3" />
                      </span>
                    ) : (
                      <span className="text-ink/20">—</span>
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
        <p className="mt-3 flex items-center gap-1.5 text-[11px] text-ink/45">
          <ShieldCheck className="h-3.5 w-3.5" /> Changez de profil via le sélecteur en haut de page pour tester les
          accès.
        </p>
      </SectionCard>

      <div className="mt-4 flex flex-wrap items-center gap-2 text-[11px] text-ink/45">
        <Wallet className="h-3.5 w-3.5" /> Devise de facturation : {school.currency} · Établissement créé le{" "}
        {formatDate(school.createdAt)}
      </div>
    </>
  );
}
