import type { ReactNode } from "react";
import { AppShell } from "@/components/app-shell";
import { getContext } from "@/lib/data/context";
import { getRole } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: ReactNode }) {
  const [ctx, role] = await Promise.all([getContext(), getRole()]);

  if (!ctx) {
    return (
      <main className="grid min-h-screen place-items-center px-6">
        <div className="card max-w-md p-8 text-center">
          <h1 className="font-display text-xl font-semibold">Base de données non initialisée</h1>
          <p className="mt-2 text-sm text-ink/60">
            Lancez la commande <code className="rounded bg-ink/5 px-1.5 py-0.5">node scripts/seed.mjs</code> pour
            créer l&apos;établissement de démonstration.
          </p>
        </div>
      </main>
    );
  }

  return (
    <AppShell
      shortName={ctx.school.shortName}
      schoolName={ctx.school.name}
      directorName={ctx.school.directorName || "Direction"}
      yearLabel={ctx.year.label}
      role={role}
    >
      {children}
    </AppShell>
  );
}
