import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, GraduationCap } from "lucide-react";
import { PrintButton } from "@/components/forms";
import { Restricted } from "@/components/restricted";
import { requireContext } from "@/lib/data/context";
import { computeClassResults } from "@/lib/data/academics";
import { getStudentDetail } from "@/lib/data/students";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import {
  TERMS,
  appreciationFor,
  formatDate,
  gradeLabel,
  mentionFor,
} from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = {
  params: Promise<{ studentId: string }>;
  searchParams: Promise<{ term?: string }>;
};

export default async function BulletinPage({ params, searchParams }: Props) {
  const [role, { studentId: rawId }, query] = await Promise.all([getRole(), params, searchParams]);
  if (!can(role, "reports")) return <Restricted role={role} module="Bulletins" />;

  const studentId = Number(rawId);
  if (!Number.isFinite(studentId)) notFound();

  const term = query.term && TERMS.includes(query.term as (typeof TERMS)[number]) ? query.term : "Trimestre 1";
  const [detail, ctx] = await Promise.all([getStudentDetail(studentId), requireContext()]);
  if (!detail || !detail.enrollment) notFound();

  const { student, enrollment, guardians, attendance } = detail;
  const results = await computeClassResults(enrollment.classId, term);
  const myResult = results.students.find((s) => s.id === studentId) ?? null;
  const mention = mentionFor(myResult?.average ?? 0);

  const rows = results.subjects.map((subject) => {
    const average = myResult?.subjectAverages[subject.id] ?? null;
    return {
      ...subject,
      average,
      points: average === null ? null : average * subject.coefficient,
    };
  });
  const totalCoefficient = rows.reduce((sum, row) => sum + row.coefficient, 0);
  const totalPoints = rows.reduce((sum, row) => sum + (row.points ?? 0), 0);

  return (
    <>
      <div className="no-print mb-4 flex flex-wrap items-center justify-between gap-2">
        <Link
          href={`/bulletins?classId=${enrollment.classId}&term=${encodeURIComponent(term)}`}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-ink/50 hover:text-ink"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Retour au palmarès
        </Link>
        <div className="flex items-center gap-2">
          <Link href={`/eleves/${studentId}`} className="btn-outline">
            Dossier de l&apos;élève
          </Link>
          <PrintButton />
        </div>
      </div>

      <article className="print-card card mx-auto max-w-4xl overflow-hidden p-6 sm:p-10">
        <header className="flex flex-col gap-4 border-b border-ink/10 pb-5 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-xl bg-brand-700 text-white">
              <GraduationCap className="h-6 w-6" />
            </span>
            <div>
              <h1 className="font-display text-lg font-bold uppercase tracking-wide text-ink">{ctx.school.name}</h1>
              <p className="text-[11px] text-ink/50">{ctx.school.address}</p>
              <p className="text-[11px] text-ink/50">
                {ctx.school.phone} · {ctx.school.email}
              </p>
              <p className="mt-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-brand-700">{ctx.school.motto}</p>
            </div>
          </div>
          <div className="rounded-xl border border-brand-200 bg-brand-50 px-4 py-3 text-center">
            <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-brand-700">Bulletin de notes</p>
            <p className="mt-1 font-display text-base font-bold text-brand-900">{term}</p>
            <p className="text-[11px] text-brand-800/70">Année {ctx.year.label}</p>
          </div>
        </header>

        <section className="grid gap-3 border-b border-ink/10 py-5 sm:grid-cols-2">
          <div className="space-y-1.5 text-sm">
            <p className="flex justify-between gap-3 border-b border-dashed border-ink/10 pb-1">
              <span className="text-ink/45">Élève</span>
              <span className="font-semibold text-ink">{student.lastName} {student.firstName}</span>
            </p>
            <p className="flex justify-between gap-3 border-b border-dashed border-ink/10 pb-1">
              <span className="text-ink/45">Matricule</span>
              <span className="font-medium text-ink">{student.matricule}</span>
            </p>
            <p className="flex justify-between gap-3 border-b border-dashed border-ink/10 pb-1">
              <span className="text-ink/45">Né(e) le</span>
              <span className="font-medium text-ink">
                {student.birthDate ? formatDate(student.birthDate) : "—"} {student.birthPlace ? `à ${student.birthPlace}` : ""}
              </span>
            </p>
          </div>
          <div className="space-y-1.5 text-sm">
            <p className="flex justify-between gap-3 border-b border-dashed border-ink/10 pb-1">
              <span className="text-ink/45">Classe</span>
              <span className="font-semibold text-ink">{enrollment.className} ({enrollment.cycle})</span>
            </p>
            <p className="flex justify-between gap-3 border-b border-dashed border-ink/10 pb-1">
              <span className="text-ink/45">Effectif</span>
              <span className="font-medium text-ink">{results.students.length} élèves</span>
            </p>
            <p className="flex justify-between gap-3 border-b border-dashed border-ink/10 pb-1">
              <span className="text-ink/45">Tuteur</span>
              <span className="font-medium text-ink">{guardians[0]?.fullName ?? "—"}</span>
            </p>
          </div>
        </section>

        <section className="py-5">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="bg-sand">
                <th className="border border-ink/10 px-3 py-2 text-left text-[10px] font-bold uppercase tracking-wide text-ink/50">Matière</th>
                <th className="border border-ink/10 px-2 py-2 text-center text-[10px] font-bold uppercase tracking-wide text-ink/50">Coef.</th>
                <th className="border border-ink/10 px-2 py-2 text-center text-[10px] font-bold uppercase tracking-wide text-ink/50">Moy. élève</th>
                <th className="border border-ink/10 px-2 py-2 text-center text-[10px] font-bold uppercase tracking-wide text-ink/50">Moy. classe</th>
                <th className="border border-ink/10 px-2 py-2 text-center text-[10px] font-bold uppercase tracking-wide text-ink/50">Points</th>
                <th className="border border-ink/10 px-3 py-2 text-left text-[10px] font-bold uppercase tracking-wide text-ink/50">Appréciation</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td className="border border-ink/10 px-3 py-2 font-medium text-ink">
                    {row.name}
                    <span className="block text-[10px] font-normal text-ink/40">{row.teacher || "—"}</span>
                  </td>
                  <td className="border border-ink/10 px-2 py-2 text-center text-ink/70">{row.coefficient}</td>
                  <td className={`border border-ink/10 px-2 py-2 text-center font-bold ${(row.average ?? 0) >= 10 ? "text-brand-700" : "text-red-600"}`}>
                    {gradeLabel(row.average)}
                  </td>
                  <td className="border border-ink/10 px-2 py-2 text-center text-ink/60">{gradeLabel(row.classAverage)}</td>
                  <td className="border border-ink/10 px-2 py-2 text-center text-ink/60">{row.points === null ? "—" : gradeLabel(row.points)}</td>
                  <td className="border border-ink/10 px-3 py-2 text-[11px] text-ink/60">{appreciationFor(row.average)}</td>
                </tr>
              ))}
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={6} className="border border-ink/10 px-3 py-6 text-center text-ink/50">
                    Aucune évaluation enregistrée pour ce trimestre.
                  </td>
                </tr>
              ) : null}
            </tbody>
            <tfoot>
              <tr className="bg-sand/60 font-semibold">
                <td className="border border-ink/10 px-3 py-2 text-right text-xs uppercase tracking-wide text-ink/50">Totaux</td>
                <td className="border border-ink/10 px-2 py-2 text-center">{totalCoefficient}</td>
                <td className="border border-ink/10 px-2 py-2 text-center" colSpan={2} />
                <td className="border border-ink/10 px-2 py-2 text-center">{gradeLabel(totalPoints)}</td>
                <td className="border border-ink/10 px-3 py-2" />
              </tr>
            </tfoot>
          </table>
        </section>

        <section className="grid gap-3 sm:grid-cols-3">
          <div className="rounded-xl bg-brand-700 p-4 text-white">
            <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-white/60">Moyenne générale</p>
            <p className="mt-1 font-display text-2xl font-bold">{gradeLabel(myResult?.average)}/20</p>
            <p className="mt-1 text-[11px] text-white/70">Mention : {myResult?.average === null ? "—" : mention.label}</p>
          </div>
          <div className="rounded-xl border border-ink/10 p-4">
            <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-ink/40">Rang</p>
            <p className="mt-1 font-display text-2xl font-bold text-ink">
              {myResult?.rank ?? "—"}
              <span className="text-sm font-medium text-ink/40"> / {results.students.length}</span>
            </p>
            <p className="mt-1 text-[11px] text-ink/45">Moyenne de classe {gradeLabel(results.classAverage)}/20</p>
          </div>
          <div className="rounded-xl border border-ink/10 p-4">
            <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-ink/40">Assiduité</p>
            <p className="mt-1 font-display text-2xl font-bold text-ink">{attendance.rate}%</p>
            <p className="mt-1 text-[11px] text-ink/45">{attendance.present}/{attendance.total} présences enregistrées</p>
          </div>
        </section>

        <section className="mt-4 rounded-xl border border-ink/10 bg-sand/40 p-4">
          <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-ink/40">Appréciation générale du conseil de classe</p>
          <p className="mt-1.5 text-sm text-ink/75">{appreciationFor(myResult?.average ?? null)}</p>
        </section>

        <footer className="mt-8 grid grid-cols-2 gap-6 text-center text-[11px] text-ink/50">
          <div>
            <p className="border-t border-ink/20 pt-2">L&apos;enseignant(e) titulaire</p>
            <p className="mt-1 font-medium text-ink/60">{enrollment.teacher || "—"}</p>
          </div>
          <div>
            <p className="border-t border-ink/20 pt-2">Le directeur / la directrice</p>
            <p className="mt-1 font-medium text-ink/60">{ctx.school.directorName}</p>
          </div>
        </footer>
        <p className="mt-6 text-center text-[10px] text-ink/30">
          Bulletin généré par Scolaris · {ctx.school.shortName} · {formatDate(new Date())}
        </p>
      </article>
    </>
  );
}
