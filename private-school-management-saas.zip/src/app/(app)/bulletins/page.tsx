import Link from "next/link";
import { Award, FileText, GraduationCap, TrendingUp, UserCheck } from "lucide-react";
import { Avatar, Badge, EmptyState, PageHeader, SectionCard, StatCard } from "@/components/ui";
import { Restricted } from "@/components/restricted";
import { getClassSummaries } from "@/lib/data/context";
import { computeClassResults } from "@/lib/data/academics";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";
import { TERMS, appreciationFor, gradeLabel, mentionFor } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<{ classId?: string; term?: string }> };

export default async function ReportsPage({ searchParams }: Props) {
  const [role, params] = await Promise.all([getRole(), searchParams]);
  if (!can(role, "reports")) return <Restricted role={role} module="Bulletins" />;

  const term = params.term && TERMS.includes(params.term as (typeof TERMS)[number]) ? params.term : "Trimestre 1";
  const classRows = await getClassSummaries();
  const selectedClass = classRows.find((c) => String(c.id) === params.classId) ?? classRows[0] ?? null;

  if (!selectedClass) {
    return (
      <>
        <PageHeader eyebrow="Pédagogie" title="Bulletins" />
        <EmptyState icon={FileText} title="Aucune classe" description="Créez une classe pour générer des bulletins." />
      </>
    );
  }

  const results = await computeClassResults(selectedClass.id, term);
  const ranked = [...results.students].sort((a, b) => (a.rank ?? 999) - (b.rank ?? 999));

  return (
    <>
      <PageHeader
        eyebrow="Pédagogie"
        title="Bulletins scolaires"
        subtitle={`${selectedClass.name} · ${term} · ${results.students.length} élèves évalués`}
        actions={
          <Link href={`/notes?classId=${selectedClass.id}&term=${encodeURIComponent(term)}`} className="btn-outline">
            <TrendingUp className="h-4 w-4" /> Saisir des notes
          </Link>
        }
      />

      <div className="card mb-4 p-4">
        <form className="grid gap-3 sm:grid-cols-3 sm:items-end">
          <div>
            <label className="label" htmlFor="classId">Classe</label>
            <select id="classId" name="classId" className="input" defaultValue={String(selectedClass.id)}>
              {classRows.map((cls) => (
                <option key={cls.id} value={cls.id}>{cls.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="term">Trimestre</label>
            <select id="term" name="term" className="input" defaultValue={term}>
              {TERMS.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
          <button type="submit" className="btn-primary">
            <FileText className="h-4 w-4" /> Afficher les bulletins
          </button>
        </form>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Moyenne de classe" value={`${gradeLabel(results.classAverage)}/20`} hint={`${results.assessmentsCount} évaluations prises en compte`} icon={TrendingUp} />
        <StatCard label="Taux de réussite" value={`${results.successRate}%`} hint="Moyenne générale ≥ 10/20" icon={UserCheck} tone="sky" />
        <StatCard label="Meilleure moyenne" value={`${gradeLabel(results.best?.average)}/20`} hint={results.best ? `${results.best.lastName} ${results.best.firstName}` : "—"} icon={Award} tone="amber" />
        <StatCard label="Effectif évalué" value={ranked.filter((s) => s.average !== null).length} hint={`sur ${results.students.length} élèves inscrits`} icon={GraduationCap} tone="brand" />
      </div>

      <SectionCard
        title={`Palmarès — ${term}`}
        description="Classement par moyenne générale pondérée"
        className="mt-4"
        action={<Badge tone="brand">{selectedClass.name}</Badge>}
        bodyClassName="overflow-x-auto"
      >
        {ranked.length === 0 ? (
          <EmptyState icon={FileText} title="Aucun élève dans cette classe" description="Inscrivez des élèves puis saisissez des notes." />
        ) : (
          <table className="w-full min-w-[760px] border-collapse">
            <thead className="bg-sand/60">
              <tr>
                <th className="th">Rang</th>
                <th className="th">Élève</th>
                <th className="th">Moyenne</th>
                <th className="th">Mention</th>
                <th className="th">Appréciation du conseil</th>
                <th className="th text-right">Bulletin</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/6">
              {ranked.map((student) => {
                const mention = mentionFor(student.average ?? 0);
                return (
                  <tr key={student.id} className="row-hover">
                    <td className="td">
                      <span className="grid h-7 w-7 place-items-center rounded-full bg-sand text-xs font-bold text-ink/60">
                        {student.rank ?? "—"}
                      </span>
                    </td>
                    <td className="td">
                      <div className="flex items-center gap-2.5">
                        <Avatar first={student.firstName} last={student.lastName} size="sm" />
                        <div>
                          <Link href={`/eleves/${student.id}`} className="font-semibold text-ink hover:underline">
                            {student.lastName} {student.firstName}
                          </Link>
                          <p className="text-[11px] text-ink/45">{student.matricule}</p>
                        </div>
                      </div>
                    </td>
                    <td className="td">
                      <span className={`font-display text-base font-bold ${(student.average ?? 0) >= 10 ? "text-brand-700" : "text-red-600"}`}>
                        {gradeLabel(student.average)}
                      </span>
                      <span className="text-[11px] text-ink/40">/20</span>
                    </td>
                    <td className="td">
                      <Badge tone={mention.tone}>{mention.label}</Badge>
                    </td>
                    <td className="td max-w-[280px] text-xs text-ink/55">{appreciationFor(student.average)}</td>
                    <td className="td text-right">
                      <Link
                        href={`/bulletins/${student.id}?term=${encodeURIComponent(term)}`}
                        className="btn-soft btn-sm inline-flex"
                      >
                        <FileText className="h-3.5 w-3.5" /> Ouvrir
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </SectionCard>
    </>
  );
}
