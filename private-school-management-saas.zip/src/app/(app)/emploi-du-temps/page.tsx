import { CalendarRange, Plus, Trash2, Users } from "lucide-react";
import { Badge, EmptyState, Notice, PageHeader, SectionCard, StatCard } from "@/components/ui";
import { SubmitButton } from "@/components/forms";
import { Restricted } from "@/components/restricted";
import { addTimetableSlot, deleteTimetableSlot } from "@/lib/actions";
import { DAYS, TIME_SLOTS, getTimetablePageData } from "@/lib/data/school-life";
import { getRole } from "@/lib/session";
import { can } from "@/lib/roles";

export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<{ classId?: string; enregistre?: string; erreur?: string }> };

export default async function TimetablePage({ searchParams }: Props) {
  const [role, params] = await Promise.all([getRole(), searchParams]);
  if (!can(role, "timetable")) return <Restricted role={role} module="Emploi du temps" />;

  const { classRows, subjectRows, selectedClass, slots } = await getTimetablePageData(params.classId);

  if (!selectedClass) {
    return (
      <>
        <PageHeader eyebrow="Vie scolaire" title="Emploi du temps" />
        <EmptyState icon={CalendarRange} title="Aucune classe" description="Créez une classe pour construire son emploi du temps." />
      </>
    );
  }

  const hours = Math.round((slots.length * 55) / 60);
  const days = [...new Set(slots.map((s) => s.day))];
  const perDay = (day: number) => slots.filter((s) => s.day === day).length;

  return (
    <>
      <PageHeader
        eyebrow="Vie scolaire"
        title="Emploi du temps"
        subtitle="Construisez le planning hebdomadaire de chaque classe : matières, enseignants, salles et horaires."
        actions={<Badge tone="brand">{slots.length} créneaux · {hours} h / semaine</Badge>}
      />

      {params.enregistre ? <div className="mb-4"><Notice>Le créneau a été ajouté à l&apos;emploi du temps.</Notice></div> : null}
      {params.erreur ? <div className="mb-4"><Notice tone="danger">{params.erreur}</Notice></div> : null}

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Créneaux planifiés" value={slots.length} hint={`${classRows.length} classes dans l'établissement`} icon={CalendarRange} />
        <StatCard label="Jours couverts" value={`${days.length}/6`} hint="Du lundi au samedi" icon={Users} tone="sky" />
        <StatCard
          label="Volume hebdomadaire"
          value={`${hours} h`}
          hint={`${Math.round(slots.length / Math.max(1, days.length))} créneaux/jour en moyenne`}
          icon={CalendarRange}
          tone="amber"
        />
      </div>

      <div className="card my-4 p-4">
        <form className="flex flex-col gap-2 sm:flex-row sm:items-end">
          <div className="sm:w-64">
            <label className="label" htmlFor="classId">Classe</label>
            <select id="classId" name="classId" className="input" defaultValue={String(selectedClass.id)}>
              {classRows.map((cls) => (
                <option key={cls.id} value={cls.id}>{cls.name}</option>
              ))}
            </select>
          </div>
          <button type="submit" className="btn-primary">
            <CalendarRange className="h-4 w-4" /> Afficher le planning
          </button>
          <p className="text-xs text-ink/45 sm:ml-auto">
            Titulaire : {selectedClass.mainTeacher || "—"} · salle {selectedClass.room || "—"}
          </p>
        </form>
      </div>

      <SectionCard
        title={`Planning — ${selectedClass.name}`}
        description="Vue hebdomadaire du lundi au samedi"
        bodyClassName="overflow-x-auto p-0"
      >
        <table className="w-full min-w-[920px] border-collapse">
          <thead className="bg-sand/70">
            <tr>
              <th className="th w-24">Horaire</th>
              {DAYS.map((day) => (
                <th key={day.value} className="th">
                  {day.label}
                  <span className="ml-1 font-medium normal-case tracking-normal text-ink/30">({perDay(day.value)})</span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/6">
            {TIME_SLOTS.map((slot) => (
              <tr key={slot.start}>
                <td className="td whitespace-nowrap bg-sand/30 text-[11px] font-bold text-ink/50">
                  {slot.start}
                  <span className="block text-[10px] font-medium text-ink/35">{slot.end}</span>
                </td>
                {DAYS.map((day) => {
                  const cell = slots.find((s) => s.day === day.value && s.startTime === slot.start);
                  return (
                    <td key={day.value} className="td p-1.5 align-top">
                      {cell ? (
                        <div className="group relative rounded-lg border border-brand-200 bg-brand-50/70 p-2">
                          <p className="text-[12px] font-bold leading-tight text-brand-900">
                            {cell.subjectName ?? "Créneau libre"}
                          </p>
                          <p className="mt-0.5 text-[10px] leading-tight text-brand-800/70">{cell.teacher || "—"}</p>
                          <p className="text-[10px] text-brand-800/50">{cell.room || selectedClass.room}</p>
                          <form action={deleteTimetableSlot} className="absolute right-1 top-1 opacity-0 transition group-hover:opacity-100">
                            <input type="hidden" name="slotId" value={cell.id} />
                            <input type="hidden" name="classId" value={selectedClass.id} />
                            <button
                              type="submit"
                              className="grid h-5 w-5 place-items-center rounded bg-white/80 text-red-600 hover:bg-white"
                              aria-label="Supprimer le créneau"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          </form>
                        </div>
                      ) : (
                        <div className="rounded-lg border border-dashed border-ink/10 bg-sand/30 p-2 text-center text-[10px] text-ink/25">
                          —
                        </div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </SectionCard>

      <div className="mt-4 grid gap-4 xl:grid-cols-[1fr_1.4fr]">
        <SectionCard title="Ajouter un créneau" description="Un cours par créneau et par jour">
          <form action={addTimetableSlot} className="grid gap-3 sm:grid-cols-2">
            <input type="hidden" name="classId" value={selectedClass.id} />
            <div>
              <label className="label" htmlFor="day">Jour</label>
              <select id="day" name="day" className="input" defaultValue={1}>
                {DAYS.map((day) => (
                  <option key={day.value} value={day.value}>{day.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="subjectId">Matière</label>
              <select id="subjectId" name="subjectId" className="input" defaultValue="">
                <option value="">Créneau libre</option>
                {subjectRows.map((subject) => (
                  <option key={subject.id} value={subject.id}>{subject.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="startTime">Début</label>
              <select id="startTime" name="startTime" className="input" defaultValue={TIME_SLOTS[0].start}>
                {TIME_SLOTS.map((slot) => (
                  <option key={slot.start} value={slot.start}>{slot.start}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="endTime">Fin</label>
              <select id="endTime" name="endTime" className="input" defaultValue={TIME_SLOTS[0].end}>
                {TIME_SLOTS.map((slot) => (
                  <option key={slot.end} value={slot.end}>{slot.end}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="teacher">Enseignant</label>
              <input id="teacher" name="teacher" className="input" placeholder="Mme Traoré Fatou" />
            </div>
            <div>
              <label className="label" htmlFor="room">Salle</label>
              <input id="room" name="room" className="input" defaultValue={selectedClass.room} />
            </div>
            <div className="sm:col-span-2">
              <SubmitButton className="btn-primary w-full" pendingLabel="Ajout du créneau…">
                <Plus className="h-4 w-4" /> Ajouter au planning
              </SubmitButton>
            </div>
          </form>
        </SectionCard>

        <SectionCard title="Charge par jour" description="Répartition des créneaux de la semaine">
          <div className="space-y-3">
            {DAYS.map((day) => {
              const count = perDay(day.value);
              const max = Math.max(1, ...DAYS.map((d) => perDay(d.value)));
              return (
                <div key={day.value}>
                  <div className="flex items-center justify-between text-[11px] font-semibold text-ink/55">
                    <span>{day.label}</span>
                    <span>{count} créneau(x)</span>
                  </div>
                  <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-ink/8">
                    <div className="h-full rounded-full bg-brand-500" style={{ width: `${(count / max) * 100}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-4 rounded-xl bg-sand p-3 text-[11px] leading-relaxed text-ink/55">
            Les créneaux sont partagés avec le portail parents : chaque famille voit le planning de la classe de son
            enfant en temps réel.
          </div>
        </SectionCard>
      </div>
    </>
  );
}
