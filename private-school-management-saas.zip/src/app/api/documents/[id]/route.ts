import { getDocumentFile } from "@/lib/data/documents";

export const dynamic = "force-dynamic";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const documentId = Number(id);
  if (!Number.isFinite(documentId)) {
    return new Response("Identifiant invalide", { status: 400 });
  }

  const document = await getDocumentFile(documentId);
  if (!document) {
    return new Response("Document introuvable", { status: 404 });
  }

  const url = new URL(request.url);
  const download = url.searchParams.get("download") === "1";
  const bytes = Buffer.from(document.data, "base64");
  const safeName = document.fileName.replace(/["\r\n]/g, "");

  return new Response(new Uint8Array(bytes), {
    headers: {
      "Content-Type": document.mimeType || "application/octet-stream",
      "Content-Disposition": `${download ? "attachment" : "inline"}; filename="${safeName}"`,
      "Cache-Control": "private, max-age=60",
    },
  });
}
