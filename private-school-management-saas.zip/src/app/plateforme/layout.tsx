import type { ReactNode } from "react";
import Link from "next/link";
import { ArrowRight, Building2, GraduationCap, ShieldCheck } from "lucide-react";

export const metadata = {
  title: "Console plateforme — Scolaris",
  description: "Administration des écoles clientes, abonnements et facturation Scolaris.",
};

export default function PlatformLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-ink text-white">
      <header className="border-b border-white/10 bg-ink/95">
        <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <Link href="/" className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-500 text-white">
                <GraduationCap className="h-5 w-5" />
              </span>
              <span className="leading-tight">
                <span className="block font-display text-[15px] font-bold tracking-tight">Scolaris</span>
                <span className="block text-[10px] font-semibold uppercase tracking-[0.14em] text-white/40">
                  Console plateforme
                </span>
              </span>
            </Link>
            <span className="ml-2 hidden items-center gap-1 rounded-full bg-brand-500/20 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-brand-200 sm:inline-flex">
              <ShieldCheck className="h-3 w-3" /> Équipe interne
            </span>
          </div>
          <nav className="flex items-center gap-2">
            <Link href="/dashboard" className="btn bg-white/10 text-white hover:bg-white/20">
              <Building2 className="h-4 w-4" /> <span className="hidden sm:inline">Espace école</span>
            </Link>
            <Link href="/" className="btn bg-white text-ink hover:bg-white/90">
              Site <ArrowRight className="h-4 w-4" />
            </Link>
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-6xl px-4 py-8 sm:px-6">{children}</main>
      <footer className="mx-auto w-full max-w-6xl px-4 pb-10 text-[11px] text-white/35 sm:px-6">
        Console d&apos;administration Scolaris · gestion des écoles clientes, abonnements et facturation interne.
      </footer>
    </div>
  );
}
