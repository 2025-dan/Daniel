import Link from "next/link";
import {
  Building2,
  CalendarClock,
  CircleDollarSign,
  GraduationCap,
  LifeBuoy,
  Save,
  TrendingUp,
  Users,
} from "lucide-react";
import { SubmitButton } from "@/components/forms";
import { updateSubscription } from "@/lib/actions";
import { getPlatformData } from "@/lib/data/plateforme";
import { COUNTRIES, compactMoney, formatDate, money, percent } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<{ enregistre?: string }> };

const STATUS_TONE: Record<string, string> = {
  actif: "bg-brand-500/20 text-brand-200",
  essai: "bg-amber-400/20 text-amber-200",
  suspendu: "bg-red-500/20 text-red-200",
};

const PLANS = ["Essentiel", "Pro", "Groupe"];

export default async function PlatformPage({ searchParams }: Props) {
  const [data, params] = await Promise.all([getPlatformData(), searchParams]);
  const { schools, totals, recentInvoices } = data;
  const seatUsage = percent(totals.students, Math.max(1, totals.seats));

  return (
    <>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-brand-300">Administration</p>
          <h1 className="mt-1 font-display text-2xl font-semibold tracking-tight sm:text-3xl">Écoles clientes & abonnements</h1>
          <p className="mt-1.5 max-w-2xl text-sm text-white/50">
            Suivez le portefeuille d&apos;écoles, la consommation des licences et le revenu récurrent de la
            plateforme Scolaris.
          </p>
        </div>
        {params.enregistre ? (
          <span className="rounded-xl border border-brand-400/40 bg-brand-500/15 px-3 py-2 text-xs font-semibold text-brand-200">
            Abonnement mis à jour
          </span>
        ) : null}
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Écoles clientes", value: totals.schools, hint: `${totals.active} actives · ${totals.trial} en essai`, icon: Building2 },
          { label: "Revenu mensuel (MRR)", value: `${compactMoney(totals.mrr)} FC`, hint: `ARR ≈ ${compactMoney(totals.arr)} FC`, icon: CircleDollarSign },
          { label: "Élèves gérés", value: totals.students, hint: `${seatUsage}% des licences utilisées`, icon: Users },
          { label: "Licences vendues", value: totals.seats, hint: `${totals.suspended} école(s) suspendue(s)`, icon: GraduationCap },
        ].map((kpi) => (
          <div key={kpi.label} className="rounded-2xl border border-white/10 bg-white/[0.04] p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-white/40">{kpi.label}</p>
                <p className="mt-2 font-display text-2xl font-semibold">{kpi.value}</p>
                <p className="mt-1 text-[11px] text-white/40">{kpi.hint}</p>
              </div>
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-500/20 text-brand-200">
                <kpi.icon className="h-4 w-4" />
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1.55fr_1fr]">
        <div className="rounded-2xl border border-white/10 bg-white/[0.04]">
          <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
            <div>
              <h2 className="font-display text-sm font-semibold">Portefeuille d&apos;écoles</h2>
              <p className="text-[11px] text-white/40">Données consolidées de chaque établissement</p>
            </div>
            <span className="rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-white/60">
              {schools.length} comptes
            </span>
          </div>
          <div className="divide-y divide-white/8">
            {schools.map((school) => (
              <details key={school.id} className="group px-5 py-4">
                <summary className="cursor-pointer list-none">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-500/20 text-xs font-bold text-brand-200">
                        {school.shortName}
                      </span>
                      <div>
                        <p className="text-sm font-semibold">{school.name}</p>
                        <p className="text-[11px] text-white/40">
                          {school.city} · {school.directorName} · client depuis {formatDate(school.createdAt)}
                        </p>
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                          <span className={`badge ${STATUS_TONE[school.subscriptionStatus] ?? "bg-white/10 text-white/60"}`}>
                            {school.subscriptionStatus}
                          </span>
                          <span className="badge bg-white/10 text-white/60">Plan {school.plan}</span>
                          <span className="badge bg-white/10 text-white/60">{school.studentCount}/{school.seats} élèves</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-display text-base font-semibold">{money(school.monthlyPrice)}</p>
                      <p className="text-[10px] uppercase tracking-wide text-white/35">par mois</p>
                      <p className="mt-1 text-[11px] text-white/40">
                        Recouvrement {percent(school.paid, Math.max(1, school.invoiced))}%
                      </p>
                    </div>
                  </div>
                </summary>

                <div className="mt-4 grid gap-3 rounded-xl bg-black/20 p-3 sm:grid-cols-3">
                  <div>
                    <p className="text-[10px] uppercase tracking-wide text-white/35">Classes</p>
                    <p className="text-sm font-semibold">{school.classCount}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wide text-white/35">Facturé (école)</p>
                    <p className="text-sm font-semibold">{money(school.invoiced)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wide text-white/35">Renouvellement</p>
                    <p className="text-sm font-semibold">{school.renewalDate ? formatDate(school.renewalDate) : "—"}</p>
                  </div>
                </div>

                <form action={updateSubscription} className="mt-3 grid gap-2 sm:grid-cols-3">
                  <input type="hidden" name="schoolId" value={school.id} />
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-white/35">Nom de l&apos;école</label>
                    <input name="name" defaultValue={school.name} className="w-full rounded-lg border border-white/15 bg-white/10 px-2 py-1.5 text-xs text-white" />
                  </div>
                  <div>
                    <label className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-white/35">Pays</label>
                    <select name="country" defaultValue={school.country} className="w-full rounded-lg border border-white/15 bg-white/10 px-2 py-1.5 text-xs text-white">
                      {[...new Set([school.country, ...COUNTRIES])].filter(Boolean).map((country) => (
                        <option key={country} value={country} className="text-ink">{country}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-white/35">Ville</label>
                    <input name="city" defaultValue={school.city} className="w-full rounded-lg border border-white/15 bg-white/10 px-2 py-1.5 text-xs text-white" />
                  </div>
                  <div>
                    <label className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-white/35">Plan</label>
                    <select name="plan" defaultValue={school.plan} className="w-full rounded-lg border border-white/15 bg-white/10 px-2 py-1.5 text-xs text-white">
                      {PLANS.map((plan) => (
                        <option key={plan} value={plan} className="text-ink">{plan}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-white/35">Statut</label>
                    <select name="subscriptionStatus" defaultValue={school.subscriptionStatus} className="w-full rounded-lg border border-white/15 bg-white/10 px-2 py-1.5 text-xs text-white">
                      <option value="actif" className="text-ink">actif</option>
                      <option value="essai" className="text-ink">essai</option>
                      <option value="suspendu" className="text-ink">suspendu</option>
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-white/35">Licences</label>
                    <input name="seats" type="number" min={1} defaultValue={school.seats} className="w-full rounded-lg border border-white/15 bg-white/10 px-2 py-1.5 text-xs text-white" />
                  </div>
                  <div>
                    <label className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-white/35">Prix / mois</label>
                    <input name="monthlyPrice" type="number" min={0} step={5000} defaultValue={school.monthlyPrice} className="w-full rounded-lg border border-white/15 bg-white/10 px-2 py-1.5 text-xs text-white" />
                  </div>
                  <div>
                    <label className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-white/35">Échéance</label>
                    <input name="renewalDate" type="date" defaultValue={school.renewalDate ?? ""} className="w-full rounded-lg border border-white/15 bg-white/10 px-2 py-1.5 text-xs text-white" />
                  </div>
                  <div className="sm:col-span-3">
                    <SubmitButton className="btn bg-brand-500 text-white hover:bg-brand-400" pendingLabel="Mise à jour…">
                      <Save className="h-3.5 w-3.5" /> Enregistrer l&apos;abonnement
                    </SubmitButton>
                  </div>
                </form>
              </details>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-5">
            <h2 className="flex items-center gap-2 font-display text-sm font-semibold">
              <TrendingUp className="h-4 w-4 text-brand-300" /> Répartition des plans
            </h2>
            <div className="mt-4 space-y-3">
              {PLANS.map((plan) => {
                const count = schools.filter((s) => s.plan === plan).length;
                const revenue = schools.filter((s) => s.plan === plan).reduce((sum, s) => sum + s.monthlyPrice, 0);
                return (
                  <div key={plan}>
                    <div className="flex items-center justify-between text-[11px] font-semibold text-white/60">
                      <span>{plan} · {count} école(s)</span>
                      <span>{compactMoney(revenue)} F</span>
                    </div>
                    <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                      <div className="h-full rounded-full bg-brand-400" style={{ width: `${percent(revenue, Math.max(1, totals.mrr))}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-4 rounded-xl bg-black/20 p-3 text-[11px] leading-relaxed text-white/45">
              <p className="flex items-center gap-1.5 font-semibold text-white/70">
                <CalendarClock className="h-3.5 w-3.5" /> Renouvellements sous 30 jours
              </p>
              <ul className="mt-2 space-y-1">
                {schools
                  .filter((s) => s.renewalDate)
                  .slice(0, 4)
                  .map((s) => (
                    <li key={s.id} className="flex items-center justify-between gap-2">
                      <span className="truncate">{s.shortName} · {s.plan}</span>
                      <span>{formatDate(s.renewalDate)}</span>
                    </li>
                  ))}
              </ul>
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-5">
            <h2 className="flex items-center gap-2 font-display text-sm font-semibold">
              <LifeBuoy className="h-4 w-4 text-brand-300" /> Derniers mouvements écoles
            </h2>
            <div className="mt-3 space-y-2">
              {recentInvoices.map((invoice) => (
                <div key={invoice.id} className="rounded-xl bg-black/20 px-3 py-2">
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-xs font-semibold text-white/80">
                      {invoice.firstName} {invoice.lastName}
                    </p>
                    <span className="text-[10px] text-white/40">{money(invoice.amount)}</span>
                  </div>
                  <p className="truncate text-[10px] text-white/35">
                    {invoice.schoolName} {invoice.className ? `· ${invoice.className}` : ""} · {invoice.status}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-5">
            <h2 className="font-display text-sm font-semibold">Facturation Scolaris</h2>
            <dl className="mt-3 space-y-2 text-[11px]">
              <div className="flex items-center justify-between text-white/50">
                <dt>MRR</dt>
                <dd className="font-semibold text-white">{money(totals.mrr)}</dd>
              </div>
              <div className="flex items-center justify-between text-white/50">
                <dt>ARR projeté</dt>
                <dd className="font-semibold text-white">{money(totals.arr)}</dd>
              </div>
              <div className="flex items-center justify-between text-white/50">
                <dt>Écoles suspendues</dt>
                <dd className="font-semibold text-white">{totals.suspended}</dd>
              </div>
              <div className="flex items-center justify-between text-white/50">
                <dt>Utilisation licences</dt>
                <dd className="font-semibold text-white">{seatUsage}%</dd>
              </div>
            </dl>
            <Link href="/dashboard" className="btn mt-4 w-full bg-white text-ink hover:bg-white/90">
              Retour à l&apos;école
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}
