"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import {
  motion,
  AnimatePresence,
  useScroll,
  useTransform,
  useMotionValue,
  useSpring,
} from "framer-motion";
import {
  ArrowRight,
  BarChart3,
  Bell,
  CalendarCheck,
  Check,
  ClipboardList,
  FileText,
  GraduationCap,
  MessageSquare,
  Smartphone,
  Sparkles,
  TrendingUp,
  Users,
  Wallet,
  ChevronRight,
} from "lucide-react";

const HERO_IMAGE =
  "https://images.pexels.com/photos/34211747/pexels-photo-34211747.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1200";
const CLASS_IMAGE =
  "https://images.pexels.com/photos/25457343/pexels-photo-25457343.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=1000";

const FEATURES = [
  {
    icon: Users,
    title: "Inscriptions & dossiers",
    text: "Inscrivez un élève en 2 minutes : état civil, tuteurs, classe, frais générés automatiquement.",
  },
  {
    icon: Wallet,
    title: "Scolarité & paiements",
    text: "Mobile money, espèces, virement : chaque encaissement met à jour le solde et produit un reçu.",
  },
  {
    icon: Bell,
    title: "Relances automatiques",
    text: "Repérez les impayés et envoyez les rappels aux parents par SMS ou notification en un clic.",
  },
  {
    icon: CalendarCheck,
    title: "Présences & discipline",
    text: "L'appel en classe, les retards et les absences justifiées, visibles instantanément par la vie scolaire.",
  },
  {
    icon: ClipboardList,
    title: "Notes & bulletins",
    text: "Saisie des notes, moyennes pondérées, rangs et bulletins prêts à imprimer, sans aucune ressaisie.",
  },
  {
    icon: MessageSquare,
    title: "Communication parents",
    text: "Un canal unique pour les annonces, les réunions et les rappels de scolarité aux familles.",
  },
];

const ROLES = [
  "Directeur / promoteur",
  "Secrétariat / scolarité",
  "Comptable / économe",
  "Enseignant",
  "Surveillant / éducateur",
  "Parent / tuteur",
];

const PLANS = [
  {
    name: "Essentiel",
    price: "65 000",
    period: "FC / mois",
    detail: "Jusqu'à 150 élèves",
    features: ["Inscriptions & dossiers", "Scolarité et paiements", "Présences", "Bulletins PDF", "2 comptes staff"],
  },
  {
    name: "Pro",
    price: "135 000",
    period: "FC / mois",
    detail: "Jusqu'à 500 élèves",
    featured: true,
    features: [
      "Tout Essentiel",
      "Relances automatiques illimitées",
      "Communication SMS & notifications",
      "Rapports financiers",
      "Comptes staff illimités",
    ],
  },
  {
    name: "Groupe scolaire",
    price: "Sur devis",
    period: "",
    detail: "Plusieurs établissements",
    features: ["Multi-établissements", "Consolidation des tableaux de bord", "Accompagnement à la migration", "Support prioritaire"],
  },
];

const NAV_STATS = [
  { value: "-30 %", label: "de temps administratif" },
  { value: "0", label: "ressaisie pour les bulletins" },
  { value: "100 %", label: "accessible sur mobile" },
];

function FloatingBlob({
  x,
  y,
  delay,
  color,
  size = 400,
}: {
  x: string | number;
  y: string | number;
  delay: number;
  color: string;
  size?: string | number;
}) {
  return (
    <motion.div
      className="absolute rounded-full blur-[120px] mix-blend-overlay pointer-events-none"
      style={{
        left: x,
        top: y,
        width: size,
        height: size,
        backgroundColor: color,
        opacity: 0.45,
      }}
      initial={{ scale: 0.8, y: 20 }}
      animate={{
        scale: [0.8, 1.1, 0.8],
        y: [0, -16, 0],
      }}
      transition={{
        duration: 8,
        repeat: Infinity,
        ease: "easeInOut",
        delay,
      }}
    />
  );
}

export default function LandingPage() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const { scrollYProgress } = useScroll();
  const blur = useTransform(scrollYProgress, [0, 0.2], [0, 12]);
  const opacity = useTransform(scrollYProgress, [0, 0.1], [1, 0.4]);

  return (
    <div className="min-h-screen bg-sand relative overflow-hidden">
      {/* Fond animé */}
      <FloatingBlob x="-10%" y="-10%" delay={0} color="#48a47e" size={560} />
      <FloatingBlob x="85%" y="10%" delay={1.5} color="#e8a33d" size={520} />
      <FloatingBlob x="20%" y="75%" delay={3} color="#0e6e4f" size={480} />
      <FloatingBlob x="90%" y="80%" delay={4.5} color="#b3dbc7" size="440" />

      {/* Ligne de mouvement décorative sous le hero */}
      <svg className="absolute -bottom-2 left-0 w-full h-2.5 pointer-events-none" preserveAspectRatio="none">
        <path d="M2 5C60 2 140 2 298 5" stroke="#48a47e" strokeWidth={3} strokeLinecap="round" fill="none" />
      </svg>

      <header
        className={
          scrolled
            ? "sticky top-0 z-40 border-b border-ink/8 bg-sand/95 backdrop-blur-md shadow-sm"
            : "sticky top-0 z-40 border-b border-ink/8 bg-sand/85 backdrop-blur"
        }
      >
        <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-4 sm:px-6">
          <Link href="/" className="flex items-center gap-2.5">
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="grid h-9 w-9 place-items-center rounded-xl bg-brand-700 text-white"
            >
              <GraduationCap className="h-5 w-5" />
            </motion.div>
            <span className="font-display text-lg font-bold tracking-tight text-ink">Scolaris</span>
          </Link>
          <nav className={[
            "hidden items-center gap-7 text-sm font-medium text-ink/60 md:flex",
            scrolled ? "text-ink/50" : "",
          ].join(" ")}>
            <a href="#fonctionnalites" className="transition hover:text-ink">Fonctionnalités</a>
            <a href="#roles" className="transition hover:text-ink">Rôles</a>
            <a href="#tarifs" className="transition hover:text-ink">Tarifs</a>
          </nav>
          <div className="flex items-center gap-2">
            <Link href="/dashboard" className="btn-ghost hidden text-[13px] sm:inline-flex">Se connecter</Link>
            <motion.a
              href="/dashboard"
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              className="btn-primary text-[13px]"
            >
              Ouvrir la démo <ArrowRight className="h-4 w-4" />
            </motion.a>
          </div>
        </div>
      </header>

      <main>
        {/* Hero */}
        <section
          className="mx-auto grid w-full max-w-6xl items-center gap-12 px-4 pb-20 pt-14 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:pb-32 lg:pt-24"
        >
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="flex flex-col gap-6"
          >
            <motion.span
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-brand-50 px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.1em] text-brand-700"
            >
              <Sparkles className="h-3.5 w-3.5 animate-bounce" />
              SaaS pour écoles privées · République démocratique du Congo
            </motion.span>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="font-display text-[34px] font-bold leading-[1.08] tracking-tight text-ink sm:text-5xl lg:text-[60px]"
            >
              Toute votre école,
              <br />
              pilotée depuis
              <span className="relative ml-2 inline-block text-brand-700">
                un seul écran.
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="mt-6 max-w-xl text-base leading-relaxed text-ink/60 sm:text-[17px]"
            >
              Inscriptions, scolarité, paiements mobile money, présences, notes et bulletins : Scolaris remplace
              le papier, Excel et WhatsApp. Fini les impayés mal suivis et les bulletins recopiés à la main.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="mt-10 flex flex-wrap items-center gap-3"
            >
              <motion.a
                href="/dashboard"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="btn-primary px-5 py-3 text-sm"
              >
                Découvrir la plateforme <ArrowRight className="h-4 w-4" />
              </motion.a>
              <motion.a
                href="#fonctionnalites"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="btn-outline px-5 py-3 text-sm"
              >
                Voir les fonctionnalités
              </motion.a>
            </motion.div>

            <motion.dl
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1 }}
              className="mt-10 grid max-w-lg grid-cols-3 gap-4 border-t border-ink/10 pt-6"
            >
              {NAV_STATS.map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 1.2 + i * 0.1 }}
                >
                  <motion.span
                    whileHover={{ scale: 1.1 }}
                    className="font-display text-xl font-bold text-brand-700"
                  >
                    {stat.value}
                  </motion.span>
                  <dd className="mt-0.5 text-[11px] font-medium leading-tight text-ink/50">{stat.label}</dd>
                </motion.div>
              ))}
            </motion.dl>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.9 }}
            className="relative"
          >
            <motion.div
              className="absolute -left-6 -top-6 hidden h-24 w-24 rounded-3xl bg-brand-200/60 blur-2xl sm:block"
            />
            <motion.div
              className="relative overflow-hidden rounded-[28px] border border-white bg-white p-2 shadow-[0_40px_80px_-40px_rgba(16,32,27,0.5)]"
              whileHover={{ y: -4 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
            >
              <motion.img
                src={HERO_IMAGE}
                alt="Élèves en uniforme dans une salle de classe"
                className="h-[320px] w-full rounded-[22px] object-cover sm:h-[400px]"
                loading="lazy"
              />
              <motion.div
                className="absolute inset-x-6 bottom-6 rounded-2xl border border-white/60 bg-white/95 p-4 shadow-lg backdrop-blur"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.2 }}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-ink/40">Recouvrement scolarité</p>
                    <p className="mt-1 font-display text-2xl font-bold text-ink">82 %</p>
                  </div>
                  <span className="inline-flex items-center gap-1 rounded-full bg-brand-100 px-2.5 py-1 text-[11px] font-bold text-brand-800">
                    <TrendingUp className="h-3.5 w-3.5 animate-pulse" /> +12 pts
                  </span>
                </div>
                <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-ink/8">
                  <div className="h-full w-[82%] rounded-full bg-brand-500" />
                </div>
                <p className="mt-2 text-[11px] text-ink/50">4 350 000 FC recouvrés · 11 impayés suivis</p>
              </motion.div>
            </motion.div>
            <motion.div
              className="absolute -right-3 top-8 hidden rounded-2xl border border-ink/8 bg-white px-3.5 py-2.5 shadow-lg sm:block"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 1.4 }}
            >
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Bulletins</p>
              <p className="mt-0.5 flex items-center gap-1.5 text-xs font-semibold text-ink">
                <FileText className="h-3.5 w-3.5 text-brand-600" /> Générés en 1 clic
              </p>
            </motion.div>
            <motion.div
              className="absolute -left-4 bottom-24 hidden rounded-2xl border border-ink/8 bg-white px-3.5 py-2.5 shadow-lg sm:block"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 1.6 }}
            >
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Paiement reçu</p>
              <p className="mt-0.5 text-xs font-semibold text-ink">75 000 FC · M-Pesa</p>
            </motion.div>
          </motion.div>
        </section>

        {/* Bandeau problèmes */}
        <section className="border-y border-ink/8 bg-white">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="mx-auto grid w-full max-w-6xl gap-6 px-4 py-12 sm:px-6 md:grid-cols-3"
          >
            {[
              { icon: Smartphone, title: "Pensé mobile first", text: "Les parents paient et suivent depuis leur téléphone." },
              { icon: BarChart3, title: "Pilotage en temps réel", text: "Effectifs, trésorerie et résultats sous les yeux du directeur." },
              { icon: FileText, title: "Bulletins sans ressaisie", text: "Les notes saisies une fois alimentent tous les documents." },
            ].map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15, duration: 0.6 }}
                whileHover={{ y: -4 }}
                className="flex items-start gap-3 transition"
              >
                <motion.div
                  whileHover={{ scale: 1.1 }}
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-700"
                >
                  <item.icon className="h-5 w-5" strokeWidth={1.8} />
                </motion.div>
                <div>
                  <p className="text-sm font-semibold text-ink">{item.title}</p>
                  <p className="mt-0.5 text-sm text-ink/55">{item.text}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </section>

        {/* Fonctionnalités */}
        <section id="fonctionnalites" className="mx-auto w-full max-w-6xl px-4 py-16 sm:px-6 lg:py-28">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-2xl mb-12"
          >
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-[11px] font-bold uppercase tracking-[0.14em] text-brand-600"
            >
              Le MVP, déjà complet
            </motion.p>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="mt-2 font-display text-3xl font-bold tracking-tight text-ink sm:text-4xl"
            >
              Six modules pour couvrir toute l'année scolaire
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="mt-3 text-base text-ink/55"
            >
              Du dossier d'inscription au bulletin de fin de trimestre, tout se tient : les données saisies une
              fois sont réutilisées partout.
            </motion.p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
          >
            {FEATURES.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.12, duration: 0.6 }}
                whileHover={{ y: -6 }}
                className="group rounded-2xl border border-ink/8 bg-white p-5 transition hover:-translate-y-1 hover:border-brand-200 hover:shadow-lg"
              >
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  className="grid h-10 w-10 place-items-center rounded-xl bg-brand-50 text-brand-700 transition group-hover:bg-brand-700 group-hover:text-white"
                >
                  <feature.icon className="h-5 w-5" strokeWidth={1.8} />
                </motion.div>
                <motion.h3
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="mt-4 font-display text-base font-semibold text-ink"
                >
                  {feature.title}
                </motion.h3>
                <motion.p
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="mt-1.5 text-sm leading-relaxed text-ink/55"
                >
                  {feature.text}
                </motion.p>
              </motion.div>
            ))}
          </motion.div>
        </section>

        {/* Aperçu produit */}
        <section className="mx-auto w-full max-w-6xl px-4 pb-24 sm:px-6 lg:pb-32">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="overflow-hidden rounded-[28px] bg-brand-900 p-6 sm:p-10"
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid items-center gap-12 lg:grid-cols-[0.9fr_1.1fr]"
            >
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-4"
              >
                <motion.p
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="text-[11px] font-bold uppercase tracking-[0.14em] text-brand-300"
                >
                  Vue directeur
                </motion.p>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="font-display text-2xl font-bold leading-tight text-white sm:text-3xl"
                >
                  Les bonnes décisions, sans attendre la fin du mois
                </motion.h2>
                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="mt-3 text-sm leading-relaxed text-brand-100/80 max-w-xs"
                >
                  Un tableau de bord unique pour repérer les impayés, suivre l'assiduité et vérifier la santé
                  financière avant qu'il ne soit trop tard.
                </motion.p>
                <motion.ul
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="mt-6 space-y-3"
                >
                  {[
                    "Encaissements des 6 derniers mois",
                    "Répartition des factures par statut",
                    "Relances à faire, classées par solde",
                    "Assiduité et effectifs par classe",
                    "Bulletins scannés et documents des élèves",
                    "Portail parents et console multi-écoles",
                  ].map((line, i) => (
                    <motion.li
                      key={line}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.5 + i * 0.08 }}
                      className="flex items-center gap-2.5 text-sm text-white/85"
                    >
                      <span className="grid h-5 w-5 place-items-center rounded-full bg-brand-500/30">
                        <Check className="h-3 w-3 text-brand-200" />
                      </span>
                      {line}
                    </motion.li>
                  ))}
                </motion.ul>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 40 }}
                animate={{ opacity: 1, x: 0 }}
                className="rounded-2xl bg-sand p-4 shadow-2xl"
              >
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center justify-between"
                >
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Tableau de bord</p>
                    <p className="font-display text-sm font-semibold text-ink">Complexe Scolaire Les Palmiers</p>
                  </div>
                  <span className="rounded-full bg-white px-2.5 py-1 text-[10px] font-bold text-ink/50">2026-2027</span>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="mt-3 grid grid-cols-3 gap-2"
                >
                  {[
                    { label: "Élèves", value: "110" },
                    { label: "Encaissé", value: "32 M" },
                    { label: "Impayés", value: "11 M" },
                  ].map((kpi, i) => (
                    <motion.div
                      key={kpi.label}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 + i * 0.1 }}
                      className="rounded-xl bg-white p-3"
                    >
                      <p className="text-[9px] font-bold uppercase tracking-wide text-ink/40">{kpi.label}</p>
                      <p className="mt-1 font-display text-sm font-bold text-ink">{kpi.value}</p>
                    </motion.div>
                  ))}
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="mt-2 rounded-xl bg-white p-4"
                >
                  <p className="text-[10px] font-bold uppercase tracking-wide text-ink/40">Encaissements</p>
                  <div className="mt-3 flex h-24 items-end gap-2">
                    {[42, 58, 47, 72, 63, 88].map((h, i) => (
                      <motion.div
                        key={i}
                        initial={{ height: "30%" }}
                        animate={{ height: `${h}%` }}
                        transition={{ delay: 0.4 + i * 0.08, duration: 0.8 }}
                        className="flex-1 rounded-t-md bg-gradient-to-t from-brand-700 to-brand-400"
                      />
                    ))}
                  </div>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="mt-2 space-y-1.5"
                >
                  {[
                    { name: "Kabongo Grâce", amount: "135 000 FC" },
                    { name: "Ilunga Junior", amount: "95 000 FC" },
                  ].map((row, i) => (
                    <motion.div
                      key={row.name}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.6 + i * 0.1 }}
                      className="flex items-center justify-between rounded-xl bg-white px-3 py-2"
                    >
                      <span className="flex items-center gap-2 text-[11px] font-semibold text-ink/70">
                        <span className="grid h-5 w-5 place-items-center rounded-full bg-amber-100 text-[8px] font-bold text-amber-700">
                          {row.name.charAt(0)}
                        </span>
                        {row.name}
                      </span>
                      <span className="text-[11px] font-bold text-red-600">{row.amount}</span>
                    </motion.div>
                  ))}
                </motion.div>
              </motion.div>
            </motion.div>
          </motion.div>
        </section>

        {/* Rôles */}
        <section id="roles" className="border-y border-ink/8 bg-white">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mx-auto grid w-full max-w-6xl gap-12 px-4 py-20 sm:px-6 lg:grid-cols-[0.85fr_1.15fr] lg:py-24"
          >
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-4"
            >
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-[11px] font-bold uppercase tracking-[0.14em] text-brand-600"
              >
                Une plateforme, plusieurs métiers
              </motion.p>
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="font-display text-3xl font-bold tracking-tight text-ink"
              >
                Chacun voit ce qui le concerne
              </motion.h2>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="mt-3 text-sm leading-relaxed text-ink/55 max-w-md"
              >
                Les accès sont cloisonnés par rôle : le comptable ne gère pas les notes, l'enseignant ne voit pas la
                trésorerie. Le directeur garde la vue d'ensemble.
              </motion.p>
              <motion.img
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4 }}
                src={CLASS_IMAGE}
                alt="Classe d'école primaire"
                className="mt-6 hidden h-44 w-full rounded-2xl object-cover lg:block"
              />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="grid gap-3 sm:grid-cols-2"
            >
              {ROLES.map((role, i) => (
                <motion.div
                  key={role}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ x: 4 }}
                  className="flex items-center gap-3 rounded-xl border border-ink/8 bg-sand/50 px-4 py-3 transition"
                >
                  <motion.div
                    whileHover={{ scale: 1.2 }}
                    className="grid h-8 w-8 place-items-center rounded-lg bg-white text-brand-700 shadow-sm"
                  >
                    <Users className="h-4 w-4" strokeWidth={1.8} />
                  </motion.div>
                  <span className="text-sm font-semibold text-ink/75">{role}</span>
                </motion.div>
              ))}
              <motion.div
                key="parents"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: ROLES.length * 0.1 }}
                className="rounded-xl border border-dashed border-brand-300 bg-brand-50 px-4 py-3"
              >
                <p className="text-xs font-semibold text-brand-800">Portail parents — V2</p>
                <p className="mt-0.5 text-[11px] text-brand-700/70">Suivi, paiement en ligne et messagerie directe.</p>
              </motion.div>
            </motion.div>
          </motion.div>
        </section>

        {/* Tarifs */}
        <section id="tarifs" className="mx-auto w-full max-w-6xl px-4 py-16 sm:px-6 lg:py-28">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mx-auto max-w-2xl text-center"
          >
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-[11px] font-bold uppercase tracking-[0.14em] text-brand-600"
            >
              Tarifs simples
            </motion.p>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="mt-2 font-display text-3xl font-bold tracking-tight text-ink sm:text-4xl"
            >
              Un abonnement par établissement
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="mt-3 text-sm text-ink/55"
            >
              Sans frais de mise en service. Paiement mensuel, résiliable. Les prix sont indiqués en francs congolais (FC).
            </motion.p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-10 grid gap-4 lg:grid-cols-3"
          >
            {PLANS.map((plan, i) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.12, duration: 0.6 }}
                whileHover={{ y: -6 }}
                className={`relative rounded-2xl border p-6 ${
                  plan.featured ? "border-brand-700 bg-brand-900 text-white shadow-xl" : "border-ink/10 bg-white"
                }`}
              >
                {plan.featured ? (
                  <motion.span
                    whileHover={{ scale: 1.1 }}
                    className="absolute -top-3 left-6 rounded-full bg-amber-brand px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-ink"
                  >
                    Le plus choisi
                  </motion.span>
                ) : null}
                <motion.p
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className={`text-sm font-semibold ${plan.featured ? "text-brand-200" : "text-ink/60"}`}>
                  {plan.name}
                </motion.p>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="mt-2 flex items-baseline gap-1"
                >
                  <span className="font-display text-3xl font-bold">{plan.price}</span>
                  <span className={`text-sm ${plan.featured ? "text-white/60" : "text-ink/45"}`}>{plan.period}</span>
                </motion.div>
                <motion.p
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className={`mt-1 text-xs ${plan.featured ? "text-white/60" : "text-ink/45"}`}>
                  {plan.detail}
                </motion.p>
                <Link
                  href="/dashboard"
                  className={`mt-5 w-full ${plan.featured ? "btn bg-white text-brand-900 hover:bg-brand-50" : "btn-outline"}`}
                >
                  Ouvrir la démo
                </Link>
                <ul className="mt-6 space-y-2.5">
                  {plan.features.map((feature, j) => (
                    <motion.li
                      key={feature}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.5 + j * 0.08 }}
                      className={`flex items-center gap-2 text-sm ${plan.featured ? "text-white/85" : "text-ink/65"}`}>
                      <Check className={`h-4 w-4 ${plan.featured ? "text-brand-300" : "text-brand-600"}`} />
                      {feature}
                    </motion.li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </motion.div>
        </section>

        {/* CTA */}
        <section className="mx-auto w-full max-w-6xl px-4 pb-24 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex flex-col items-start justify-between gap-6 rounded-[28px] bg-gradient-to-br from-brand-800 to-brand-600 px-6 py-10 text-white sm:flex-row sm:items-center sm:px-10"
          >
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-2"
            >
              <motion.h2
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="font-display text-2xl font-bold tracking-tight sm:text-3xl">
                Prêt à faire passer votre école au digital ?
              </motion.h2>
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="mt-2 max-w-xl text-sm text-white/75">
                Explorez la démo complète avec 110 élèves, 8 classes et 300 factures déjà en place. Aucun compte à créer.
              </motion.p>
            </motion.div>
            <motion.a
              href="/dashboard"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="btn bg-white px-5 py-3 text-brand-900 hover:bg-brand-50"
            >
              Entrer dans la démo <ArrowRight className="h-4 w-4" />
            </motion.a>
          </motion.div>
        </section>
      </main>

      <footer className="border-t border-ink/8 bg-white">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mx-auto flex w-full max-w-6xl flex-col gap-4 px-4 py-10 sm:flex-row sm:items-center sm:justify-between sm:px-6"
        >
          <div className="flex items-center gap-2.5">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand-700 text-white">
              <GraduationCap className="h-4 w-4" />
            </span>
            <div>
              <p className="font-display text-sm font-bold text-ink">Scolaris</p>
              <p className="text-[11px] text-ink/45">Cahier des charges v1.0 · Daniel · 23 octobre 2026</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-4 text-[11px] text-ink/45">
            <Link href="/parents" className="font-semibold text-brand-700 hover:underline">Portail parents</Link>
            <Link href="/plateforme" className="font-semibold text-brand-700 hover:underline">Console plateforme</Link>
            <span>Kinshasa, République démocratique du Congo · Démonstration produit</span>
          </div>
        </motion.div>
      </footer>
    </div>
  );
}
