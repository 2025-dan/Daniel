// Seed script — node scripts/seed.mjs
// Idempotent: vide les tables puis insère un jeu de données de démonstration complet.
import { Client } from "pg";
import { readFileSync } from "node:fs";

const env = readFileSync(new URL("../.env", import.meta.url), "utf8");
const databaseUrl =
  env.match(/^DATABASE_URL=(.*)$/m)?.[1]?.trim() ??
  "postgresql://postgres:postgres@127.0.0.1:5432/app_db";

const client = new Client({ connectionString: databaseUrl });

let seed = 20261023;
function rnd() {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
const pick = (arr) => arr[Math.floor(rnd() * arr.length)];
const int = (min, max) => Math.floor(rnd() * (max - min + 1)) + min;
const chance = (p) => rnd() < p;

const today = new Date();
today.setHours(12, 0, 0, 0);
const iso = (d) => d.toISOString().slice(0, 10);
const shift = (days) => {
  const d = new Date(today);
  d.setDate(d.getDate() + days);
  return iso(d);
};

const FIRST_M = [
  "Patrick", "Dieumerci", "Glody", "Junior", "Jonathan", "Emmanuel", "Christian", "Blaise", "Serge",
  "Franck", "Olivier", "Trésor", "Kevin", "Israël", "Prince", "Ange", "David", "Yannick", "Wilfried",
  "Béni", "Josué", "Éric", "Héritier", "Bonheur", "Gédéon", "Merveil", "Elie", "Pascal", "Aristote",
];
const FIRST_F = [
  "Grâce", "Esther", "Sarah", "Bénédicte", "Christelle", "Prisca", "Naomi", "Rebecca", "Léa",
  "Emmanuella", "Yasmine", "Séraphine", "Danielle", "Ornella", "Mireille", "Félicité", "Gloria",
  "Divine", "Merveille", "Béatrice", "Céline", "Nadine", "Rachel", "Sylvie", "Plamedi", "Bénie",
  "Chantal", "Anuarite", "Kavira", "Mireille",
];
const LAST = [
  "Mbala", "Ilunga", "Tshibangu", "Kasongo", "Mwamba", "Nsimba", "Bakala", "Lokole", "Ngoy",
  "Mulumba", "Kabongo", "Mbuyi", "Kalala", "Lukusa", "Mukendi", "Badibanga", "Nzuzi", "Mavungu",
  "Bofassa", "Kanku", "Mutombo", "Ngalula", "Tshiala", "Mputu", "Bokungu", "Kayembe", "Lumbala",
  "Nkashama", "Mwena", "Kibwe",
];
const PROFESSIONS = [
  "Commerçante", "Enseignant", "Infirmière", "Chauffeur", "Fonctionnaire", "Couturière",
  "Entrepreneur", "Mécanicien", "Agent bancaire", "Ménagère", "Ingénieur", "Pharmacienne",
];

const CLASSES = [
  { name: "Maternelle A", level: "Maternelle", cycle: "Maternelle", capacity: 30, room: "Bât. A1", teacher: "Mme Chantal Bofassa", fee: 55000, pupils: 6 },
  { name: "1ère Primaire", level: "1ère Primaire", cycle: "Primaire", capacity: 45, room: "Bât. A2", teacher: "M. Patrick Ngoy", fee: 65000, pupils: 8 },
  { name: "4ème Primaire", level: "4ème Primaire", cycle: "Primaire", capacity: 45, room: "Bât. B1", teacher: "Mme Merveille Kasongo", fee: 70000, pupils: 8 },
  { name: "6ème Primaire", level: "6ème Primaire", cycle: "Primaire", capacity: 45, room: "Bât. B2", teacher: "M. Dieumerci Mukendi", fee: 75000, pupils: 8 },
  { name: "7ème Éducation de base", level: "7ème Éducation de base", cycle: "Éducation de base", capacity: 50, room: "Bât. C1", teacher: "M. Éric Tshibangu", fee: 95000, pupils: 7 },
  { name: "8ème Éducation de base", level: "8ème Éducation de base", cycle: "Éducation de base", capacity: 50, room: "Bât. C2", teacher: "Mme Gloria Ilunga", fee: 95000, pupils: 7 },
  { name: "1ère Humanités", level: "1ère Humanités", cycle: "Humanités", capacity: 50, room: "Bât. D1", teacher: "M. Glody Mwamba", fee: 125000, pupils: 7 },
  { name: "3ème Humanités", level: "3ème Humanités", cycle: "Humanités", capacity: 50, room: "Bât. D2", teacher: "Mme Prisca Nsimba", fee: 135000, pupils: 6 },
];

const SUBJECTS = [
  { name: "Mathématiques", code: "MATH", cycle: "Primaire", coef: 3, teacher: "M. Dieumerci Mukendi" },
  { name: "Français", code: "FRA", cycle: "Primaire", coef: 3, teacher: "Mme Merveille Kasongo" },
  { name: "Anglais", code: "ANG", cycle: "Primaire", coef: 2, teacher: "M. James Brown" },
  { name: "Sciences & SVT", code: "SVT", cycle: "Primaire", coef: 2, teacher: "Mme Prisca Nsimba" },
  { name: "Histoire-Géographie", code: "HG", cycle: "Éducation de base", coef: 2, teacher: "M. Éric Tshibangu" },
  { name: "Éducation civique et morale", code: "ECM", cycle: "Éducation de base", coef: 1, teacher: "Mme Chantal Bofassa" },
  { name: "Informatique", code: "INFO", cycle: "Humanités", coef: 1, teacher: "M. Patrick Ngoy" },
  { name: "Éveil & Motricité", code: "EVE", cycle: "Maternelle", coef: 2, teacher: "Mme Chantal Bofassa" },
  { name: "Philosophie", code: "PHILO", cycle: "Humanités", coef: 2, teacher: "M. Glody Mwamba" },
];

const TERMS = ["Trimestre 1", "Trimestre 2"];

function appreciationFor(avg) {
  if (avg >= 16) return "Excellent travail, continue ainsi.";
  if (avg >= 14) return "Très bons résultats, félicitations.";
  if (avg >= 12) return "Ensemble satisfaisant, peut mieux faire.";
  if (avg >= 10) return "Résultats passables, plus de rigueur.";
  return "Résultats insuffisants, soutien nécessaire.";
}

async function main() {
  await client.connect();
  console.log("→ connexion établie");

  await client.query(`TRUNCATE TABLE
    payrolls, staff, timetable_slots, lesson_logs, exams,
    reminders, messages, attendance, grades, assessments, subjects,
    payments, invoices, fee_structures, enrollments, guardians, students,
    classes, academic_years, schools
    RESTART IDENTITY CASCADE`);

  const school = (
    await client.query(
      `INSERT INTO schools (name, short_name, city, country, phone, email, address, motto, currency, director_name, plan, subscription_status, seats, monthly_price, renewal_date)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'Groupe','actif',500,285000,'2027-01-05') RETURNING id`,
      [
        "Complexe Scolaire Les Palmiers",
        "CSLP",
        "Kinshasa",
        "République démocratique du Congo",
        "+243 81 245 78 90",
        "contact@lespalmiers.cd",
        "Avenue de la Libération n°45, Gombe, Kinshasa",
        "Excellence · Discipline · Espérance",
        "FC",
        "M. Patrice Ilunga",
      ],
    )
  ).rows[0].id;

  const year = (
    await client.query(
      `INSERT INTO academic_years (school_id, label, start_date, end_date, is_current)
       VALUES ($1,$2,$3,$4,true) RETURNING id`,
      [school, "2026-2027", "2026-09-14", "2027-07-03"],
    )
  ).rows[0].id;

  const classIds = [];
  for (const c of CLASSES) {
    const row = await client.query(
      `INSERT INTO classes (school_id, academic_year_id, name, level, cycle, capacity, room, main_teacher, monthly_fee)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
      [school, year, c.name, c.level, c.cycle, c.capacity, c.room, c.teacher, c.fee],
    );
    classIds.push({ ...c, id: row.rows[0].id });
  }

  const subjectIds = [];
  for (const s of SUBJECTS) {
    const row = await client.query(
      `INSERT INTO subjects (school_id, name, code, cycle, coefficient, teacher)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
      [school, s.name, s.code, s.cycle, s.coef, s.teacher],
    );
    subjectIds.push({ ...s, id: row.rows[0].id });
  }

  for (const level of CLASSES.map((c) => c.level)) {
    await client.query(
      `INSERT INTO fee_structures (school_id, academic_year_id, level, label, amount, type, due_date)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [school, year, level, "Frais d'inscription", 35000, "inscription", "2026-09-20"],
    );
    const fee = CLASSES.find((c) => c.level === level).fee;
    await client.query(
      `INSERT INTO fee_structures (school_id, academic_year_id, level, label, amount, type, due_date)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [school, year, level, "Scolarité annuelle (3 versements)", fee * 9, "scolarité", "2026-10-05"],
    );
  }

  let matriculeNo = 1;
  let invoiceNo = 1;
  const students = [];

  for (const cls of classIds) {
    for (let i = 0; i < cls.pupils; i++) {
      const gender = chance(0.52) ? "F" : "M";
      const firstName = pick(gender === "F" ? FIRST_F : FIRST_M);
      const lastName = pick(LAST).toUpperCase();
      const matricule = `GSLP-2026-${String(matriculeNo++).padStart(3, "0")}`;
      const birthYear = 2026 - (cls.cycle === "Maternelle" ? 4 : cls.cycle === "Collège" ? 12 : 8) - int(0, 2);
      const status = chance(0.04) ? "suspendu" : "actif";

      const st = await client.query(
        `INSERT INTO students (school_id, matricule, first_name, last_name, gender, birth_date, birth_place, status, address, blood_group, notes, enrolled_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
        [
          school,
          matricule,
          firstName,
          lastName,
          gender,
          `${birthYear}-${String(int(1, 12)).padStart(2, "0")}-${String(int(1, 27)).padStart(2, "0")}`,
          pick(["Kinshasa", "Lubumbashi", "Goma", "Bukavu", "Kisangani", "Mbuji-Mayi", "Matadi", "Kolwezi"]),
          status,
          `${pick(["Gombe", "Lemba", "Ngaliema", "Limete", "Masina", "Kintambo", "Bandalungwa"])}, Kinshasa`,
          pick(["", "", "O+", "A+", "B+", "AB+", "O-"]),
          "",
          shift(-int(40, 120)),
        ],
      );
      const studentId = st.rows[0].id;
      students.push({ id: studentId, classId: cls.id, classFee: cls.fee, firstName, lastName, matricule });

      const guardianLast = lastName === pick(LAST).toUpperCase() ? lastName : lastName;
      const fatherFirst = pick(FIRST_M);
      await client.query(
        `INSERT INTO guardians (student_id, full_name, relation, phone, email, profession, is_primary)
         VALUES ($1,$2,$3,$4,$5,$6,true)`,
        [
          studentId,
          `${fatherFirst} ${guardianLast}`,
          pick(["Père", "Mère", "Tuteur"]),
          `+243 8${int(1, 9)} ${int(100, 999)} ${int(100, 999)}`,
          `${fatherFirst.toLowerCase().replace(/[^a-z]/g, "")}.${lastName.toLowerCase().replace(/[^a-z]/g, "")}@mail.ci`,
          pick(PROFESSIONS),
        ],
      );
      await client.query(
        `INSERT INTO guardians (student_id, full_name, relation, phone, email, profession, is_primary)
         VALUES ($1,$2,$3,$4,$5,$6,false)`,
        [
          studentId,
          `${pick(FIRST_F)} ${guardianLast}`,
          "Mère",
          `+243 8${int(1, 9)} ${int(100, 999)} ${int(100, 999)}`,
          "",
          pick(PROFESSIONS),
        ],
      );

      await client.query(
        `INSERT INTO enrollments (student_id, class_id, academic_year_id, status, tuition_amount, registered_at)
         VALUES ($1,$2,$3,$4,$5,$6)`,
        [studentId, cls.id, year, chance(0.15) ? "réinscrit" : "inscrit", cls.fee * 9, shift(-int(40, 120))],
      );

      const plans = [
        { label: "Frais d'inscription 2026-2027", amount: 35000, due: shift(-70), payProb: 0.93 },
        { label: "Scolarité — 1er versement", amount: cls.fee * 3, due: shift(-48), payProb: 0.84 },
        { label: "Scolarité — 2e versement", amount: cls.fee * 3, due: shift(-16), payProb: 0.64 },
        { label: "Scolarité — 3e versement", amount: cls.fee * 3, due: shift(22), payProb: 0.28 },
      ];
      if (chance(0.45)) {
        plans.push({ label: "Cantine — Trimestre 1", amount: 45000, due: shift(-9), payProb: 0.55 });
      }

      for (const plan of plans) {
        const number = `FAC-2026-${String(invoiceNo++).padStart(4, "0")}`;
        let paid = 0;
        if (chance(plan.payProb)) paid = plan.amount;
        else if (chance(0.4)) paid = Math.round((plan.amount * int(20, 70)) / 100 / 500) * 500;
        const status = paid >= plan.amount ? "payée" : paid > 0 ? "partielle" : plan.due < shift(0) ? "impayée" : "à venir";
        const inv = await client.query(
          `INSERT INTO invoices (school_id, student_id, number, label, amount, amount_paid, due_date, status)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
          [school, studentId, number, plan.label, plan.amount, paid, plan.due, status === "à venir" ? "impayée" : status],
        );
        if (paid > 0) {
          await client.query(
            `INSERT INTO payments (school_id, invoice_id, student_id, amount, method, reference, paid_at, recorded_by)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
            [
              school,
              inv.rows[0].id,
              studentId,
              paid,
              pick(["mobile money", "mobile money", "espèces", "espèces", "virement", "chèque"]),
              `${pick(["OM", "WV", "MM", "CSH"])}-${int(100000, 999999)}`,
              shift(-int(0, 60)),
              pick(["Mme Awa Coulibaly", "M. Serge Ehouman", "Comptabilité"]),
            ],
          );
        }
      }
    }
  }

  // Présences — 14 derniers jours ouvrés
  const attendanceDays = [];
  let cursor = new Date(today);
  while (attendanceDays.length < 14) {
    const day = cursor.getDay();
    if (day !== 0 && day !== 6) attendanceDays.push(iso(cursor));
    cursor.setDate(cursor.getDate() - 1);
  }
  for (const date of attendanceDays) {
    for (const st of students) {
      const r = rnd();
      const status = r < 0.88 ? "présent" : r < 0.93 ? "absent" : r < 0.975 ? "retard" : "excusé";
      await client.query(
        `INSERT INTO attendance (student_id, class_id, date, status, note, recorded_by)
         VALUES ($1,$2,$3,$4,$5,$6)`,
        [studentIdSafe(st.id), st.classId, date, status, "", "Vie scolaire"],
      );
    }
  }

  // Évaluations et notes
  for (const cls of classIds) {
    const relevant = subjectIds.filter((s) =>
      cls.cycle === "Maternelle" ? s.code === "EVE" || s.code === "FRA" || s.code === "MATH" : cls.cycle === "Collège" ? true : s.cycle !== "Maternelle" && s.code !== "HG" && s.code !== "ECM" && s.code !== "INFO",
    );
    const pupils = students.filter((s) => s.classId === cls.id);
    for (const subject of relevant) {
      for (const term of TERMS) {
        const titles = term === "Trimestre 1" ? ["Devoir surveillé", "Composition"] : ["Interrogation écrite", "Devoir surveillé"];
        for (let k = 0; k < titles.length; k++) {
          const a = await client.query(
            `INSERT INTO assessments (class_id, subject_id, academic_year_id, term, title, max_score, coefficient, date)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
            [
              cls.id,
              subject.id,
              year,
              term,
              titles[k],
              20,
              k === 1 ? 2 : 1,
              term === "Trimestre 1" ? shift(-int(35, 60)) : shift(-int(5, 30)),
            ],
          );
          const base = int(8, 14);
          for (const pupil of pupils) {
            const score = Math.min(20, Math.max(2, Math.round((base + (rnd() * 9 - 3)) * 4) / 4));
            await client.query(
              `INSERT INTO grades (assessment_id, student_id, score, remark) VALUES ($1,$2,$3,$4)`,
              [a.rows[0].id, pupil.id, score, ""],
            );
          }
        }
      }
    }
  }

  // Relances
  const unpaid = await client.query(
    `SELECT id, student_id FROM invoices WHERE status IN ('impayée','partielle') ORDER BY due_date ASC LIMIT 6`,
  );
  for (const inv of unpaid.rows) {
    await client.query(
      `INSERT INTO reminders (invoice_id, student_id, channel, message, sent_at)
       VALUES ($1,$2,$3,$4, now() - ($5 || ' days')::interval)`,
      [inv.id, inv.student_id, pick(["sms", "email", "app"]), "Rappel de scolarité envoyé au tuteur.", int(1, 20)],
    );
  }

  // Messages
  const msgs = [
    {
      audience: "tous",
      classId: null,
      studentId: null,
      recipient: "Tous les parents",
      channel: "sms",
      subject: "Réunion de rentrée",
      body: "Chers parents, la réunion de rentrée se tiendra samedi à 9h dans la cour de l'établissement. Votre présence est vivement souhaitée.",
      days: 12,
      count: 44,
    },
    {
      audience: "classe",
      classId: classIds[3].id,
      studentId: null,
      recipient: "Parents — CM2 A",
      channel: "email",
      subject: "Préparation du BEPC blanc",
      body: "Un BEPC blanc est organisé du 24 au 26. Les élèves doivent se présenter à 7h30 munis de leur convocation.",
      days: 6,
      count: 8,
    },
    {
      audience: "tous",
      classId: null,
      studentId: null,
      recipient: "Tous les parents",
      channel: "app",
      subject: "Paiement mobile disponible",
      body: "Vous pouvez désormais régler la scolarité par M-Pesa, Orange Money et Airtel Money depuis la plateforme. Un reçu est généré automatiquement.",
      days: 3,
      count: 44,
    },
    {
      audience: "classe",
      classId: classIds[1].id,
      studentId: null,
      recipient: "Parents — CP A",
      channel: "sms",
      subject: "Sortie pédagogique au Zoo d'Abidjan",
      body: "Sortie pédagogique vendredi. Prévoir un pique-nique, une casquette et la participation de 2 000 FCFA.",
      days: 1,
      count: 8,
    },
  ];
  for (const m of msgs) {
    await client.query(
      `INSERT INTO messages (school_id, audience, class_id, student_id, recipient_label, channel, subject, body, status, recipients_count, sent_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'envoyé',$9, now() - ($10 || ' days')::interval)`,
      [school, m.audience, m.classId, m.studentId, m.recipient, m.channel, m.subject, m.body, m.count, m.days],
    );
  }
  await client.query(
    `INSERT INTO messages (school_id, audience, recipient_label, channel, subject, body, status, recipients_count, sent_at)
     VALUES ($1,'tous',$2,'sms',$3,$4,'brouillon',0, now())`,
    [
      school,
      "Tous les parents",
      "Rentrée du 2e trimestre",
      "La rentrée du deuxième trimestre est fixée au lundi 5 janvier. Les emplois du temps seront publiés sur la plateforme.",
    ],
  );


  /* ---------------- Personnel & paie ---------------- */
  const STAFF = [
    ["Patrice", "Ilunga", "Directeur", "direction", "Master en gestion scolaire", 1250000],
    ["Blaise", "Mukendi", "Comptable", "administration", "Licence en comptabilité", 750000],
    ["Merveille", "Kasongo", "Enseignante 4ème Primaire", "enseignement", "Licence en pédagogie", 620000],
    ["Dieumerci", "Mukendi", "Enseignant 6ème Primaire", "enseignement", "Licence en mathématiques", 650000],
    ["Prisca", "Nsimba", "Professeure de SVT", "enseignement", "Licence en biologie", 610000],
    ["Éric", "Tshibangu", "Professeur d'Histoire-Géo", "enseignement", "Licence en histoire", 610000],
    ["Chantal", "Bofassa", "Éducatrice Maternelle", "enseignement", "Graduat en pédagogie", 520000],
    ["James", "Brown", "Professeur d'Anglais", "enseignement", "Licence en langues", 580000],
    ["Gloria", "Ilunga", "Enseignante 8ème Éducation de base", "enseignement", "Licence en lettres", 640000],
    ["Glody", "Mwamba", "Professeur de Philosophie", "enseignement", "Licence en philosophie", 660000],
    ["Nadine", "Kanku", "Secrétaire de scolarité", "administration", "Graduat en secrétariat", 480000],
    ["Patrick", "Ngoy", "Surveillant général", "surveillance", "Graduat", 450000],
    ["Séraphine", "Mutombo", "Éducatrice de la petite enfance", "surveillance", "CAP", 380000],
    ["Mireille", "Lumbala", "Agent d'entretien", "support", "—", 280000],
  ];
  const staffIds = [];
  for (const [firstName, lastName, jobTitle, category, qualification, salary] of STAFF) {
    const row = await client.query(
      `INSERT INTO staff (school_id, first_name, last_name, job_title, category, phone, email, qualification, hire_date, monthly_salary, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
      [
        school,
        firstName,
        lastName,
        jobTitle,
        category,
        `+243 8${int(1, 9)} ${int(100, 999)} ${int(100, 999)}`,
        `${firstName.toLowerCase().replace(/[^a-z]/g, "")}.${lastName.toLowerCase().replace(/[^a-z]/g, "")}@lespalmiers.cd`,
        qualification,
        `${2026 - int(1, 8)}-09-01`,
        salary,
        chance(0.08) ? "congé" : "actif",
      ],
    );
    staffIds.push({ id: row.rows[0].id, salary });
  }
  const periodOf = (offset) => {
    const d = new Date(today.getFullYear(), today.getMonth() + offset, 1);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  };
  for (const offset of [-2, -1, 0]) {
    const period = periodOf(offset);
    for (const member of staffIds) {
      const bonuses = offset < 0 ? int(0, 2) * 25000 : 0;
      const deductions = Math.round(member.salary * 0.0575);
      const net = member.salary + bonuses - deductions;
      const paid = offset < 0 || chance(0.35);
      await client.query(
        `INSERT INTO payrolls (school_id, staff_id, period, gross_salary, bonuses, deductions, net_salary, status, method, paid_at, reference)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
        [
          school,
          member.id,
          period,
          member.salary,
          bonuses,
          deductions,
          net,
          paid ? "payé" : "en attente",
          pick(["virement", "mobile money", "espèces"]),
          paid ? `${period}-05` : null,
          paid ? `PAIE-${period}-${int(1000, 9999)}` : "",
        ],
      );
    }
  }

  /* ---------------- Emplois du temps ---------------- */
  const HOURS = [
    ["07:30", "08:25"],
    ["08:25", "09:20"],
    ["09:20", "10:15"],
    ["10:30", "11:25"],
    ["11:25", "12:20"],
    ["15:00", "15:55"],
  ];
  for (const cls of classIds) {
    const pool = subjectIds.filter((sub) =>
      cls.cycle === "Maternelle"
        ? sub.cycle === "Maternelle" || ["FRA", "MATH"].includes(sub.code)
        : cls.cycle === "Collège"
          ? true
          : sub.cycle === "Primaire",
    );
    for (let day = 1; day <= 5; day++) {
      const slots = day === 5 ? 4 : HOURS.length;
      for (let k = 0; k < slots; k++) {
        const subject = pool[(day * 3 + k) % pool.length];
        await client.query(
          `INSERT INTO timetable_slots (school_id, class_id, day, start_time, end_time, subject_id, teacher, room)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
          [school, cls.id, day, HOURS[k][0], HOURS[k][1], subject.id, subject.teacher, cls.room],
        );
      }
    }
  }

  /* ---------------- Cahier de textes ---------------- */
  const logDays = attendanceDays.slice(0, 7);
  for (const cls of classIds) {
    const pool = subjectIds.filter((sub) => sub.cycle === cls.cycle || cls.cycle === "Collège");
    for (const [index, day] of logDays.entries()) {
      if (chance(0.25)) continue;
      const subject = pool[index % pool.length];
      await client.query(
        `INSERT INTO lesson_logs (school_id, class_id, subject_id, date, title, content, homework, due_date, teacher)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
        [
          school,
          cls.id,
          subject.id,
          day,
          `${subject.name} — séance ${index + 1}`,
          `Déroulé de la séance : rappel des acquis, exercices d'application et correction collective.`,
          pick([
            "Exercices n°4 à 8 page 42 du manuel.",
            "Apprendre la leçon et préparer une présentation orale.",
            "Résoudre les deux problèmes du polycopié distribué.",
            "Lire le chapitre 3 et relever les mots difficiles.",
          ]),
          shift(int(1, 5)),
          subject.teacher,
        ],
      );
    }
  }

  /* ---------------- Examens ---------------- */
  for (const cls of classIds) {
    const pool = subjectIds.filter((sub) =>
      cls.cycle === "Maternelle" ? sub.cycle === "Maternelle" : sub.cycle === cls.cycle || cls.cycle === "Collège",
    );
    for (let i = 0; i < 3; i++) {
      const subject = pool[i % pool.length];
      const offset = [-12, 3, 9][i];
      await client.query(
        `INSERT INTO exams (school_id, class_id, subject_id, term, title, date, start_time, duration, room, supervisor, status)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
        [
          school,
          cls.id,
          subject.id,
          offset < 0 ? "Trimestre 1" : "Trimestre 2",
          offset < 0 ? `Composition — ${subject.name}` : `Devoir surveillé — ${subject.name}`,
          shift(offset),
          pick(["08:00", "10:00", "14:30"]),
          pick([60, 90, 120]),
          cls.room,
          pick(STAFF.filter((s) => s[3] === "enseignement").map((s) => `${s[0]} ${s[1]}`)),
          offset < 0 ? "terminé" : "planifié",
        ],
      );
    }
  }

  /* ---------------- Autres écoles clientes (console plateforme) ---------------- */
  const OTHER_SCHOOLS = [
    {
      name: "Institut La Semence",
      short: "ILS",
      city: "Kinshasa",
      plan: "Essentiel",
      status: "essai",
      seats: 150,
      price: 65000,
      renewal: shift(12),
      director: "M. Jean-Baptiste Kabongo",
      classes: 2,
      pupils: 7,
    },
    {
      name: "Complexe Scolaire Étoile du Sud",
      short: "CSES",
      city: "Lubumbashi",
      plan: "Pro",
      status: "actif",
      seats: 500,
      price: 135000,
      renewal: shift(21),
      director: "Mme Clarisse Mwamba",
      classes: 3,
      pupils: 9,
    },
    {
      name: "Lycée Moderne de Goma",
      short: "LMG",
      city: "Goma",
      plan: "Essentiel",
      status: "suspendu",
      seats: 150,
      price: 65000,
      renewal: shift(-8),
      director: "M. Ousmane Bahati",
      classes: 2,
      pupils: 6,
    },
  ];
  for (const item of OTHER_SCHOOLS) {
    const row = await client.query(
      `INSERT INTO schools (name, short_name, city, country, phone, email, address, motto, currency, director_name, plan, subscription_status, seats, monthly_price, renewal_date)
       VALUES ($1,$2,$3,'République démocratique du Congo',$4,$5,$6,'Excellence et rigueur','FC',$7,$8,$9,$10,$11,$12) RETURNING id`,
      [
        item.name,
        item.short,
        item.city,
        `+243 8${int(1, 9)} ${int(100, 999)} ${int(100, 999)}`,
        `contact@${item.short.toLowerCase()}.cd`,
        `${item.city}, République démocratique du Congo`,
        item.director,
        item.plan,
        item.status,
        item.seats,
        item.price,
        item.renewal,
      ],
    );
    const otherId = row.rows[0].id;
    const otherYear = await client.query(
      `INSERT INTO academic_years (school_id, label, start_date, end_date, is_current)
       VALUES ($1,'2026-2027','2026-09-14','2027-07-03',true) RETURNING id`,
      [otherId],
    );
    for (let c = 0; c < item.classes; c++) {
      const cls = await client.query(
        `INSERT INTO classes (school_id, academic_year_id, name, level, cycle, capacity, room, main_teacher, monthly_fee)
         VALUES ($1,$2,$3,$4,'Primaire',45,$5,$6,$7) RETURNING id`,
        [
          otherId,
          otherYear.rows[0].id,
          c === 0 ? "1ère Primaire" : "5ème Primaire",
          c === 0 ? "1ère Primaire" : "5ème Primaire",
          `Salle ${c + 1}`,
          `M. ${pick(FIRST_M)} ${pick(LAST)}`,
          50000,
        ],
      );
      for (let s = 0; s < item.pupils; s++) {
        const gender = chance(0.5) ? "F" : "M";
        const first = pick(gender === "F" ? FIRST_F : FIRST_M);
        const last = pick(LAST).toUpperCase();
        const st = await client.query(
          `INSERT INTO students (school_id, matricule, first_name, last_name, gender, birth_date, birth_place, status, address, enrolled_at)
           VALUES ($1,$2,$3,$4,$5,$6,$7,'actif',$8,$9) RETURNING id`,
          [
            otherId,
            `${item.short}-2026-${String(c * 20 + s + 1).padStart(3, "0")}`,
            first,
            last,
            gender,
            `2015-0${int(1, 9)}-1${int(0, 9)}`,
            item.city,
            `${item.city}, quartier central`,
            shift(-int(30, 90)),
          ],
        );
        await client.query(
          `INSERT INTO guardians (student_id, full_name, relation, phone, profession, is_primary)
           VALUES ($1,$2,'Père',$3,'Commerçant',true)`,
          [st.rows[0].id, `${pick(FIRST_M)} ${last}`, `+243 8${int(1, 9)} ${int(100, 999)} ${int(100, 999)}`],
        );
        await client.query(
          `INSERT INTO enrollments (student_id, class_id, academic_year_id, status, tuition_amount, registered_at)
           VALUES ($1,$2,$3,'inscrit',450000,$4)`,
          [st.rows[0].id, cls.rows[0].id, otherYear.rows[0].id, shift(-int(30, 90))],
        );
        const paid = chance(0.7) ? 180000 : 0;
        await client.query(
          `INSERT INTO invoices (school_id, student_id, number, label, amount, amount_paid, due_date, status)
           VALUES ($1,$2,$3,'Scolarité — 1er versement',180000,$4,$5,$6)`,
          [
            otherId,
            st.rows[0].id,
            `${item.short}-FAC-${String(c * 20 + s + 1).padStart(4, "0")}`,
            paid,
            chance(0.5) ? shift(-5) : shift(20),
            paid >= 180000 ? "payée" : paid > 0 ? "partielle" : "impayée",
          ],
        );
      }
    }
  }

  /* ---------------- Documents & bulletins scannés ---------------- */
  function miniPdf(lines) {
    const content = lines
      .map((line, i) => `BT /F1 ${i === 0 ? 16 : 11} Tf 50 ${790 - i * 22} Td (${String(line).replace(/[()\\]/g, "")}) Tj ET`)
      .join("\n");
    const objects = [
      "1 0 obj<< /Type /Catalog /Pages 2 0 R>>endobj",
      "2 0 obj<< /Type /Pages /Kids [3 0 R] /Count 1>>endobj",
      "3 0 obj<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R>>endobj",
      "4 0 obj<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica>>endobj",
      `5 0 obj<< /Length ${content.length} >>stream\n${content}\nendstream endobj`,
    ];
    let pdf = "%PDF-1.4\n";
    const offsets = [];
    for (const obj of objects) {
      offsets.push(pdf.length);
      pdf += obj + "\n";
    }
    const xref = pdf.length;
    pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
    for (const off of offsets) pdf += String(off).padStart(10, "0") + " 00000 n \n";
    pdf += `trailer<< /Size ${objects.length + 1} /Root 1 0 R>>\nstartxref\n${xref}\n%%EOF`;
    return Buffer.from(pdf, "latin1").toString("base64");
  }

  const bulletinLines = (pupil, cls, term, average) => [
    "COMPLEXE SCOLAIRE LES PALMIERS",
    "Kinshasa — République democratique du Congo",
    `BULLETIN DE NOTES — ${term.toUpperCase()} — Annee 2026-2027`,
    "",
    `Eleve : ${pupil.lastName} ${pupil.firstName}`,
    `Classe : ${cls.name}    Matricule : ${pupil.matricule}`,
    `Moyenne generale : ${average.toFixed(2)}/20`,
    "",
    "Mathématiques ............ " + (average + 0.5).toFixed(1),
    "Français ................. " + (average - 0.4).toFixed(1),
    "Sciences ................. " + (average + 0.1).toFixed(1),
    "",
    "Appreciation du conseil : ensemble satisfaisant.",
    "Le directeur, M. Patrice Ilunga",
    "",
    "Document numerise — verifier les notes avant validation.",
  ];

  const docStudents = students.slice(0, 10);
  for (const [index, pupil] of docStudents.entries()) {
    const cls = classIds.find((c) => c.id === pupil.classId) ?? classIds[0];
    const average = 11 + (index % 5) * 1.2;
    if (index % 2 === 0) {
      const pdf = miniPdf(bulletinLines(pupil, cls, "Trimestre 1", average));
      await client.query(
        `INSERT INTO documents (school_id, student_id, class_id, category, title, file_name, mime_type, file_size, data, term, average, decision, status, shared, uploaded_by, source)
         VALUES ($1,$2,$3,'bulletin',$4,$5,'application/pdf',$6,$7,'Trimestre 1',$8,$9,$10,true,'Secrétariat','scan')`,
        [
          school,
          pupil.id,
          cls.id,
          `Bulletin T1 — ${pupil.lastName} ${pupil.firstName}`,
          `bulletin-t1-${pupil.matricule.toLowerCase()}.pdf`,
          1800 + index * 40,
          pdf,
          average,
          average >= 10 ? "admis" : "à soutenir",
          index % 3 === 0 ? "à vérifier" : "validé",
        ],
      );
    }
    if (index < 4) {
      const pdf = miniPdf([
        "COMPLEXE SCOLAIRE LES PALMIERS",
        "EXTRAIT D'ACTE DE NAISSANCE",
        "",
        `${pupil.lastName} ${pupil.firstName}`,
        `Matricule : ${pupil.matricule}`,
        "Document administratif a conserver dans le dossier eleve.",
      ]);
      await client.query(
        `INSERT INTO documents (school_id, student_id, class_id, category, title, file_name, mime_type, file_size, data, status, shared, uploaded_by, source)
         VALUES ($1,$2,$3,'acte',$4,$5,'application/pdf',$6,$7,'validé',false,'Scolarité','import')`,
        [
          school,
          pupil.id,
          cls.id,
          `Acte de naissance — ${pupil.lastName}`,
          `acte-naissance-${pupil.matricule.toLowerCase()}.pdf`,
          1200,
          pdf,
        ],
      );
    }
  }

  const counts = await client.query(
    `SELECT (SELECT count(*) FROM students) students, (SELECT count(*) FROM invoices) invoices,
            (SELECT count(*) FROM payments) payments, (SELECT count(*) FROM grades) grades,
            (SELECT count(*) FROM attendance) attendance, (SELECT count(*) FROM staff) staff,
            (SELECT count(*) FROM timetable_slots) slots, (SELECT count(*) FROM lesson_logs) lessons,
            (SELECT count(*) FROM exams) exams, (SELECT count(*) FROM schools) schools,
            (SELECT count(*) FROM documents) documents`,
  );
  console.log("✔ Données de démonstration créées :", counts.rows[0]);
  await client.end();
}

function studentIdSafe(id) {
  return id;
}

main().catch(async (err) => {
  console.error(err);
  try {
    await client.end();
  } catch {}
  process.exit(1);
});
