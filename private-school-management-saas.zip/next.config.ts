import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: {
    serverActions: {
      // Autorise l'import de scans et de documents (photos, PDF) jusqu'à 12 Mo.
      bodySizeLimit: "12mb",
    },
  },
};

export default nextConfig;
